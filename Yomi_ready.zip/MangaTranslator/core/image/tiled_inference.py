"""Tiled inference for RT-DETR (ogkalu comic-text-and-bubble-detector).

The model is trained at 640x640 on roughly square crops (tall webtoons were
split vertically). The pipeline used to squash a whole 1:2 / 1:3 webtoon page
into 640x640, which shrinks and distorts text so `text_free` (outside text)
is often missed. For tall pages we run the model on overlapping near-square
vertical slices and merge the detections.
"""

from typing import Dict, List, Tuple

import numpy as np
import torch

TALL_ASPECT_THRESHOLD = 1.3  # h/w above this -> tile
TILE_OVERLAP = 0.2  # fraction of tile height shared with next tile
MERGE_IOU = 0.5
MERGE_IOA = 0.8  # drop box mostly inside a same-class, higher-score box


class _Boxes:
    def __init__(self, xyxy, conf, cls):
        self.xyxy, self.conf, self.cls = xyxy, conf, cls

    def __len__(self):
        return int(self.xyxy.shape[0])


class _Results:
    def __init__(self, boxes, names):
        self.boxes, self.names = boxes, names


def compute_tiles(h: int, w: int) -> List[Tuple[int, int]]:
    """Return [(y_start, y_end)] near-square vertical slices with overlap."""
    tile_h = max(w, 1)
    if h <= tile_h * TALL_ASPECT_THRESHOLD:
        return [(0, h)]
    step = max(int(tile_h * (1.0 - TILE_OVERLAP)), 1)
    tiles, y = [], 0
    while True:
        y2 = min(y + tile_h, h)
        tiles.append((y, y2))
        if y2 >= h:
            break
        y += step
    # avoid a sliver at the end
    if len(tiles) > 1 and (tiles[-1][1] - tiles[-1][0]) < tile_h * 0.5:
        tiles[-1] = (max(0, h - tile_h), h)
    return tiles


def merge_detections(boxes, scores, labels):
    """Greedy per-class NMS + containment suppression (numpy)."""
    if len(boxes) == 0:
        return boxes, scores, labels
    keep = []
    order = np.argsort(-scores)
    for i in order:
        bi = boxes[i]
        ai = max((bi[2] - bi[0]) * (bi[3] - bi[1]), 1e-6)
        dup = False
        for j in keep:
            if labels[j] != labels[i]:
                continue
            bj = boxes[j]
            iw = min(bi[2], bj[2]) - max(bi[0], bj[0])
            ih = min(bi[3], bj[3]) - max(bi[1], bj[1])
            if iw <= 0 or ih <= 0:
                continue
            inter = iw * ih
            aj = max((bj[2] - bj[0]) * (bj[3] - bj[1]), 1e-6)
            iou = inter / (ai + aj - inter)
            if iou > MERGE_IOU or inter / ai > MERGE_IOA:
                dup = True
                break
        if not dup:
            keep.append(i)
    keep = np.array(keep, dtype=int)
    return boxes[keep], scores[keep], labels[keep]


def run_rtdetr_tiled(model, image_cv, conf, device, imgsz=640):
    """Drop-in for ``model(image_cv, conf=..., device=..., imgsz=...)[0]``."""
    h, w = image_cv.shape[:2]
    tiles = compute_tiles(h, w)
    if len(tiles) == 1:
        return model(
            image_cv, conf=conf, device=device, verbose=False, imgsz=imgsz
        )[0]

    all_b, all_s, all_l = [], [], []
    for y1, y2 in tiles:
        res = model(
            image_cv[y1:y2], conf=conf, device=device, verbose=False, imgsz=imgsz
        )[0]
        if res.boxes is None or len(res.boxes) == 0:
            continue
        b = res.boxes.xyxy.detach().cpu().numpy().astype(np.float32).copy()
        b[:, [1, 3]] += y1
        all_b.append(b)
        all_s.append(res.boxes.conf.detach().cpu().numpy())
        all_l.append(res.boxes.cls.detach().cpu().numpy())

    names: Dict[int, str] = getattr(model, "names", {}) or {}
    dev = device if device is not None else "cpu"
    if not all_b:
        z = torch.zeros((0, 4), dtype=torch.float32, device=dev)
        e = torch.zeros((0,), dtype=torch.float32, device=dev)
        return _Results(_Boxes(z, e, e.clone()), names)

    b, s, l = merge_detections(
        np.concatenate(all_b), np.concatenate(all_s), np.concatenate(all_l)
    )
    t = lambda a: torch.as_tensor(a, dtype=torch.float32, device=dev)
    return _Results(_Boxes(t(b), t(s), t(l)), names)
