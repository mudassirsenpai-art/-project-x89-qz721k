"""Duplicate text-box removal for tall manhwa/manhua/webtoon pages.

Symptom this fixes: the same speech bubble is drawn twice with two different
font sizes (two overlapping text layers inside one bubble). It happens when
the same bubble ends up as two entries (bubble + bubble from tile overlap /
secondary detector, or bubble + OSB "text_free" box on top of it) and both
entries get translated and rendered.

Only used on tall pages (webtoon strips); regular manga pages are untouched.
"""

from typing import Any, Dict, List, Optional

from utils.logging import log_message

TALL_ASPECT_THRESHOLD = 1.3  # same value as tiled_inference.TALL_ASPECT_THRESHOLD
DUP_IOA_THRESHOLD = 0.6  # smaller box this much inside the other => duplicate


def is_tall_page(width: int, height: int) -> bool:
    return width > 0 and (height / float(width)) > TALL_ASPECT_THRESHOLD


def _area(b) -> float:
    return max(0.0, float(b[2]) - float(b[0])) * max(0.0, float(b[3]) - float(b[1]))


def _inter(a, b) -> float:
    iw = min(a[2], b[2]) - max(a[0], b[0])
    ih = min(a[3], b[3]) - max(a[1], b[1])
    return iw * ih if iw > 0 and ih > 0 else 0.0


def dedupe_overlapping_text_items(
    items: List[Dict[str, Any]],
    img_w: Optional[int] = None,
    img_h: Optional[int] = None,
    only_tall: bool = True,
    threshold: float = DUP_IOA_THRESHOLD,
    verbose: bool = False,
) -> List[Dict[str, Any]]:
    """Drop items whose bbox is mostly covered by another item.

    Keep priority: real speech bubble > OSB text, then larger box.
    Never drops SFX-flagged items in favour of nothing: an SFX/OSB item is only
    dropped if a speech bubble covers it.
    """
    if not items or len(items) < 2:
        return items
    if only_tall and img_w and img_h and not is_tall_page(img_w, img_h):
        return items

    # Step 1: a "merged" box = one big box that swallows 2+ separate bubbles
    # (text of both bubbles lands in it). Drop the big box, keep the children.
    merged = set()
    for a in range(len(items)):
        ba = items[a].get("bbox")
        if not ba or len(ba) != 4:
            continue
        kids = []
        for b in range(len(items)):
            if b == a:
                continue
            bb = items[b].get("bbox")
            if not bb or len(bb) != 4:
                continue
            ab = max(_area(bb), 1e-6)
            if _area(bb) < _area(ba) and _inter(ba, bb) / ab > threshold:
                kids.append(bb)
        distinct = []
        for k in kids:
            if all(
                _inter(k, d) / max(min(_area(k), _area(d)), 1e-6) < 0.3
                for d in distinct
            ):
                distinct.append(k)
        if len(distinct) >= 2:
            merged.add(a)
    if merged:
        log_message(
            f"Removed {len(merged)} merged box(es) that covered 2+ separate bubbles",
            always_print=True,
        )
        items = [it for i, it in enumerate(items) if i not in merged]
        if len(items) < 2:
            return items

    def rank(it):
        bbox = it.get("bbox")
        # higher = more worth keeping
        return (0 if it.get("is_outside_text", False) else 1, _area(bbox))

    valid = [i for i, it in enumerate(items) if it.get("bbox") and len(it["bbox"]) == 4]
    order = sorted(valid, key=lambda i: rank(items[i]), reverse=True)
    kept: List[int] = []
    dropped = set()
    for i in order:
        bi = items[i]["bbox"]
        ai = _area(bi)
        dup = False
        for j in kept:
            bj = items[j]["bbox"]
            smaller = max(min(ai, _area(bj)), 1e-6)
            if _inter(bi, bj) / smaller > threshold:
                dup = True
                break
        if dup:
            dropped.add(i)
        else:
            kept.append(i)

    if not dropped:
        return items
    log_message(
        f"Removed {len(dropped)} duplicate overlapping text box(es) (tall page)",
        always_print=True,
    )
    # keep original order of the input list
    return [it for i, it in enumerate(items) if i not in dropped]


# ---------------------------------------------------------------------------
# Text-level duplicate removal
# ---------------------------------------------------------------------------
# The box-level dedupe above only catches duplicates whose boxes overlap and
# only on tall pages. It misses the common case where ONE bubble's OCR/
# translation swallowed the neighbouring bubble's text (so the same sentence
# is drawn once small inside the big bubble and again in its own bubble), and
# the case where a speech bubble is also picked up as an outside-text (OSB)
# item and its translation is drawn a second time over the artwork.
# These helpers work purely on the translated strings, so they run on every
# page type and on both the auto pipeline and the manual Pass 2 render.

import re as _re
from difflib import SequenceMatcher as _SM

_MIN_CONTAINED_CHARS = 12  # never strip very short/common phrases ("Haan.")


def _norm_text(s: str) -> str:
    return _re.sub(r"[\W_]+", "", (s or "").casefold())


def _words(s: str) -> List[str]:
    return [w for w in _re.split(r"[\W_]+", s or "") if w]


_FUZZY_RATIO = 0.88  # near-identical translations of the same sentence
_FAR_MIN_CHARS = 20  # far-apart duplicates are only dropped for longer texts


def _similar(na: str, nb: str) -> bool:
    if not na or not nb:
        return False
    if na == nb:
        return True
    if min(len(na), len(nb)) < _MIN_CONTAINED_CHARS:
        return False
    if abs(len(na) - len(nb)) > 0.25 * max(len(na), len(nb)):
        return False
    return _SM(None, na, nb).ratio() >= _FUZZY_RATIO


def _boxes_near(a, b, slack: float = 0.75) -> bool:
    """True if two boxes overlap or sit close together (same area of the page)."""
    if not a or not b or len(a) != 4 or len(b) != 4:
        return True  # unknown geometry: fall back to text-only decision
    gap_x = max(a[0], b[0]) - min(a[2], b[2])
    gap_y = max(a[1], b[1]) - min(a[3], b[3])
    max_h = max(a[3] - a[1], b[3] - b[1], 1)
    max_w = max(a[2] - a[0], b[2] - b[0], 1)
    return gap_x <= slack * max_w and gap_y <= slack * max_h


def _strip_phrase(text: str, phrase: str) -> Optional[str]:
    """Remove `phrase` (matched word-by-word, ignoring punctuation/case) from text."""
    words = _words(phrase)
    if not words:
        return None
    pattern = r"[\W_]*".join(_re.escape(w) for w in words) + r"[?!.\u2026]*"
    new_text, n = _re.subn(pattern, " ", text, flags=_re.IGNORECASE)
    if n == 0:
        return None
    new_text = _re.sub(r"\s+", " ", new_text).strip()
    new_text = _re.sub(r"^[\s,;:\-\u2026.]+", "", new_text).strip()
    new_text = _re.sub(r"[\s,;:\-]+$", "", new_text).strip()
    return new_text


def dedupe_translation_texts(
    bboxes: List[Any],
    texts: List[str],
    is_outside: List[bool],
    verbose: bool = False,
) -> List[str]:
    """Return a copy of `texts` with duplicated sentences removed.

    1. Identical translation in two items -> keep the speech bubble (or the
       larger box), blank the other (so it is skipped at render time).
    2. Item B's text fully contained inside item A's text (and the boxes are
       neighbours) -> A was a merged read of two bubbles; strip B's text out
       of A and let B render it in its own bubble.
    Blanked entries come back as "" which both render paths already skip.
    """
    n = len(texts)
    out = [(t or "") for t in texts]
    if n < 2:
        return out

    def area(i):
        b = bboxes[i]
        return _area(b) if b and len(b) == 4 else 0.0

    def overlaps_other(i):
        bi = bboxes[i]
        if not bi or len(bi) != 4:
            return False
        for k in range(n):
            if k == i:
                continue
            bk = bboxes[k]
            if not bk or len(bk) != 4:
                continue
            if _inter(bi, bk) / max(min(_area(bi), _area(bk)), 1e-6) >= 0.3:
                return True
        return False

    # Pass 1: duplicates (case/punctuation-insensitive, also near-identical).
    # Neighbouring boxes: always. Far-apart boxes: only long texts, and only
    # drop the copy that is an OSB item or sits on top of another box (a stray
    # nested item carrying another bubble's sentence).
    norms = [_norm_text(t) for t in out]
    for i in range(n):
        if not norms[i] or not out[i]:
            continue
        for j in range(i + 1, n):
            if not out[j] or not _similar(norms[i], norms[j]):
                continue
            if _boxes_near(bboxes[i], bboxes[j]):
                # keep speech bubble over OSB, then larger box
                keep_i = (not is_outside[i], area(i)) >= (not is_outside[j], area(j))
                drop = j if keep_i else i
            else:
                if min(len(norms[i]), len(norms[j])) < _FAR_MIN_CHARS:
                    continue
                cand_i = is_outside[i] or overlaps_other(i)
                cand_j = is_outside[j] or overlaps_other(j)
                if cand_i and cand_j:
                    keep_i = (not is_outside[i], area(i)) >= (not is_outside[j], area(j))
                    drop = j if keep_i else i
                elif cand_j:
                    drop = j
                elif cand_i:
                    drop = i
                else:
                    continue
            out[drop] = ""
            norms[drop] = ""
            if verbose:
                log_message(f"Dropped duplicate text on item {drop}", always_print=True)
            if drop == i:
                break

    # Pass 2: one item's text embedded inside another's
    changed = True
    guard = 0
    while changed and guard < 4 * n:
        changed = False
        guard += 1
        for a in range(n):
            if not out[a]:
                continue
            na = _norm_text(out[a])
            for b in range(n):
                if a == b or not out[b]:
                    continue
                nb = _norm_text(out[b])
                if len(nb) < _MIN_CONTAINED_CHARS or len(nb) >= len(na):
                    continue
                if nb not in na:
                    continue
                if not _boxes_near(bboxes[a], bboxes[b]):
                    continue
                stripped = _strip_phrase(out[a], out[b])
                if stripped is None:
                    continue
                out[a] = stripped
                changed = True
                if verbose:
                    log_message(
                        f"Removed text of item {b} that was duplicated inside item {a}",
                        always_print=True,
                    )
                break
            if changed:
                break
    return out
