"""Outline-based rescue for yolo_3 "caption" decisions.

yolo_3 detects floating captions as "bubble", so detection.py runs a fill/ring
heuristic (see ``_split_yolo3_captions``) and sends boxes that fail it to OSB.
That heuristic wrongly rejects REAL speech bubbles whose surroundings are bright
or pale (white sky, pale pink glow, white gutter, burst bubbles on white): the
outside ring then looks like the bubble fill, so ``ring_diff`` is small.

``is_enclosed_speech_bubble`` supplies the missing evidence. A real bubble is:
  1. a bright, near-uniform interior region that stays INSIDE the box (floating
     text on a page/art leaks out of the box),
  2. fully wrapped by a thin dark outline (tail/gaps tolerated via dilation),
  3. holding letter-like dark blobs of consistent height (i.e. real text).

Depends only on numpy + OpenCV so it can be unit-tested without torch.
"""

from typing import Dict, Tuple

import cv2
import numpy as np

SIM_TOL = 24  # gray distance to count as "same colour as bubble fill"
DARK_T = 125  # gray value below which a pixel counts as outline ink
BOUND_FRAC = 0.85  # share of interior boundary that must touch dark outline
MIN_AREA_FRAC = 0.20  # interior must cover at least this share of the box
LEAK = 1.08  # interior may not exceed the box by more than this factor
MIN_LETTERS = 4  # letter-sized dark blobs required inside the interior
MIN_FILL_GRAY = 165  # rescued bubbles are light (dark/coloured ones already pass)
MAX_FILL_STD = 10.0  # interior must be (near) uniform once text is excluded
MIN_CENTER_COVERAGE = 0.40  # below this the centre is art, not a bubble


def _close(mask: np.ndarray, k: int) -> np.ndarray:
    """Morphological closing that does NOT treat the ROI border as 'inside'."""
    p = k + 1
    out = cv2.morphologyEx(
        np.pad(mask, p), cv2.MORPH_CLOSE, np.ones((k, k), np.uint8)
    )
    return out[p:-p, p:-p]


def is_enclosed_speech_bubble(
    image_bgr: np.ndarray, box, pad: int = 8
) -> Tuple[bool, Dict[str, float]]:
    """Return (is_bubble, metrics) for an xyxy box on a BGR (or RGB) image."""
    info: Dict[str, float] = {"boundary": 0.0, "letters": 0.0, "std": -1.0}
    h, w = image_bgr.shape[:2]
    x1, y1, x2, y2 = [int(round(float(v))) for v in box[:4]]
    x1, y1, x2, y2 = max(0, x1), max(0, y1), min(w, x2), min(h, y2)
    bw, bh = x2 - x1, y2 - y1
    if bw < 30 or bh < 30:
        return False, info

    X1, Y1 = max(0, x1 - pad), max(0, y1 - pad)
    X2, Y2 = min(w, x2 + pad), min(h, y2 + pad)
    g = cv2.cvtColor(image_bgr[Y1:Y2, X1:X2], cv2.COLOR_BGR2GRAY).astype(np.int16)

    cx1, cy1 = x1 - X1 + int(bw * 0.3), y1 - Y1 + int(bh * 0.3)
    cx2, cy2 = x2 - X1 - int(bw * 0.3), y2 - Y1 - int(bh * 0.3)
    if cx2 <= cx1 or cy2 <= cy1:
        return False, info
    fill = float(np.median(g[cy1:cy2, cx1:cx2]))

    # 1) interior = connected "same colour as fill" region through the centre
    sim = (np.abs(g - fill) <= SIM_TOL).astype(np.uint8)
    sim = cv2.morphologyEx(sim, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    _, lab, _, _ = cv2.connectedComponentsWithStats(sim, connectivity=4)
    cen = lab[cy1:cy2, cx1:cx2]
    ids, cnt = np.unique(cen[cen > 0], return_counts=True)
    if len(ids) == 0:
        return False, info
    region = (lab == ids[int(np.argmax(cnt))]).astype(np.uint8)
    region = _close(region, 15)
    ys, xs = np.where(region > 0)
    if len(xs) == 0 or len(xs) < MIN_AREA_FRAC * bw * bh:
        return False, info
    if (xs.max() - xs.min() + 1) > LEAK * bw or (ys.max() - ys.min() + 1) > LEAK * bh:
        return False, info  # leaked out of the box -> floating text, not a bubble

    # 2) interior boundary must be wrapped by a dark outline
    dark = cv2.dilate((g < DARK_T).astype(np.uint8), np.ones((7, 7), np.uint8))
    boundary = region - cv2.erode(region, np.ones((3, 3), np.uint8))
    frac = float(dark[boundary > 0].mean()) if boundary.sum() else 0.0
    info["boundary"] = frac
    if frac < BOUND_FRAC:
        return False, info

    # 3) text evidence inside the enclosed region
    filled = _close(region, 31)
    # keep the text window clear of the outline stroke itself (else outline
    # fragments get counted as letters); scale with bubble size.
    k = max(9, int(0.05 * min(bw, bh)) | 1)
    # distance transform on a zero-padded mask: cv2.erode treats the ROI border as
    # "inside", which let outline tips (top/bottom/left/right of an ellipse) leak
    # into the text window and be counted as letters.
    dist = cv2.distanceTransform(np.pad(filled, 1), cv2.DIST_L2, 3)[1:-1, 1:-1]
    inner = (dist >= (k // 2) + 1).astype(np.uint8)
    txt = ((inner > 0) & (g < fill - 60)).astype(np.uint8)
    txt = cv2.dilate(txt, np.ones((3, 3), np.uint8))
    _, _, tst, _ = cv2.connectedComponentsWithStats(txt)
    letters = [
        s for s in tst[1:]
        if 5 <= s[3] <= 0.35 * bh and 2 <= s[2] <= 0.35 * bw and s[4] >= 12
    ]
    info["letters"] = float(len(letters))
    text_frac = float(txt.sum()) / max(1, int(inner.sum()))
    if len(letters) < MIN_LETTERS or text_frac > 0.35:
        return False, info
    if fill < MIN_FILL_GRAY:
        return False, info
    clean = (inner > 0) & (txt == 0)
    if clean.sum() < 50:
        return False, info
    info["std"] = float(g[clean].std())
    if info["std"] > MAX_FILL_STD:
        return False, info
    hs = np.array([s[3] for s in letters], float)
    if (np.abs(hs / np.median(hs) - 1) <= 0.6).mean() < 0.7:
        return False, info
    return True, info
