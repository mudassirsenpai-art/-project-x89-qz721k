"""Post-clean verification of speech bubbles (runs after cleaning, before render).

Two independent model checks that catch the classic failures for good:

1. LEFTOVER-TEXT CHECKER  (fixes "text stays inside the bubble")
   A text-detection model (the same YOLO text model the project already uses
   for outside-bubble text) is run on the *cleaned* page. Any text it still
   finds inside a bubble interior is confirmed with a pixel contrast check and
   erased with the bubble's own fill colour. Repeats up to MAX_ROUNDS times.

2. SECOND-OPINION BUBBLE FINDER  (fixes "inpaint went outside the bubble")
   The RT-DETR bubble detector (a different model from the primary YOLO/SAM
   pipeline) is run on the original page. Where it agrees with a bubble
   (IoU >= MIN_AGREE_IOU) but our cleaning mask reaches clearly past that
   independent bubble box, the overshoot is copied back from the original.
   Text-sized dark strokes are never "restored", so a wrong second opinion can
   not bring text back.

Everything is best-effort: any failure logs and leaves the page untouched.
"""

from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np

from utils.logging import log_message

MAX_ROUNDS = 2
MIN_AGREE_IOU = 0.4  # independent box must overlap our bubble this much
BOX_MARGIN_FRAC = 0.06  # tolerance around the independent box
BOX_MARGIN_PX = 6
MIN_TEXT_BOX_PX = 8
INK_DELTA = 45  # gray difference vs bubble fill that counts as ink
MIN_INK_PIXELS = 12
MIN_INK_FRAC = 0.01
TEXT_STROKE_MAX_PX = 120  # dark components smaller than this are "text"


# ---------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------
def _np(x) -> np.ndarray:
    if x is None:
        return np.zeros((0,), dtype=np.float32)
    if hasattr(x, "detach"):
        x = x.detach().cpu().numpy()
    return np.asarray(x)


def _run_model(model, image_bgr, conf, device):
    """model(image)[0]; tiled for tall pages when the tiler is importable."""
    try:
        from core.image.tiled_inference import run_rtdetr_tiled

        return run_rtdetr_tiled(model, image_bgr, conf=conf, device=device, imgsz=640)
    except ImportError:
        return model(image_bgr, conf=conf, device=device, verbose=False, imgsz=640)[0]


def _boxes(results) -> Tuple[np.ndarray, np.ndarray]:
    """(N,4) xyxy boxes and (N,) class ids from a results object."""
    b = getattr(results, "boxes", None)
    if b is None:
        return np.zeros((0, 4), np.float32), np.zeros((0,), np.int64)
    xyxy = _np(b.xyxy).reshape(-1, 4).astype(np.float32)
    cls = _np(getattr(b, "cls", None))
    if cls.size != len(xyxy):
        cls = np.zeros((len(xyxy),), dtype=np.int64)
    return xyxy, cls.astype(np.int64)


def _iou(a, b) -> float:
    iw = min(a[2], b[2]) - max(a[0], b[0])
    ih = min(a[3], b[3]) - max(a[1], b[1])
    if iw <= 0 or ih <= 0:
        return 0.0
    inter = iw * ih
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return float(inter / max(ua, 1e-6))


def _gray(c) -> float:
    b, g, r = [float(v) for v in c[:3]]
    return 0.114 * b + 0.587 * g + 0.299 * r


def _usable(info: Dict[str, Any], H: int, W: int) -> bool:
    m = info.get("mask")
    return (
        isinstance(m, np.ndarray)
        and m.shape[:2] == (H, W)
        and not info.get("inpainted", False)
        and info.get("color") is not None
    )


# ---------------------------------------------------------------------------
# 1) leftover-text checker
# ---------------------------------------------------------------------------
def find_and_clean_leftover_text(
    cleaned_bgr: np.ndarray,
    processed_info: List[Dict[str, Any]],
    bubble_data: List[Dict[str, Any]],
    text_model,
    conf: float,
    device,
    verbose: bool = False,
) -> int:
    """Erase text a detector still sees inside bubble interiors. Returns #fixes."""
    H, W = cleaned_bgr.shape[:2]
    infos = [i for i in processed_info if _usable(i, H, W)]
    if not infos:
        return 0
    osb_boxes = [
        d.get("bbox")
        for d in (bubble_data or [])
        if d.get("is_outside_text", False) and d.get("bbox") is not None
    ]
    k3 = np.ones((3, 3), np.uint8)
    total = 0
    for rnd in range(MAX_ROUNDS):
        boxes, _ = _boxes(_run_model(text_model, cleaned_bgr, conf, device))
        fixed = 0
        for x1, y1, x2, y2 in boxes:
            x1, y1 = max(0, int(np.floor(x1))), max(0, int(np.floor(y1)))
            x2, y2 = min(W, int(np.ceil(x2))), min(H, int(np.ceil(y2)))
            if x2 - x1 < MIN_TEXT_BOX_PX or y2 - y1 < MIN_TEXT_BOX_PX:
                continue
            cx, cy = (x1 + x2) / 2.0, (y1 + y2) / 2.0
            if any(
                ob is not None and ob[0] <= cx <= ob[2] and ob[1] <= cy <= ob[3]
                for ob in osb_boxes
            ):
                continue  # belongs to an outside-text item, not a bubble
            # which bubble interior holds (most of) this detection?
            best, best_frac = None, 0.0
            for info in infos:
                frac = float(np.count_nonzero(info["mask"][y1:y2, x1:x2])) / max(
                    1, (x2 - x1) * (y2 - y1)
                )
                if frac > best_frac:
                    best, best_frac = info, frac
            if best is None or best_frac < 0.5:
                continue
            pad = 3
            ry1, ry2 = max(0, y1 - pad), min(H, y2 + pad)
            rx1, rx2 = max(0, x1 - pad), min(W, x2 + pad)
            interior = cv2.dilate(best["mask"][ry1:ry2, rx1:rx2], k3, iterations=2) > 0
            fill = tuple(int(v) for v in best["color"][:3])
            g = cv2.cvtColor(cleaned_bgr[ry1:ry2, rx1:rx2, :3], cv2.COLOR_BGR2GRAY)
            ink = (np.abs(g.astype(np.int16) - _gray(fill)) > INK_DELTA) & interior
            n_ink = int(np.count_nonzero(ink))
            if n_ink < max(MIN_INK_PIXELS, MIN_INK_FRAC * interior.sum()):
                continue  # detector false alarm: nothing contrasting there
            ink = cv2.dilate(ink.astype(np.uint8), k3, iterations=2) > 0
            ink &= interior
            region = cleaned_bgr[ry1:ry2, rx1:rx2]
            region[ink] = fill
            fixed += 1
        total += fixed
        log_message(
            f"Leftover-text checker round {rnd + 1}: {len(boxes)} detections, {fixed} fixed",
            verbose=verbose,
        )
        if fixed == 0:
            break
    return total


# ---------------------------------------------------------------------------
# 2) second-opinion bubble finder
# ---------------------------------------------------------------------------
def independent_bubble_boxes(
    original_bgr: np.ndarray, rtdetr_model, conf: float, device
) -> np.ndarray:
    """Bubble boxes from the RT-DETR model (class 'bubble')."""
    results = _run_model(rtdetr_model, original_bgr, conf, device)
    boxes, cls = _boxes(results)
    names = getattr(rtdetr_model, "names", None) or {}
    bubble_ids = [cid for cid, nm in names.items() if nm == "bubble"]
    if bubble_ids:
        boxes = boxes[np.isin(cls, bubble_ids)]
    return boxes


def confirm_bubble_masks(
    original_bgr: np.ndarray,
    cleaned_bgr: np.ndarray,
    processed_info: List[Dict[str, Any]],
    indep_boxes: np.ndarray,
    verbose: bool = False,
) -> Dict[str, int]:
    """Cross-check each cleaning mask against the independent bubble boxes."""
    H, W = cleaned_bgr.shape[:2]
    stats = {"confirmed": 0, "unconfirmed": 0, "clipped_px": 0}
    if indep_boxes is None or len(indep_boxes) == 0:
        return stats
    orig_gray = None
    for info in processed_info:
        if not _usable(info, H, W) or info.get("bbox") is None:
            continue
        bb = [float(v) for v in info["bbox"][:4]]
        ious = [_iou(bb, ib) for ib in indep_boxes]
        j = int(np.argmax(ious))
        if ious[j] < MIN_AGREE_IOU:
            stats["unconfirmed"] += 1
            log_message(
                f"Bubble {[int(v) for v in bb]}: not confirmed by 2nd model "
                f"(best IoU {ious[j]:.2f})",
                verbose=verbose,
            )
            continue
        stats["confirmed"] += 1
        ib = indep_boxes[j]
        mx = BOX_MARGIN_FRAC * (ib[2] - ib[0]) + BOX_MARGIN_PX
        my = BOX_MARGIN_FRAC * (ib[3] - ib[1]) + BOX_MARGIN_PX
        ax1, ay1 = max(0, int(ib[0] - mx)), max(0, int(ib[1] - my))
        ax2, ay2 = min(W, int(ib[2] + mx)), min(H, int(ib[3] + my))
        outside = info["mask"] > 0
        outside[ay1:ay2, ax1:ax2] = False  # keep everything inside the allowed box
        if not outside.any():
            continue
        # Only act where the cleaning really changed pixels.
        changed = np.any(cleaned_bgr[..., :3] != original_bgr[..., :3], axis=2)
        leak = outside & changed
        if not leak.any():
            continue
        # Never bring text back: small, strongly dark/contrasting components
        # in the overshoot are treated as text strokes and left cleaned.
        if orig_gray is None:
            orig_gray = cv2.cvtColor(original_bgr[..., :3], cv2.COLOR_BGR2GRAY)
        fill_g = _gray(info["color"])
        strong = (np.abs(orig_gray.astype(np.int16) - fill_g) > 90) & leak
        if strong.any():
            n, lab, st, _ = cv2.connectedComponentsWithStats(
                strong.astype(np.uint8), connectivity=8
            )
            for c in range(1, n):
                if (
                    st[c, cv2.CC_STAT_WIDTH] <= TEXT_STROKE_MAX_PX
                    and st[c, cv2.CC_STAT_HEIGHT] <= TEXT_STROKE_MAX_PX
                ):
                    leak[lab == c] = False
        n_leak = int(np.count_nonzero(leak))
        if n_leak:
            cleaned_bgr[leak] = original_bgr[leak]
            stats["clipped_px"] += n_leak
            log_message(
                f"Bubble {[int(v) for v in bb]}: restored {n_leak}px of cleaning "
                "that reached past the confirmed bubble",
                always_print=True,
            )
    return stats


# ---------------------------------------------------------------------------
# orchestrator
# ---------------------------------------------------------------------------
def verify_page_bubbles(
    original_bgr: np.ndarray,
    cleaned_bgr: np.ndarray,
    bubble_data: List[Dict[str, Any]],
    processed_info: List[Dict[str, Any]],
    *,
    text_model=None,
    rtdetr_model=None,
    text_conf: float = 0.3,
    bubble_conf: float = 0.3,
    device=None,
    check_text: bool = True,
    check_masks: bool = True,
    verbose: bool = False,
) -> Dict[str, Any]:
    """Run both checks in place on `cleaned_bgr`. Never raises."""
    report: Dict[str, Any] = {"text_fixed": 0, "confirmed": 0, "unconfirmed": 0, "clipped_px": 0}
    try:
        if (
            cleaned_bgr is None
            or original_bgr is None
            or cleaned_bgr.shape[:2] != original_bgr.shape[:2]
            or not processed_info
        ):
            return report
        # mask confirmation first (it can only restore background), then the
        # text checker so it sees the final state of the page.
        if check_masks and rtdetr_model is not None:
            try:
                ib = independent_bubble_boxes(original_bgr, rtdetr_model, bubble_conf, device)
                s = confirm_bubble_masks(
                    original_bgr, cleaned_bgr, processed_info, ib, verbose=verbose
                )
                report.update(s)
            except Exception as e:
                log_message(f"Bubble mask confirmation skipped: {e}", always_print=True)
        if check_text and text_model is not None:
            try:
                report["text_fixed"] = find_and_clean_leftover_text(
                    cleaned_bgr,
                    processed_info,
                    bubble_data,
                    text_model,
                    text_conf,
                    device,
                    verbose=verbose,
                )
            except Exception as e:
                log_message(f"Leftover-text check skipped: {e}", always_print=True)
        log_message(
            f"Bubble verification: {report['confirmed']} confirmed, "
            f"{report['unconfirmed']} unconfirmed, {report['clipped_px']}px restored, "
            f"{report['text_fixed']} leftover text region(s) erased",
            always_print=True,
        )
    except Exception as e:  # never break the pipeline
        log_message(f"Bubble verification skipped: {e}", always_print=True)
    return report
