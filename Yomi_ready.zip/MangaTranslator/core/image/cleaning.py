import gc
import os
import random
import tempfile
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import cv2
import numpy as np
from PIL import Image

from core.batch_coordinator import (
    expanded_mask_bbox,
    partition_non_overlapping_waves,
    paste_image_region,
)
from core.image.glow_detection import MAX_GLOW_RING_EXTENT, detect_glow_halo
from core.scaling import scale_area, scale_kernel, scale_scalar
from utils.exceptions import CleaningError, ImageProcessingError, ValidationError
from utils.logging import log_message

from .detection import detect_speech_bubbles
from .image_utils import pil_to_cv2
from .inpainting import FluxKleinInpainter, FluxKontextInpainter
from ..text.style_extraction import extract_text_style

# Cleaning parameters
GRAYSCALE_MIDPOINT = 128  # Threshold for determining black vs white bubbles
MIN_CONTOUR_AREA = 50  # Minimum area threshold for filtering small contours
DILATION_KERNEL_SIZE = (7, 7)  # Kernel size for morphological dilation
EROSION_KERNEL_SIZE = (5, 5)  # Kernel size for morphological erosion
DISTANCE_TRANSFORM_MASK_SIZE = 5  # Mask size for distance transform

# Classification thresholds for colored bubbles
BRIGHT_RATIO_THRESHOLD = 0.65
DARK_RATIO_THRESHOLD = 0.65
BRIGHT_DOM_RATIO_MIN = 0.40
DARK_DOM_RATIO_MIN = 0.40
BRIGHT_DARK_RATIO_MAX = 0.10
DARK_BRIGHT_RATIO_MAX = 0.10


# Adaptive shrink defaults for conjoined junction zones (at 1.0x scale)
JUNCTION_ADJACENCY_MARGIN = 10  # Px margin around bbox intersection for junction zone
JUNCTION_MIN_SHRINK = 1.0  # Minimal shrink applied inside junction zones


def _normalize_mask(mask: np.ndarray) -> np.ndarray:
    """
    Ensure mask is uint8 binary (0/255).
    """
    if mask.dtype != np.uint8:
        mask = mask.astype(np.uint8)
    return np.where(mask > 0, 255, 0).astype(np.uint8)


def _resample_inpainted_bubble_color(
    pil_working: Image.Image,
    bubble_info: Dict[str, Any],
    mask_bool: np.ndarray,
) -> None:
    cv_after = cv2.cvtColor(np.array(pil_working.convert("RGB")), cv2.COLOR_RGB2BGR)
    masked_after = cv_after[mask_bool]
    if masked_after.size > 0:
        mean_val = int(np.clip(np.mean(masked_after), 0, 255))
        bubble_info["color"] = (mean_val, mean_val, mean_val)


def _inpaint_colored_bubbles_with_coordinator(
    pil_working: Image.Image,
    colored_bubbles: List[Dict[str, Any]],
    inpainter: Any,
    base_seed: int,
    verbose: bool,
    request_coordinator: Any,
) -> Image.Image:
    candidates = []
    for idx, bubble_info in enumerate(colored_bubbles):
        mask_np = bubble_info["mask"]
        mask_bool = mask_np.astype(bool)
        context_bbox = expanded_mask_bbox(mask_bool, pil_working.size)
        candidates.append(
            {
                "index": idx,
                "bubble_info": bubble_info,
                "mask": mask_bool,
                "seed": base_seed + idx if base_seed > 0 else base_seed,
                "bbox_tuple": bubble_info.get("bbox"),
                "context_bbox": context_bbox,
            }
        )

    waves = partition_non_overlapping_waves(
        candidates,
        lambda candidate: candidate["context_bbox"],
    )
    log_message(
        f"Scheduling colored-bubble Flux in {len(waves)} wave(s)",
        verbose=verbose,
    )

    for wave in waves:
        base_image = pil_working

        def make_job(candidate):
            def job():
                image_for_job = base_image.copy()
                try:
                    result_image = inpainter.inpaint_mask(
                        image_for_job,
                        candidate["mask"],
                        seed=candidate["seed"],
                        verbose=verbose,
                        ocr_params={
                            "type": "colored_bubble",
                            "bbox": candidate["bbox_tuple"],
                        },
                    )
                    return {
                        "candidate": candidate,
                        "image": result_image,
                        "error": None,
                    }
                except Exception as e:
                    return {
                        "candidate": candidate,
                        "image": None,
                        "error": e,
                        "traceback": traceback.format_exc(),
                    }

            return job

        results = request_coordinator.map_ordered([make_job(c) for c in wave])
        for result in results:
            candidate = result["candidate"]
            bubble_info = candidate["bubble_info"]
            if result["error"] is not None:
                err = result["error"]
                log_message(
                    f"Flux inpainting failed for bubble {candidate['bbox_tuple']}: "
                    f"{type(err).__name__}: {err}; falling back to standard fill\n"
                    f"{result.get('traceback', '')}",
                    always_print=True,
                )
                continue

            result_image = result["image"]
            context_bbox = candidate["context_bbox"]
            if context_bbox is None:
                pil_working = result_image
            else:
                pil_working = paste_image_region(
                    pil_working, result_image, context_bbox
                )
            bubble_info["inpainted"] = True
            _resample_inpainted_bubble_color(
                pil_working, bubble_info, candidate["mask"]
            )

    return pil_working


def _build_adaptive_shrink_mask(
    roi_mask: np.ndarray,
    roi_shrink_px: float,
    detection_bbox: tuple,
    neighbor_bboxes: list,
    processing_scale: float = 1.0,
) -> np.ndarray:
    """
    Shrink ROI uniformly except near conjoined neighbor edges, where only
    JUNCTION_MIN_SHRINK is applied.  Without this, the distance-transform
    shrink pinches off narrow junction passages and leaves remnant text.
    """
    adjacency_margin = max(1, int(round(JUNCTION_ADJACENCY_MARGIN * processing_scale)))
    junction_min_shrink = max(1.0, JUNCTION_MIN_SHRINK * processing_scale)

    dist_map = cv2.distanceTransform(
        roi_mask, cv2.DIST_L2, DISTANCE_TRANSFORM_MASK_SIZE
    )
    shrunk = np.where(dist_map >= roi_shrink_px, 255, 0).astype(np.uint8)

    x1, y1, x2, y2 = detection_bbox
    h, w = roi_mask.shape[:2]

    for other_bbox in neighbor_bboxes:
        ox1, oy1, ox2, oy2 = other_bbox

        if (
            x1 - adjacency_margin > ox2
            or ox1 - adjacency_margin > x2
            or y1 - adjacency_margin > oy2
            or oy1 - adjacency_margin > y2
        ):
            continue

        zone_x1 = max(0, max(x1, ox1) - adjacency_margin)
        zone_y1 = max(0, max(y1, oy1) - adjacency_margin)
        zone_x2 = min(w, min(x2, ox2) + adjacency_margin)
        zone_y2 = min(h, min(y2, oy2) + adjacency_margin)

        if zone_x2 <= zone_x1 or zone_y2 <= zone_y1:
            continue

        junction_slice = dist_map[zone_y1:zone_y2, zone_x1:zone_x2]
        restored = np.where(junction_slice >= junction_min_shrink, 255, 0).astype(
            np.uint8
        )
        np.bitwise_or(
            shrunk[zone_y1:zone_y2, zone_x1:zone_x2],
            restored,
            out=shrunk[zone_y1:zone_y2, zone_x1:zone_x2],
        )

    return shrunk


def process_single_bubble(
    base_mask,
    img_gray,
    img_height,
    img_width,
    thresholding_value,
    use_otsu_threshold,
    roi_shrink_px,
    verbose,
    detection_bbox=None,
    is_sam=False,
    dilation_kernel=None,
    constraint_erosion_kernel=None,
    min_contour_area: float = MIN_CONTOUR_AREA,
    classify_colored: bool = False,
    neighbor_bboxes: Optional[list] = None,
    processing_scale: float = 1.0,
    image_bgr: Optional[np.ndarray] = None,
):
    """
    Process a single speech bubble mask to extract text regions and determine fill color.

    Args:
        base_mask (numpy.ndarray): The base mask (SAM or YOLO) for the bubble
        img_gray (numpy.ndarray): Grayscale image
        img_height (int): Image height
        img_width (int): Image width
        thresholding_value (int): Fixed threshold value for text detection
        use_otsu_threshold (bool): Whether to use Otsu's method for thresholding
        roi_shrink_px (int): Pixels to shrink ROI inwards
        verbose (bool): Whether to print verbose messages
        detection_bbox: Bounding box for logging (optional)
        is_sam (bool): Whether this is a SAM mask (for logging)
        dilation_kernel: Kernel for dilation
        constraint_erosion_kernel: Kernel for erosion
        min_contour_area: Min area for contours
        classify_colored: Whether to classify colored bubbles
        neighbor_bboxes: Neighboring bboxes for shrink logic
        processing_scale: Processing scale multiplier
        image_bgr (numpy.ndarray): BGR image for text color sampling

    Returns:
        tuple: (final_mask, fill_color_bgr, is_colored, sample_color_bgr, text_bbox, text_color_bgr, text_median_line_height, glow_color_rgb, glow_radius)

    Raises:
        CleaningError: If processing fails
    """
    try:
        base_mask = _normalize_mask(base_mask)

        if dilation_kernel is None:
            dilation_kernel = cv2.getStructuringElement(
                cv2.MORPH_ELLIPSE, DILATION_KERNEL_SIZE
            )
        if constraint_erosion_kernel is None:
            constraint_erosion_kernel = cv2.getStructuringElement(
                cv2.MORPH_ELLIPSE, EROSION_KERNEL_SIZE
            )
        masked_pixels = img_gray[base_mask == 255]
        if masked_pixels.size == 0:
            log_message(
                f"{'[SAM]' if is_sam else ''}Skipping detection {detection_bbox}: empty mask",
                verbose=verbose,
            )
            raise CleaningError(f"Empty mask for detection {detection_bbox}")

        mean_pixel_value = np.mean(masked_pixels)
        is_black_bubble = mean_pixel_value < GRAYSCALE_MIDPOINT
        fill_color_bgr = (0, 0, 0) if is_black_bubble else (255, 255, 255)
        is_colored_bubble = False
        sample_color_bgr: tuple[int, int, int] = fill_color_bgr

        log_message(
            f"{'[SAM]' if is_sam else ''}Detection {detection_bbox}: "
            f"{'Black' if is_black_bubble else 'White'} bubble (mean={mean_pixel_value:.1f})",
            verbose=verbose,
        )

        roi_mask = cv2.dilate(base_mask, dilation_kernel, iterations=1)
        roi_gray = np.zeros_like(img_gray)
        roi_indices = roi_mask == 255
        roi_gray[roi_indices] = img_gray[roi_indices]

        # Invert for black bubbles to detect text properly
        roi_for_thresholding = (
            cv2.bitwise_not(roi_gray) if is_black_bubble else roi_gray
        )
        thresholded_roi = np.zeros_like(img_gray)

        if use_otsu_threshold:
            roi_pixels_for_otsu = roi_for_thresholding[roi_indices]
            thresh_val, _ = cv2.threshold(
                roi_pixels_for_otsu, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )
            log_message(
                f"{'[SAM]' if is_sam else ''}  Otsu threshold: {thresh_val}",
                verbose=verbose,
            )
            _, thresholded_roi = cv2.threshold(
                roi_for_thresholding, thresh_val, 255, cv2.THRESH_BINARY
            )
        else:
            _, thresholded_roi = cv2.threshold(
                roi_for_thresholding, thresholding_value, 255, cv2.THRESH_BINARY
            )

        thresholded_roi = cv2.bitwise_and(thresholded_roi, roi_mask)

        if neighbor_bboxes and detection_bbox is not None:
            shrunk_roi_mask = _build_adaptive_shrink_mask(
                roi_mask,
                float(roi_shrink_px),
                detection_bbox,
                neighbor_bboxes,
                processing_scale=processing_scale,
            )
        else:
            dist_map = cv2.distanceTransform(
                roi_mask, cv2.DIST_L2, DISTANCE_TRANSFORM_MASK_SIZE
            )
            shrunk_roi_mask = np.where(dist_map >= float(roi_shrink_px), 255, 0).astype(
                np.uint8
            )
        thresholded_roi = cv2.bitwise_and(thresholded_roi, shrunk_roi_mask)

        # Use eroded mask to avoid erasing bubble outlines
        eroded_constraint_mask = cv2.erode(
            base_mask, constraint_erosion_kernel, iterations=1
        )

        contours, _ = cv2.findContours(
            thresholded_roi, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        valid_contours = []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area <= min_contour_area:
                continue
            m = cv2.moments(cnt)
            if m["m00"] == 0:
                continue
            cx = int(m["m10"] / m["m00"])
            cy = int(m["m01"] / m["m00"])
            if (
                0 <= cx < img_width
                and 0 <= cy < img_height
                and eroded_constraint_mask[cy, cx] == 255
            ):
                valid_contours.append(cnt)

        log_message(
            f"{'[SAM]' if is_sam else ''}Detection {detection_bbox}: {len(valid_contours)} text fragments found",
            verbose=verbose,
        )

        text_bbox = None
        text_line_count = 0
        text_median_line_height = None
        if valid_contours:
            validated_mask = np.zeros((img_height, img_width), dtype=np.uint8)
            cv2.drawContours(
                validated_mask, valid_contours, -1, 255, thickness=cv2.FILLED
            )

            # Re-contour to get clean boundary from validated mask
            boundary_contours, _ = cv2.findContours(
                validated_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            if boundary_contours:
                largest_contour = max(boundary_contours, key=cv2.contourArea)
                final_mask = np.zeros((img_height, img_width), dtype=np.uint8)
                cv2.drawContours(
                    final_mask, [largest_contour], -1, 255, thickness=cv2.FILLED
                )
                # text_bbox is meant to describe the *whole* text block (all
                # lines), not just the single largest connected component.
                # When a bubble has multiple lines separated by gaps, each
                # line is its own external contour here - use the union of
                # ALL boundary contours' bounding boxes so multi-line text
                # isn't silently truncated to one line. (final_mask above is
                # left as the single largest contour; it's only used for the
                # colored-bubble sampling logic below, not for this bbox.)
                per_contour_rects = [cv2.boundingRect(c) for c in boundary_contours]
                bx1 = min(r[0] for r in per_contour_rects)
                by1 = min(r[1] for r in per_contour_rects)
                bx2 = max(r[0] + r[2] for r in per_contour_rects)
                by2 = max(r[1] + r[3] for r in per_contour_rects)
                text_bbox = (bx1, by1, bx2, by2)
                # Median single-line height across contours, for font-size
                # estimation (core.pipeline.estimate_target_font_size_from_bbox).
                # More robust than dividing the whole block height by a line
                # count: unaffected by inter-line gap size and by contours
                # that are stray punctuation/accents rather than full lines.
                if per_contour_rects:
                    text_line_count = len(per_contour_rects)
                    text_median_line_height = float(
                        np.median([r[3] for r in per_contour_rects])
                    )

                if classify_colored:
                    # Sample bubble interior excluding exact text pixels and outline to determine if colored
                    sampling_mask = cv2.erode(
                        base_mask, constraint_erosion_kernel, iterations=2
                    )
                    text_mask = cv2.bitwise_and(
                        cv2.bitwise_not(thresholded_roi), shrunk_roi_mask
                    )
                    text_mask_dilated = cv2.dilate(
                        text_mask, np.ones((3, 3), np.uint8), iterations=1
                    )
                    sampling_mask[text_mask_dilated == 255] = 0

                    sample_pixels = img_gray[sampling_mask == 255]
                    if sample_pixels.size == 0:
                        sample_pixels = masked_pixels

                    sample_values = sample_pixels.astype(np.uint8).flatten()
                    hist = np.bincount(sample_values, minlength=256)
                    dominant_val = (
                        int(hist.argmax()) if hist.size > 0 else int(mean_pixel_value)
                    )
                    dominant_count = int(hist.max()) if hist.size > 0 else 0
                    total_count = max(int(sample_values.size), 1)
                    dominant_ratio = dominant_count / float(total_count)
                    bright_ratio = float(
                        np.count_nonzero(sample_values >= 245)
                    ) / float(total_count)
                    dark_ratio = float(np.count_nonzero(sample_values <= 15)) / float(
                        total_count
                    )

                    log_prefix = "[SAM] " if is_sam else ""
                    if bright_ratio >= BRIGHT_RATIO_THRESHOLD or (
                        dominant_val >= 245
                        and dominant_ratio >= BRIGHT_DOM_RATIO_MIN
                        and dark_ratio <= BRIGHT_DARK_RATIO_MAX
                    ):
                        is_colored_bubble = False
                        fill_color_bgr = (255, 255, 255)
                        sample_color_bgr = (255, 255, 255)
                        log_message(
                            f"{log_prefix}Detection {detection_bbox}: white "
                            f"(mode={dominant_val}, dom_ratio={dominant_ratio:.2f}, "
                            f"bright_ratio={bright_ratio:.2f}, dark_ratio={dark_ratio:.2f})",
                            verbose=verbose,
                        )
                    elif dark_ratio >= DARK_RATIO_THRESHOLD or (
                        dominant_val <= 15
                        and dominant_ratio >= DARK_DOM_RATIO_MIN
                        and bright_ratio <= DARK_BRIGHT_RATIO_MAX
                    ):
                        is_colored_bubble = False
                        fill_color_bgr = (0, 0, 0)
                        sample_color_bgr = (0, 0, 0)
                        log_message(
                            f"{log_prefix}Detection {detection_bbox}: black "
                            f"(mode={dominant_val}, dom_ratio={dominant_ratio:.2f}, "
                            f"bright_ratio={bright_ratio:.2f}, dark_ratio={dark_ratio:.2f})",
                            verbose=verbose,
                        )
                    else:
                        is_colored_bubble = True
                        sample_color_bgr = (dominant_val, dominant_val, dominant_val)
                        log_message(
                            f"{log_prefix}Detection {detection_bbox}: "
                            f"colored/gradient (mode={dominant_val}, "
                            f"dom_ratio={dominant_ratio:.2f}, "
                            f"bright_ratio={bright_ratio:.2f}, "
                            f"dark_ratio={dark_ratio:.2f})",
                            verbose=verbose,
                        )

                text_color_bgr = None
                glow_color_rgb = None
                glow_radius = 0.0
                lettering_style = None
                if image_bgr is not None:
                    text_mask = cv2.bitwise_and(
                        cv2.bitwise_not(thresholded_roi), shrunk_roi_mask
                    )
                    sample_mask = cv2.erode(
                        text_mask, np.ones((3, 3), np.uint8), iterations=1
                    )
                    text_pixels_bgr = image_bgr[sample_mask == 255]
                    # Fallback if erosion obliterates thin text
                    if text_pixels_bgr.size == 0:
                        text_pixels_bgr = image_bgr[text_mask == 255]

                    if text_pixels_bgr.size > 0:
                        sampled_bgr = tuple(
                            np.median(text_pixels_bgr, axis=0).astype(int)
                        )
                        hsv = cv2.cvtColor(
                            np.uint8([[sampled_bgr]]), cv2.COLOR_BGR2HSV
                        )[0][0]
                        if hsv[1] < 25:
                            if not is_colored_bubble:
                                text_color_bgr = (
                                    (0, 0, 0)
                                    if fill_color_bgr == (255, 255, 255)
                                    else (255, 255, 255)
                                )
                            else:
                                text_color_bgr = (
                                    (0, 0, 0) if hsv[2] < 128 else (255, 255, 255)
                                )
                        else:
                            text_color_bgr = sampled_bgr

                    if text_pixels_bgr.size > 0:
                        # Glow needs room around the ink for the halo to
                        # actually be sampled - crop a padded region around
                        # the raw text_mask (not the eroded sample_mask,
                        # which is intentionally shrunk inward) and hand it
                        # to the shared detector along with the bubble's own
                        # background color as the reference to fade into.
                        text_ys, text_xs = np.where(text_mask == 255)
                        if text_ys.size > 0:
                            pad = MAX_GLOW_RING_EXTENT
                            gx0 = max(0, int(text_xs.min()) - pad)
                            gy0 = max(0, int(text_ys.min()) - pad)
                            gx1 = min(img_width, int(text_xs.max()) + 1 + pad)
                            gy1 = min(img_height, int(text_ys.max()) + 1 + pad)
                            glow_crop_bgr = image_bgr[gy0:gy1, gx0:gx1]
                            glow_ink_mask = text_mask[gy0:gy1, gx0:gx1]
                            if glow_crop_bgr.size > 0:
                                glow_crop_rgb = cv2.cvtColor(
                                    glow_crop_bgr, cv2.COLOR_BGR2RGB
                                )
                                bg_ref_bgr = (
                                    sample_color_bgr
                                    if sample_color_bgr
                                    else fill_color_bgr
                                )
                                bg_ref_rgb = (
                                    bg_ref_bgr[2],
                                    bg_ref_bgr[1],
                                    bg_ref_bgr[0],
                                )
                                glow_info = detect_glow_halo(
                                    glow_crop_rgb, glow_ink_mask, bg_ref_rgb
                                )
                                if glow_info:
                                    glow_color_rgb = glow_info["color"]
                                    glow_radius = glow_info["radius"]

                                # Unified style probe on the same untouched
                                # crop: measures fill/outline/glow/font size
                                # together so they're internally consistent
                                # (e.g. an outline is only trusted if the
                                # measured fill is what it wraps). Wraps in
                                # try/except so a measurement failure can
                                # never break cleaning - it just degrades to
                                # the sampling above.
                                try:
                                    lettering_style = extract_text_style(
                                        glow_crop_bgr,
                                        verbose=verbose,
                                        label=str(detection_bbox),
                                    )
                                except Exception as style_exc:
                                    log_message(
                                        f"{log_prefix}Style probe failed: {style_exc}",
                                        verbose=verbose,
                                    )
                                    lettering_style = None

                return (
                    final_mask,
                    fill_color_bgr,
                    is_colored_bubble,
                    sample_color_bgr,
                    text_bbox,
                    text_color_bgr,
                    text_median_line_height,
                    glow_color_rgb,
                    glow_radius,
                    lettering_style,
                )

        raise CleaningError("Failed to process bubble mask")

    except Exception as e:
        log_message(
            f"Failed to process {'SAM' if is_sam else 'YOLO'} mask for {detection_bbox}",
            always_print=True,
        )
        raise CleaningError("Failed to process bubble mask") from e


def clean_speech_bubbles(
    image_input: Union[str, Path, Image.Image],
    model_path,
    confidence=0.6,
    pre_computed_detections=None,
    device=None,
    thresholding_value: int = 200,
    use_otsu_threshold: bool = False,
    roi_shrink_px: int = 5,
    verbose: bool = False,
    processing_scale: float = 1.0,
    conjoined_confidence=0.35,
    inpaint_colored_bubbles: bool = False,
    flux_hf_token: str = "",
    flux_num_inference_steps: int = 8,
    flux_residual_diff_threshold: float = 0.15,
    flux_seed: int = 1,
    osb_text_verification: bool = False,
    osb_text_hf_token: str = "",
    inpaint_method: str = "flux_kontext",
    flux_backend: str = "sdnq",
    flux_low_vram: bool = False,
    flux_sdcpp_cache_mode: str = "none",
    flux_sdcpp_diffusion_quant: str = "Q4_K_M",
    flux_sdcpp_text_encoder_quant: str = "",
    flux_luminance_correction: bool = True,
    flux_upscale_small_crops: bool = True,
    bubble_detector_model: str = "yolo_2",
    request_coordinator: Optional[Any] = None,
):
    """
    Clean speech bubbles using YOLO/SAM masks and optional Flux inpainting for colored bubbles.

    Args:
        image_input (str, Path, or PIL.Image.Image): Path to input image or a PIL Image object.
        model_path (str): Path to YOLO model.
        confidence (float): Confidence threshold for detections.
        pre_computed_detections (list, optional): Pre-computed detections from previous call.
        device (torch.device, optional): The device to run detection model on if needed.
        thresholding_value (int): Fixed threshold value for text detection (0-255). Lower values (e.g., 180)
                                 are useful for uncleaned text close to bubble's edges.
        use_otsu_threshold (bool): If True, use Otsu's method for thresholding instead of the fixed value.
        roi_shrink_px (int): Number of pixels to shrink the ROI inwards before identification/fill.
        inpaint_colored_bubbles (bool): If True, detect non-white/black bubbles and inpaint text with Flux.
        flux_hf_token (str): Hugging Face token for Flux downloads (shared with outside-text removal).
        flux_num_inference_steps (int): Flux denoising steps for colored bubble inpainting.
        flux_residual_diff_threshold (float): Flux residual diff threshold for caching.
        flux_seed (int): Seed for Flux; -1 enables random per run.
        osb_text_verification (bool): When True, expand bubble boxes to fully cover OSB text detections.
        osb_text_hf_token (str): Optional token for OSB text model downloads.

    Returns:
        numpy.ndarray: Cleaned image with text removed.
        list[dict]: A list of dictionaries per bubble containing:
                    - 'mask' (np.ndarray): validated text mask (0/255)
                    - 'base_mask' (np.ndarray): normalized detection mask used for processing
                    - 'color' (tuple BGR): sampled bubble color
                    - 'bbox' (tuple): detection bounding box
                    - 'is_colored' (bool): whether bubble interior was classified colored
                    - 'text_bbox' (tuple|None): bounding box of detected text mask
                    - 'is_sam' (bool): whether detection originated from SAM
    Raises:
        ValueError: If the image cannot be loaded or if an image object is passed without pre-computed detections.
        RuntimeError: If model loading or bubble detection fails.
    """
    try:
        if isinstance(image_input, (str, Path)):
            pil_image = Image.open(image_input)
            image_path = image_input
        else:
            pil_image = image_input
            image_path = None  # In-memory image has no path

        image = pil_to_cv2(pil_image)
        img_height, img_width = image.shape[:2]
        img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        cleaned_image = image.copy()

        if pre_computed_detections is not None:
            detections = pre_computed_detections
        elif image_path is not None:
            detection_result = detect_speech_bubbles(
                image_path,
                model_path,
                confidence,
                device=device,
                conjoined_confidence=conjoined_confidence,
                osb_text_verification=osb_text_verification,
                osb_text_hf_token=osb_text_hf_token,
                bubble_detector_model=bubble_detector_model,
            )
            detections = (
                detection_result[0]
                if isinstance(detection_result, tuple)
                else detection_result
            )
        else:
            raise ValidationError(
                "Bubble detection requires an image path, but an image object "
                "was provided without pre-computed detections."
            )

        processed_bubbles = []

        effective_roi_shrink_px = float(
            scale_scalar(
                roi_shrink_px,
                processing_scale,
                minimum=0.0,
                maximum=64.0,
            )
        )
        dilation_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, scale_kernel(DILATION_KERNEL_SIZE, processing_scale)
        )
        constraint_erosion_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, scale_kernel(EROSION_KERNEL_SIZE, processing_scale)
        )
        min_contour_area = scale_area(
            MIN_CONTOUR_AREA,
            processing_scale,
            minimum=MIN_CONTOUR_AREA,
            maximum=5000,
        )
        for detection in detections:
            final_mask = None
            fill_color_bgr = None
            is_colored_bubble = False
            sample_color_bgr: Optional[tuple[int, int, int]] = None
            text_bbox: Optional[tuple[int, int, int, int]] = None
            text_color_bgr: Optional[tuple[int, int, int]] = None
            text_median_line_height: Optional[float] = None
            glow_color_rgb: Optional[tuple[int, int, int]] = None
            glow_radius: float = 0.0
            lettering_style: Optional[dict] = None
            base_mask = None
            is_sam_mask = False

            sam_mask = detection.get("sam_mask")
            if sam_mask is not None:
                base_mask = _normalize_mask(sam_mask)
                is_sam_mask = True
                try:
                    (
                        final_mask,
                        fill_color_bgr,
                        is_colored_bubble,
                        sample_color_bgr,
                        text_bbox,
                        text_color_bgr,
                        text_median_line_height,
                        glow_color_rgb,
                        glow_radius,
                        lettering_style,
                    ) = process_single_bubble(
                        base_mask,
                        img_gray,
                        img_height,
                        img_width,
                        thresholding_value,
                        use_otsu_threshold,
                        effective_roi_shrink_px,
                        verbose,
                        detection.get("bbox"),
                        is_sam=True,
                        dilation_kernel=dilation_kernel,
                        constraint_erosion_kernel=constraint_erosion_kernel,
                        min_contour_area=min_contour_area,
                        classify_colored=inpaint_colored_bubbles,
                        neighbor_bboxes=detection.get("conjoined_neighbor_bboxes"),
                        processing_scale=processing_scale,
                        image_bgr=image,
                    )
                except Exception as e:
                    retry_success = False
                    if not use_otsu_threshold and base_mask is not None:
                        log_message(
                            f"Standard cleaning failed for {detection.get('bbox')}, retrying with Otsu...",
                            verbose=verbose,
                        )
                        retry_res = retry_cleaning_with_otsu(
                            image,
                            {
                                "base_mask": base_mask,
                                "bbox": detection.get("bbox"),
                                "is_sam": True,
                                "neighbor_bboxes": detection.get(
                                    "conjoined_neighbor_bboxes"
                                ),
                            },
                            thresholding_value,
                            roi_shrink_px,
                            processing_scale,
                            verbose,
                            inpaint_colored_bubbles,
                        )
                        if retry_res:
                            final_mask = retry_res["mask"]
                            fill_color_bgr = retry_res["color"]
                            sample_color_bgr = retry_res["color"]
                            is_colored_bubble = retry_res["is_colored"]
                            text_bbox = retry_res["text_bbox"]
                            text_color_bgr = retry_res.get("text_color_bgr")
                            glow_color_rgb = retry_res.get("glow_color_rgb")
                            glow_radius = retry_res.get("glow_radius", 0.0)
                            lettering_style = retry_res.get("lettering_style")
                            retry_success = True
                            log_message(
                                f"Otsu retry successful for {detection.get('bbox')}",
                                verbose=verbose,
                            )
                        else:
                            log_message(
                                f"Otsu retry failed for {detection.get('bbox')}",
                                verbose=verbose,
                            )

                    if not retry_success:
                        error_msg = f"Error processing SAM mask for detection {detection.get('bbox')}: {e}"
                        log_message(error_msg, always_print=True)
                        continue
            else:
                if "mask_points" not in detection or not detection["mask_points"]:
                    log_message(
                        f"Skipping detection {detection.get('bbox')}: no mask points",
                        verbose=verbose,
                    )
                    continue

                try:
                    points_list = detection["mask_points"]
                    points = np.array(points_list, dtype=np.float32)

                    if len(points.shape) == 3 and points.shape[1] == 1:
                        points_int = np.round(points).astype(int)
                    elif len(points.shape) == 2 and points.shape[1] == 2:
                        points_int = np.round(points).astype(int).reshape((-1, 1, 2))
                    else:
                        log_message(
                            f"Skipping detection {detection.get('bbox')}: invalid mask format",
                            verbose=verbose,
                        )
                        continue

                    yolo_mask = np.zeros((img_height, img_width), dtype=np.uint8)
                    cv2.fillPoly(yolo_mask, [points_int], 255)
                    base_mask = _normalize_mask(yolo_mask)

                    (
                        final_mask,
                        fill_color_bgr,
                        is_colored_bubble,
                        sample_color_bgr,
                        text_bbox,
                        text_color_bgr,
                        text_median_line_height,
                        glow_color_rgb,
                        glow_radius,
                        lettering_style,
                    ) = process_single_bubble(
                        base_mask,
                        img_gray,
                        img_height,
                        img_width,
                        thresholding_value,
                        use_otsu_threshold,
                        effective_roi_shrink_px,
                        verbose,
                        detection.get("bbox"),
                        is_sam=False,
                        dilation_kernel=dilation_kernel,
                        constraint_erosion_kernel=constraint_erosion_kernel,
                        min_contour_area=min_contour_area,
                        classify_colored=inpaint_colored_bubbles,
                        neighbor_bboxes=detection.get("conjoined_neighbor_bboxes"),
                        processing_scale=processing_scale,
                        image_bgr=image,
                    )

                except Exception as e:
                    retry_success = False
                    if not use_otsu_threshold and base_mask is not None:
                        log_message(
                            f"Standard cleaning failed for {detection.get('bbox')}, retrying with Otsu...",
                            verbose=verbose,
                        )
                        retry_res = retry_cleaning_with_otsu(
                            image,
                            {
                                "base_mask": base_mask,
                                "bbox": detection.get("bbox"),
                                "is_sam": False,
                                "neighbor_bboxes": detection.get(
                                    "conjoined_neighbor_bboxes"
                                ),
                            },
                            thresholding_value,
                            roi_shrink_px,
                            processing_scale,
                            verbose,
                            inpaint_colored_bubbles,
                        )
                        if retry_res:
                            final_mask = retry_res["mask"]
                            fill_color_bgr = retry_res["color"]
                            sample_color_bgr = retry_res["color"]
                            is_colored_bubble = retry_res["is_colored"]
                            text_bbox = retry_res["text_bbox"]
                            text_color_bgr = retry_res.get("text_color_bgr")
                            glow_color_rgb = retry_res.get("glow_color_rgb")
                            glow_radius = retry_res.get("glow_radius", 0.0)
                            lettering_style = retry_res.get("lettering_style")
                            retry_success = True
                            log_message(
                                f"Otsu retry successful for {detection.get('bbox')}",
                                verbose=verbose,
                            )
                        else:
                            log_message(
                                f"Otsu retry failed for {detection.get('bbox')}",
                                verbose=verbose,
                            )

                    if not retry_success:
                        error_msg = f"Error processing YOLO mask for detection {detection.get('bbox')}: {e}"
                        log_message(error_msg, always_print=True)
                        continue

            if final_mask is not None and fill_color_bgr is not None:
                processed_bubbles.append(
                    {
                        "mask": final_mask,
                        "base_mask": base_mask,
                        "color": (
                            sample_color_bgr if sample_color_bgr else fill_color_bgr
                        ),
                        "bbox": detection.get("bbox"),
                        "is_colored": is_colored_bubble,
                        "text_bbox": text_bbox,
                        "text_color_bgr": text_color_bgr,
                        "text_median_line_height": text_median_line_height,
                        "glow_color_rgb": glow_color_rgb,
                        "glow_radius": glow_radius,
                        "lettering_style": lettering_style,
                        "is_sam": is_sam_mask,
                        "inpainted": False,
                    }
                )
                log_message(
                    f"Detection {detection.get('bbox')}: processed successfully",
                    verbose=verbose,
                )

        # Optional Flux inpainting for colored bubbles (text-only mask)
        if inpaint_colored_bubbles and inpaint_method not in ("opencv", "none"):
            colored_bubbles = [
                b for b in processed_bubbles if b.get("is_colored", False)
            ]
            # Nunchaku backend requires an HF token; other backends (sdnq, sdcpp)
            # don't. Warn up front so a missing-token fallback isn't silent —
            # this branch used to be unreachable dead code (an `elif` on the
            # same truthy `colored_bubbles` check below it), so this warning
            # never actually printed even when it was the real cause of a
            # bubble silently getting flat-filled instead of inpainted.
            needs_hf_token = (
                inpaint_method not in ("flux_klein_9b", "flux_klein_4b")
                and flux_backend == "nunchaku"
            )
            if colored_bubbles and needs_hf_token and not flux_hf_token:
                log_message(
                    "Colored bubbles detected but Flux inpainting skipped "
                    "(missing Hugging Face token for nunchaku backend); "
                    "falling back to standard fill",
                    always_print=True,
                )
                colored_bubbles = []

            if colored_bubbles:
                log_message(
                    f"Inpainting {len(colored_bubbles)} colored bubbles with Flux",
                    always_print=True,
                )
                pil_working = Image.fromarray(
                    cv2.cvtColor(cleaned_image, cv2.COLOR_BGR2RGB)
                )
                base_seed = (
                    random.randint(1, 999999)
                    if flux_seed == -1
                    else max(0, int(flux_seed))
                )
                temp_files = []
                try:
                    if inpaint_method == "flux_klein_9b":
                        backend = flux_backend
                        inpainter = FluxKleinInpainter(
                            variant="9b",
                            device=device,
                            huggingface_token=flux_hf_token,
                            num_inference_steps=int(flux_num_inference_steps),
                            low_vram=flux_low_vram,
                            luminance_correction=flux_luminance_correction,
                            upscale_small_crops=flux_upscale_small_crops,
                            backend=backend,
                            sdcpp_cache_mode=flux_sdcpp_cache_mode,
                            sdcpp_diffusion_quant=flux_sdcpp_diffusion_quant,
                            sdcpp_text_encoder_quant=flux_sdcpp_text_encoder_quant,
                            verbose=verbose,
                        )
                    elif inpaint_method == "flux_klein_4b":
                        backend = flux_backend
                        inpainter = FluxKleinInpainter(
                            variant="4b",
                            device=device,
                            huggingface_token=flux_hf_token,
                            num_inference_steps=int(flux_num_inference_steps),
                            low_vram=flux_low_vram,
                            luminance_correction=flux_luminance_correction,
                            upscale_small_crops=flux_upscale_small_crops,
                            backend=backend,
                            sdcpp_cache_mode=flux_sdcpp_cache_mode,
                            sdcpp_diffusion_quant=flux_sdcpp_diffusion_quant,
                            sdcpp_text_encoder_quant=flux_sdcpp_text_encoder_quant,
                            verbose=verbose,
                        )
                    else:
                        # Default to Flux Kontext
                        low_vram = flux_low_vram if flux_backend == "sdnq" else False
                        inpainter = FluxKontextInpainter(
                            device=device,
                            huggingface_token=flux_hf_token,
                            num_inference_steps=int(flux_num_inference_steps),
                            residual_diff_threshold=float(flux_residual_diff_threshold),
                            backend=flux_backend,
                            low_vram=low_vram,
                            sdcpp_cache_mode=flux_sdcpp_cache_mode,
                            sdcpp_diffusion_quant=flux_sdcpp_diffusion_quant,
                            sdcpp_text_encoder_quant=flux_sdcpp_text_encoder_quant,
                        )
                    if request_coordinator is not None and len(colored_bubbles) > 1:
                        pil_working = _inpaint_colored_bubbles_with_coordinator(
                            pil_working,
                            colored_bubbles,
                            inpainter,
                            base_seed,
                            verbose,
                            request_coordinator,
                        )
                    else:
                        for idx, bubble_info in enumerate(colored_bubbles):
                            mask_np = bubble_info["mask"]
                            mask_bool = mask_np.astype(bool)
                            region_seed = (
                                base_seed + idx if base_seed > 0 else base_seed
                            )
                            bbox_tuple = bubble_info.get("bbox")
                            ocr_params = {
                                "type": "colored_bubble",
                                "bbox": bbox_tuple,
                            }
                            try:
                                inpaint_call = inpainter.inpaint_mask
                                if request_coordinator is not None:
                                    pil_working = request_coordinator.run(
                                        inpaint_call,
                                        pil_working,
                                        mask_bool,
                                        seed=region_seed,
                                        verbose=verbose,
                                        ocr_params=ocr_params,
                                    )
                                else:
                                    pil_working = inpaint_call(
                                        pil_working,
                                        mask_bool,
                                        seed=region_seed,
                                        verbose=verbose,
                                        ocr_params=ocr_params,
                                    )
                                bubble_info["inpainted"] = True
                                _resample_inpainted_bubble_color(
                                    pil_working, bubble_info, mask_bool
                                )
                            except Exception as e:
                                log_message(
                                    f"Flux inpainting failed for bubble {bbox_tuple}: "
                                    f"{type(e).__name__}: {e}; falling back to standard fill\n"
                                    f"{traceback.format_exc()}",
                                    always_print=True,
                                )
                                continue

                            # Save intermediate result to disk to free memory when multiple regions
                            if idx < len(colored_bubbles) - 1:
                                temp_file = None
                                try:
                                    temp_fd, temp_file = tempfile.mkstemp(suffix=".png")
                                    os.close(temp_fd)
                                    pil_working.save(temp_file, format="PNG")
                                    log_message(
                                        "Saved intermediate inpainting result to disk",
                                        verbose=verbose,
                                    )
                                    temp_files.append(temp_file)
                                    with Image.open(temp_file) as img_tmp:
                                        img_tmp.load()
                                        pil_working = img_tmp.copy()
                                    gc.collect()
                                except Exception as e:
                                    log_message(
                                        f"Warning: Failed to save intermediate inpainting result: {e}",
                                        verbose=verbose,
                                    )
                                    if temp_file and temp_file in temp_files:
                                        temp_files.remove(temp_file)
                                    # fall through with in-memory image

                    cleaned_image = cv2.cvtColor(
                        np.array(pil_working.convert("RGB")), cv2.COLOR_RGB2BGR
                    )
                except Exception as e:
                    log_message(
                        f"Flux inpainting aborted; falling back to standard fill: "
                        f"{type(e).__name__}: {e}\n{traceback.format_exc()}",
                        always_print=True,
                    )
                finally:
                    for temp_file in temp_files:
                        if temp_file and os.path.exists(temp_file):
                            try:
                                os.remove(temp_file)
                            except Exception:
                                pass

        # Group masks by color for efficient batch processing (skip already inpainted regions)
        if processed_bubbles:
            color_groups = {}
            for bubble_info in processed_bubbles:
                if bubble_info.get("inpainted", False):
                    continue
                color_key = bubble_info["color"]
                if color_key not in color_groups:
                    color_groups[color_key] = []
                color_groups[color_key].append(bubble_info["mask"])

            for color_bgr, masks in color_groups.items():
                combined_mask = np.bitwise_or.reduce(masks)

                if cleaned_image.shape[2] == 4:
                    cleaned_image[combined_mask == 255, :3] = (
                        color_bgr  # Preserve alpha channel
                    )
                else:
                    cleaned_image[combined_mask == 255] = color_bgr

        # Undo fills that leaked past the bubble outline (white corner boxes).
        restore_outside_bubble_shape(
            cleaned_image, image, detections, verbose=verbose
        )
        # Tall pages: pixel-based rescue for bubbles whose mask was too big.
        restore_outline_leaks(cleaned_image, image, detections, verbose=verbose)

        # Safety net: some bubbles get skipped (processing error) or only
        # partly cleaned. Sweep leftover original text out of every white
        # bubble so the translation never lands on top of the old text.
        try:
            swept = 0
            for det in detections:
                swept += sweep_residual_bubble_text(
                    cleaned_image,
                    det.get("bbox"),
                    det.get("sam_mask"),
                    verbose=verbose,
                )
            if swept:
                log_message(
                    f"Residual sweep erased leftover text ({swept}px)",
                    always_print=True,
                )
        except Exception as sweep_exc:
            log_message(f"Residual sweep skipped: {sweep_exc}", verbose=verbose)

        log_message(
            f"Cleaned {len(processed_bubbles)} speech bubbles", always_print=True
        )
        return cleaned_image, processed_bubbles
    except IOError as e:
        raise ImageProcessingError(f"Error loading image {image_input}: {str(e)}")
    except Exception as e:
        raise CleaningError(f"Error cleaning speech bubbles: {str(e)}")


def retry_cleaning_with_otsu(
    image_bgr: np.ndarray,
    bubble_info: dict,
    thresholding_value: int,
    roi_shrink_px: int,
    processing_scale: float = 1.0,
    verbose: bool = False,
    classify_colored: bool = False,
) -> Optional[dict]:
    """
    Retry cleaning for a single bubble using Otsu thresholding.

    Returns a bubble-info dict compatible with clean_speech_bubbles output,
    or None if retry fails.
    """
    base_mask = bubble_info.get("base_mask")
    if base_mask is None:
        log_message(
            f"Otsu retry skipped for {bubble_info.get('bbox')}: missing base_mask",
            verbose=verbose,
        )
        return None

    try:
        if len(image_bgr.shape) == 3 and image_bgr.shape[2] == 4:
            img_gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGRA2GRAY)
        else:
            img_gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    except Exception as e:
        log_message(
            f"Otsu retry failed to convert image to grayscale: {e}",
            always_print=True,
        )
        return None

    img_height, img_width = img_gray.shape[:2]

    effective_roi_shrink_px = float(
        scale_scalar(
            roi_shrink_px,
            processing_scale,
            minimum=0.0,
            maximum=64.0,
        )
    )
    dilation_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, scale_kernel(DILATION_KERNEL_SIZE, processing_scale)
    )
    constraint_erosion_kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, scale_kernel(EROSION_KERNEL_SIZE, processing_scale)
    )
    min_contour_area = scale_area(
        MIN_CONTOUR_AREA,
        processing_scale,
        minimum=MIN_CONTOUR_AREA,
        maximum=5000,
    )

    try:
        result = process_single_bubble(
            base_mask,
            img_gray,
            img_height,
            img_width,
            thresholding_value,
            True,  # force Otsu
            effective_roi_shrink_px,
            verbose,
            bubble_info.get("bbox"),
            bubble_info.get("is_sam", False),
            dilation_kernel=dilation_kernel,
            constraint_erosion_kernel=constraint_erosion_kernel,
            min_contour_area=min_contour_area,
            classify_colored=classify_colored,
            neighbor_bboxes=bubble_info.get("neighbor_bboxes"),
            processing_scale=processing_scale,
            image_bgr=image_bgr,
        )
    except CleaningError as e:
        log_message(
            f"Otsu retry cleaning failed for {bubble_info.get('bbox')}: {e}",
            always_print=True,
        )
        return None
    except Exception as e:
        log_message(
            f"Otsu retry cleaning unexpected error for {bubble_info.get('bbox')}: {e}",
            always_print=True,
        )
        return None

    if not result:
        return None

    (
        final_mask,
        fill_color_bgr,
        is_colored_bubble,
        sample_color_bgr,
        text_bbox,
        text_color_bgr,
        text_median_line_height,
        glow_color_rgb,
        glow_radius,
        lettering_style,
    ) = result

    bubble_color = sample_color_bgr if sample_color_bgr else fill_color_bgr

    log_message(
        f"Otsu retry succeeded for {bubble_info.get('bbox')}",
        verbose=verbose,
    )

    return {
        "mask": final_mask,
        "base_mask": _normalize_mask(base_mask),
        "color": bubble_color,
        "bbox": bubble_info.get("bbox"),
        "is_colored": is_colored_bubble,
        "text_bbox": text_bbox,
        "text_color_bgr": text_color_bgr,
        "text_median_line_height": text_median_line_height,
        "glow_color_rgb": glow_color_rgb,
        "glow_radius": glow_radius,
        "lettering_style": lettering_style,
        "is_sam": bubble_info.get("is_sam", False),
    }


# ---------------------------------------------------------------------------
# Residual-text sweep (safety net for bubbles whose cleaning was skipped/partial)
# ---------------------------------------------------------------------------
SWEEP_MIN_PAPER_LEVEL = 200      # bubble interior must be near-white to be swept
SWEEP_PAPER_TOLERANCE = 22       # gray >= paper - tol counts as "paper"
SWEEP_MAX_INK_FRACTION = 0.38    # more ink than this => probably not a text bubble
SWEEP_MIN_INK_PIXELS = 12        # ignore specks
SWEEP_MAX_COMPONENT_HEIGHT_FRAC = 0.45  # a single "ink" blob taller than this is art, not a letter


def sweep_residual_bubble_text(
    image_bgr: np.ndarray,
    bbox,
    bubble_mask: Optional[np.ndarray] = None,
    verbose: bool = False,
) -> int:
    """
    Erase original text left inside a *white* speech bubble (in place).

    clean_speech_bubbles() can silently skip a bubble (``continue`` on a
    processing error) or only partially erase it (e.g. panel border running
    behind the bubble, overlapping bubbles). The translation then gets drawn
    over the old text. This finds the closed white interior of the bubble,
    fills its holes (= the old letters) with the paper colour and leaves the
    black outline and tail untouched.

    Args:
        image_bgr: page image (BGR / BGRA), modified in place.
        bbox: (x1, y1, x2, y2) of the bubble.
        bubble_mask: optional full-page 0/255 mask of the bubble (YOLO/SAM).
            When given, only pixels inside it are ever touched.
        verbose: log what happened.

    Returns:
        Number of pixels erased (0 if nothing to do / bubble not swept).
    """
    try:
        if image_bgr is None or bbox is None or len(bbox) != 4:
            return 0
        H, W = image_bgr.shape[:2]
        x1, y1, x2, y2 = [int(round(float(v))) for v in bbox]
        pad = 6
        cx1, cy1 = max(0, x1 - pad), max(0, y1 - pad)
        cx2, cy2 = min(W, x2 + pad), min(H, y2 + pad)
        if cx2 - cx1 < 20 or cy2 - cy1 < 20:
            return 0

        crop = image_bgr[cy1:cy2, cx1:cx2, :3]
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        ch, cw = gray.shape

        # Region we are allowed to touch.
        allowed = np.full((ch, cw), 255, np.uint8)
        if bubble_mask is not None:
            try:
                m = bubble_mask[cy1:cy2, cx1:cx2]
                if m.shape == gray.shape and np.count_nonzero(m) > 50:
                    allowed = (m > 0).astype(np.uint8) * 255
                    # stay off the outline
                    allowed = cv2.erode(allowed, np.ones((3, 3), np.uint8), iterations=1)
            except Exception:
                pass

        # Paper level = most common bright value around the middle of the bubble.
        yy, xx = np.ogrid[:ch, :cw]
        ell = (((xx - cw / 2.0) / (cw * 0.42)) ** 2 + ((yy - ch / 2.0) / (ch * 0.42)) ** 2) <= 1.0
        sel = gray[ell & (allowed > 0)]
        sel = sel[sel >= 150]
        if sel.size < 200:
            return 0
        hist = np.bincount(sel, minlength=256)
        paper = int(hist.argmax())
        if paper < SWEEP_MIN_PAPER_LEVEL:
            return 0  # coloured / dark bubble - leave to the normal pipeline

        white = (gray >= paper - SWEEP_PAPER_TOLERANCE).astype(np.uint8) * 255
        white = cv2.bitwise_and(white, allowed)

        n, labels, stats, _ = cv2.connectedComponentsWithStats(white, connectivity=4)
        if n <= 1:
            return 0
        # interior = component with the most pixels inside the central ellipse
        counts = np.bincount(labels[ell & (labels > 0)], minlength=n)
        counts[0] = 0
        interior_id = int(counts.argmax())
        if counts[interior_id] < 150:
            return 0
        interior = (labels == interior_id).astype(np.uint8) * 255

        # Fill the holes (old letters) - external contour only.
        contours, _ = cv2.findContours(interior, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not contours:
            return 0
        filled = np.zeros_like(interior)
        cv2.drawContours(filled, contours, -1, 255, thickness=cv2.FILLED)
        filled = cv2.bitwise_and(filled, allowed)

        ink = cv2.bitwise_and(filled, cv2.bitwise_not(interior))
        ink_px = int(np.count_nonzero(ink))
        interior_area = max(int(np.count_nonzero(filled)), 1)
        if ink_px < SWEEP_MIN_INK_PIXELS:
            return 0
        if ink_px / interior_area > SWEEP_MAX_INK_FRACTION:
            log_message(
                f"Residual sweep {bbox}: too much ink ({ink_px / interior_area:.0%}), skipped",
                verbose=verbose,
            )
            return 0

        # Drop blobs that are clearly not lettering (tall art/tail pieces).
        n2, lab2, st2, _ = cv2.connectedComponentsWithStats(ink, connectivity=8)
        keep = np.zeros_like(ink)
        max_h = SWEEP_MAX_COMPONENT_HEIGHT_FRAC * ch
        for i in range(1, n2):
            if st2[i, cv2.CC_STAT_HEIGHT] <= max_h:
                keep[lab2 == i] = 255
        if not np.any(keep):
            return 0

        # Cover anti-aliasing fringe, but never reach the outline.
        keep = cv2.dilate(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (13, 13)), iterations=1)
        inner = cv2.erode(filled, np.ones((3, 3), np.uint8), iterations=1)
        keep = cv2.bitwise_and(keep, inner)

        # Fill with the bubble's *actual* paper colour (per-channel median of the
        # clean interior). Forcing pure 255 on a 250-252 paper leaves a visible
        # lighter rectangle ("ghost box") behind the new text.
        region = image_bgr[cy1:cy2, cx1:cx2]
        clean_px = (cv2.erode(interior, np.ones((5, 5), np.uint8)) > 0) & (keep == 0)
        if np.count_nonzero(clean_px) >= 50:
            fill_bgr = np.median(region[clean_px][:, :3], axis=0).astype(np.uint8)
        else:
            fill_bgr = np.full(3, int(max(0, min(255, paper))), np.uint8)
        region[keep > 0, :3] = fill_bgr
        erased = int(np.count_nonzero(keep))
        log_message(f"Residual sweep {bbox}: erased {erased}px of leftover text", verbose=verbose)
        return erased
    except Exception as e:  # never break the pipeline
        log_message(f"Residual sweep failed for {bbox}: {e}", verbose=verbose)
        return 0


def sweep_residual_text_for_bubbles(
    image_bgr: np.ndarray,
    bubbles,
    verbose: bool = False,
) -> int:
    """Run sweep_residual_bubble_text for every non-OSB bubble dict. In place."""
    total = 0
    for b in bubbles or []:
        if b.get("is_outside_text", False):
            continue
        bbox = b.get("bbox")
        mask = b.get("sam_mask")
        if mask is None:
            mask = b.get("base_mask")
        total += sweep_residual_bubble_text(image_bgr, bbox, mask, verbose=verbose)
    return total


def _bubble_interior_from_original(original_bgr: np.ndarray, box, pad: int = 12):
    """Closed interior (text holes filled) of one bubble, found on the ORIGINAL
    page: connected region with the same colour as the bubble fill, wrapped by a
    dark outline. Returns (x_off, y_off, mask_uint8) or None if not clearly
    enclosed (then we do nothing for that bubble)."""
    h, w = original_bgr.shape[:2]
    x1, y1, x2, y2 = [int(round(float(v))) for v in box[:4]]
    x1, y1, x2, y2 = max(0, x1), max(0, y1), min(w, x2), min(h, y2)
    bw, bh = x2 - x1, y2 - y1
    if bw < 30 or bh < 30:
        return None
    X1, Y1 = max(0, x1 - pad), max(0, y1 - pad)
    X2, Y2 = min(w, x2 + pad), min(h, y2 + pad)
    g = cv2.cvtColor(original_bgr[Y1:Y2, X1:X2, :3], cv2.COLOR_BGR2GRAY).astype(np.int16)
    cx1, cy1 = x1 - X1 + int(bw * 0.3), y1 - Y1 + int(bh * 0.3)
    cx2, cy2 = x2 - X1 - int(bw * 0.3), y2 - Y1 - int(bh * 0.3)
    if cx2 <= cx1 or cy2 <= cy1:
        return None
    fill = float(np.median(g[cy1:cy2, cx1:cx2]))
    sim = (np.abs(g - fill) <= 24).astype(np.uint8)
    sim = cv2.morphologyEx(sim, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    _, lab, _, _ = cv2.connectedComponentsWithStats(sim, connectivity=4)
    cen = lab[cy1:cy2, cx1:cx2]
    ids, cnt = np.unique(cen[cen > 0], return_counts=True)
    if len(ids) == 0:
        return None
    region = (lab == ids[int(np.argmax(cnt))]).astype(np.uint8)

    def _close(mask, k):
        pp = k + 1
        out = cv2.morphologyEx(
            np.pad(mask, pp), cv2.MORPH_CLOSE, np.ones((k, k), np.uint8)
        )
        return out[pp:-pp, pp:-pp]

    region = _close(region, 15)
    ys, xs = np.where(region > 0)
    if len(xs) == 0 or len(xs) < 0.2 * bw * bh:
        return None
    if (xs.max() - xs.min() + 1) > 1.08 * bw or (ys.max() - ys.min() + 1) > 1.08 * bh:
        return None  # leaked outside the box -> not clearly enclosed
    dark = cv2.dilate((g < 125).astype(np.uint8), np.ones((7, 7), np.uint8))
    boundary = region - cv2.erode(region, np.ones((3, 3), np.uint8))
    if boundary.sum() == 0 or float(dark[boundary > 0].mean()) < 0.85:
        return None
    interior = _close(region, 31)  # fills thin letter strokes
    # Fill every hole that does not touch the crop border (letters, even ones
    # touching each other), so text pixels always count as "inside the bubble".
    inv = (interior == 0).astype(np.uint8)
    _, hlab = cv2.connectedComponents(inv, connectivity=4)
    border_ids = set(np.unique(np.concatenate(
        [hlab[0, :], hlab[-1, :], hlab[:, 0], hlab[:, -1]]
    )).tolist())
    border_ids.discard(0)
    holes = (inv > 0) & ~np.isin(hlab, list(border_ids))
    interior = np.where(holes, 1, interior).astype(np.uint8)
    return X1, Y1, interior


def restore_outline_leaks(
    cleaned_bgr: np.ndarray,
    original_bgr: np.ndarray,
    detections,
    pad: int = 12,
    verbose: bool = False,
) -> int:
    """Undo fills that went past a bubble's outline (tall manhwa/webtoon pages).

    Works from pixels of the original page, not from the detection mask, so it
    also fixes bubbles whose mask was too big. Interiors of ALL bubbles are
    unioned first, so one bubble can never un-clean a neighbour's text. Bubbles
    that are not clearly enclosed by an outline are skipped (no guessing)."""
    restored = 0
    try:
        H, W = cleaned_bgr.shape[:2]
        if (H / float(max(W, 1))) <= 1.3:
            return 0
        allowed = np.zeros((H, W), np.uint8)
        zones = np.zeros((H, W), np.uint8)
        found = 0
        for det in detections or []:
            if det.get("is_outside_text", False):
                continue
            bbox = det.get("bbox")
            if bbox is None or len(bbox) != 4:
                continue
            res = _bubble_interior_from_original(original_bgr, bbox, pad=pad)
            if res is None:
                continue
            X1, Y1, interior = res
            hh, ww = interior.shape[:2]
            allowed[Y1 : Y1 + hh, X1 : X1 + ww] |= interior
            zones[Y1 : Y1 + hh, X1 : X1 + ww] = 255
            found += 1
        if not found:
            return 0
        allowed = cv2.dilate(allowed, np.ones((3, 3), np.uint8))
        changed = np.any(cleaned_bgr[..., :3] != original_bgr[..., :3], axis=2)
        # only act near bubbles we could verify, and only outside every interior
        leak = changed & (zones > 0) & (allowed == 0)
        n = int(np.count_nonzero(leak))
        if n:
            cleaned_bgr[leak] = original_bgr[leak]
            restored = n
            log_message(
                f"Restored {n}px that leaked past bubble outlines",
                always_print=True,
            )
    except Exception as e:  # never break the pipeline
        log_message(f"restore_outline_leaks skipped: {e}", verbose=verbose)
    return restored


def restore_outside_bubble_shape(
    cleaned_bgr: np.ndarray,
    original_bgr: np.ndarray,
    detections,
    margin_px: int = 10,
    verbose: bool = False,
) -> int:
    """
    Undo any cleaning that leaked outside the bubble's real shape (in place).

    When a bubble sits on a coloured/gradient background, a rectangular fill
    can whiten the bbox corners around the ellipse (white box artifact). The
    bubble polygon/SAM mask is the true shape, so every pixel of the bbox that
    lies outside it (plus a small margin) is copied back from the original.
    """
    restored = 0
    try:
        H, W = cleaned_bgr.shape[:2]
        k = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (2 * margin_px + 1, 2 * margin_px + 1)
        )
        for det in detections or []:
            if det.get("is_outside_text", False):
                continue
            bbox = det.get("bbox")
            if bbox is None or len(bbox) != 4:
                continue
            shape = None
            sam = det.get("sam_mask")
            if sam is not None and sam.shape[:2] == (H, W) and np.count_nonzero(sam) > 50:
                shape = (sam > 0).astype(np.uint8) * 255
            elif det.get("mask_points") is not None:
                try:
                    pts = np.array(det["mask_points"], dtype=np.float32)
                    pts = np.round(pts).astype(np.int32).reshape((-1, 1, 2))
                    shape = np.zeros((H, W), np.uint8)
                    cv2.fillPoly(shape, [pts], 255)
                except Exception:
                    shape = None
            if shape is None:
                continue  # no true shape known -> never guess
            x1, y1, x2, y2 = [int(round(float(v))) for v in bbox]
            x1, y1 = max(0, x1 - margin_px), max(0, y1 - margin_px)
            x2, y2 = min(W, x2 + margin_px), min(H, y2 + margin_px)
            if x2 <= x1 or y2 <= y1:
                continue
            roi_shape = cv2.dilate(shape[y1:y2, x1:x2], k)
            outside = roi_shape == 0
            cur = cleaned_bgr[y1:y2, x1:x2]
            org = original_bgr[y1:y2, x1:x2]
            changed = np.any(cur[..., :3] != org[..., :3], axis=2) & outside
            n = int(np.count_nonzero(changed))
            if n:
                cur[changed] = org[changed]
                restored += n
        if restored:
            log_message(
                f"Restored {restored}px painted outside bubble shapes",
                verbose=verbose,
            )
    except Exception as e:  # never break the pipeline
        log_message(f"restore_outside_bubble_shape skipped: {e}", verbose=verbose)
    return restored
