"""Measure where the ORIGINAL text sat (centre + tilt) so the translation can be
drawn in the same place and at the same angle.

Used by the "Copy Bubble Text Position" / "Copy Outside Text Position"
options. Everything here is best-effort: any failure returns None and the
caller falls back to the normal placement, so a page never breaks.

Angle convention: degrees, positive = clockwise on screen (same as Skia's
canvas.rotate and the `rotation_deg` argument of render_text_skia).
"""

from typing import Any, Dict, Optional, Tuple

import cv2
import numpy as np
from PIL import Image

MIN_ELONGATION = 1.4  # block must be clearly wider than tall to trust its angle
MIN_ANGLE_DEG = 1.5  # ignore tiny tilts (measurement noise)
MAX_ANGLE_DEG = 45.0  # beyond this the text is vertical -> do not rotate
COLOR_DISTANCE = 70.0  # RGB distance still counted as "text colour"


def bbox_center(bbox) -> Optional[Tuple[float, float]]:
    """Centre of an (x1, y1, x2, y2) box in the same coordinate frame."""
    try:
        x1, y1, x2, y2 = [float(v) for v in bbox]
    except Exception:
        return None
    if x2 <= x1 or y2 <= y1:
        return None
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


def _text_pixel_mask(
    crop_rgb: np.ndarray,
    text_color_rgb: Optional[Tuple[int, int, int]],
    is_dark_text: bool,
) -> Optional[np.ndarray]:
    h, w = crop_rgb.shape[:2]
    if h < 4 or w < 4:
        return None
    mask = None
    if text_color_rgb is not None:
        diff = crop_rgb.astype(np.float32) - np.array(text_color_rgb, np.float32)
        dist = np.sqrt((diff**2).sum(axis=2))
        cand = (dist < COLOR_DISTANCE).astype(np.uint8) * 255
        frac = cand.mean() / 255.0
        if 0.002 < frac < 0.6:
            mask = cand
    if mask is None:
        gray = cv2.cvtColor(crop_rgb, cv2.COLOR_RGB2GRAY)
        _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        mask = (255 - otsu) if is_dark_text else otsu
    k = max(2, int(round(min(h, w) * 0.02)))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    # drop specks
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    min_area = max(6, int(0.0004 * h * w))
    keep = np.zeros_like(mask)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            keep[labels == i] = 255
    if keep.sum() == 0:
        return None
    return keep


def measure_text_geometry(
    crop: Image.Image,
    text_color_rgb: Optional[Tuple[int, int, int]] = None,
    is_dark_text: bool = True,
) -> Optional[Dict[str, Any]]:
    """Return {'center': (cx, cy), 'angle': deg, 'size': (w, h)} in CROP coords."""
    try:
        rgb = np.asarray(crop.convert("RGB"))
        mask = _text_pixel_mask(rgb, text_color_rgb, is_dark_text)
        if mask is None:
            return None
        ys, xs = np.where(mask > 0)
        if xs.size < 12:
            return None
        center = (
            (float(xs.min()) + float(xs.max()) + 1.0) / 2.0,
            (float(ys.min()) + float(ys.max()) + 1.0) / 2.0,
        )
        pts = np.column_stack([xs, ys]).astype(np.float32)
        hull = cv2.convexHull(pts)
        (_, _), (rw, rh), ang = cv2.minAreaRect(hull)
        # make `rw` the long side; angle then describes the long side direction
        if rw < rh:
            rw, rh = rh, rw
            ang += 90.0
        # normalise to (-90, 90]
        while ang > 90.0:
            ang -= 180.0
        while ang <= -90.0:
            ang += 180.0
        angle = 0.0
        if rh > 0 and (rw / rh) >= MIN_ELONGATION:
            if abs(ang) > 90.0 - 1e-6:
                ang = 0.0
            if abs(ang) <= MAX_ANGLE_DEG and abs(ang) >= MIN_ANGLE_DEG:
                angle = float(ang)
        return {
            "center": center,
            "angle": angle,
            "size": (float(xs.max() - xs.min() + 1), float(ys.max() - ys.min() + 1)),
        }
    except Exception:
        return None
