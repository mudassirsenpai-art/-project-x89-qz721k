import base64
import json
import re
from io import BytesIO
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np
from PIL import Image

from core.caching import get_cache
from core.config import TranslationConfig, calculate_reasoning_budget
from core.image.image_utils import cv2_to_pil, pil_to_cv2, process_bubble_image_cached
from core.image.ocr_detection import (
    extract_text_with_classic_paddleocr,
    extract_text_with_classic_paddleocr_v5,
    extract_text_with_manga_ocr,
    extract_text_with_paddle_ocr_vl,
)
from utils.endpoints import (
    call_anthropic_endpoint,
    call_deepseek_endpoint,
    call_gemini_endpoint,
    call_mimo_endpoint,
    call_moonshot_endpoint,
    call_openai_compatible_endpoint,
    call_openai_endpoint,
    call_openrouter_endpoint,
    call_xai_endpoint,
    call_zai_endpoint,
    openrouter_is_reasoning_model,
)
from utils.exceptions import TranslationError
from utils.logging import log_message
from utils.model_metadata import (
    anthropic_model_flags,
    get_gpt5_generation,
    get_max_tokens_cap,
    is_anthropic_model_family,
    is_anthropic_reasoning_model,
    is_deepseek_reasoning_model,
    is_gemini_3_model,
    is_gemini_25_flash_model,
    is_gemini_25_pro_model,
    is_gemma_model,
    is_google_model_family,
    is_google_reasoning_model,
    is_gpt5_chat_variant,
    is_gpt5_pro,
    is_gpt5_series,
    is_gpt56_virtual_pro,
    is_hy_mt2_model,
    is_mimo_reasoning_model,
    is_moonshot_k3_model,
    is_moonshot_reasoning_model,
    is_openai_compatible_reasoning_model,
    is_openai_model_family,
    is_openai_reasoning_model,
    is_rosetta_model,
    is_xai_reasoning_model,
    is_zai_reasoning_model,
    supports_gpt5_max_effort,
    supports_gpt5_xhigh_effort,
    supports_openai_original_image_detail,
    supports_xai_reasoning_parameter,
    supports_zai_reasoning_effort,
)
from utils.model_metadata import is_openai_reasoning_model as _is_openai_reasoning_meta

TRANSLATION_PATTERN = re.compile(
    r'^\s*(\d+)\s*:\s*"?\s*(.*?)\s*"?\s*(?=\s*\n\s*\d+\s*:|\s*$)',
    re.MULTILINE | re.DOTALL,
)

# ocr_method values that run entirely locally (no vision LLM call for the OCR
# step). These share two behaviors that vision-LLM OCR does not: (1) no
# full-page context image is attached, since these models only ever see the
# individual cropped text-element images, and (2) they never need the
# LLM-oriented OCR transcription prompt. Kept as one set so every ocr_method
# added here only needs updating in one place instead of two duplicated
# tuples.
LOCAL_OCR_METHODS = ("manga-ocr", "paddleocr-vl-1.6", "paddleocr-classic", "paddleocr-classic-v5")


def _build_system_prompt_ocr(
    input_language: Optional[str],
    reading_direction: str,
) -> str:
    lang_label = f"{input_language} " if input_language else ""
    direction = (
        "right-to-left"
        if (reading_direction or "rtl").lower() == "rtl"
        else "left-to-right"
    )

    return f"""
## ROLE
You are an expert manga OCR transcriber.

## OBJECTIVE
Your sole purpose is to accurately transcribe the original text from a series of provided images. You must not translate, interpret, or add commentary.

## CORE RULES
- **Reading Context:** The image crops are presented in a {direction} reading order. Do not reorder them.
- **Transcription Policy:** Preserve all original punctuation, ellipses, and casing. Collapse multi-line text into a single line, separated by a single space.
- **Ignore Policy:** Ignore all non-text visual elements (borders, tails, watermarks, etc.).
- **Language Focus:** Transcribe only the original {lang_label}text.
- **Ruby/Furigana Policy:** If small phonetic characters (ruby/furigana) are present, you must ignore them and transcribe only the main, larger base text.
- **Visual Emphasis Policy:** If the source text is visually emphasized (bold, slanted, etc.), you must mirror that emphasis in your transcription using markdown-style markers: `*italic*` for slanted text, `**bold**` for bold text, `***bold-italic***` for both.
- **Quotes:** Do not wrap the transcribed text in quotation marks unless they are explicitly present in the image.
- **Edge Cases:**
  - If an image contains standalone periods/ellipses, you must return it exactly as it appears.
  - If text is indecipherable, you must return the exact token: `[OCR FAILED]`.

## OUTPUT SCHEMA
- You must return your response as a single numbered list with exactly one line per input image.
- The numbering must correspond to the input image order (1, 2, 3...).
- The format must be `i: <transcribed {lang_label}text>` where `i` is the input image number.
- Do not include section headers, explanations, or formatting outside of this list.
"""  # noqa


def _format_previous_context_prompt_note(
    previous_context_image_count: int,
    previous_context_text_count: int,
    image_order: str,
) -> str:
    has_images = previous_context_image_count > 0
    has_text = previous_context_text_count > 0

    if has_images and has_text:
        return (
            f" {previous_context_image_count} previous source page image(s) are "
            "attached as visual reference, and transcribed text from "
            f"{previous_context_text_count} previous source page(s) is provided "
            "in `## PREVIOUS PAGE TRANSCRIPTS`. Image order: "
            f"{image_order}. Use this previous-page context only as narrative "
            "reference; do not transcribe, translate, or renumber previous-page "
            "material."
        )

    if has_images:
        return (
            f" {previous_context_image_count} previous source page image(s) "
            f"are attached as reference. Image order: {image_order}."
        )

    if has_text:
        return (
            f" Transcribed text from {previous_context_text_count} previous "
            "source page(s) is provided in `## PREVIOUS PAGE TRANSCRIPTS` "
            "as narrative reference only — do not translate or renumber it."
        )

    return ""


def _build_system_prompt_translation(
    output_language: str,
    mode: str,
    reading_direction: str,
    full_page_context: bool = False,
    previous_context_image_count: int = 0,
    previous_context_text_count: int = 0,
) -> str:
    direction = (
        "right-to-left"
        if (reading_direction or "rtl").lower() == "rtl"
        else "left-to-right"
    )
    input_type = "transcriptions" if mode == "two-step" else "image crops"

    cohesion_visual = (
        " Refer to the full-page image to resolve ambiguous context."
        if full_page_context
        else ""
    )

    if mode == "two-step":
        edge_cases = """- **Edge Cases:**
  - If an input line contains standalone periods/ellipses, you must return it exactly as it appears.
  - If an input line is the exact token `[OCR FAILED]`, you must output it unchanged."""
    else:
        edge_cases = """- **Edge Cases:**
  - If an image contains standalone periods/ellipses, you must return it exactly as it appears.
  - If text is indecipherable, you must return the exact token: `[OCR FAILED]`."""

    previous_context_rule = ""
    if previous_context_image_count > 0 and previous_context_text_count > 0:
        previous_context_rule = """
- **Previous Page Context:** Earlier source-page images and transcripts are visual/narrative context only; do not transcribe, translate, number, or count them. Use them to maintain consistency:
  - **Proper Nouns:** Keep character names, place names, organizations, technique/skill/title names, honorifics, and stylized terms consistent with established usage.
  - **Character Voice:** Preserve each character's established voice, register, and pronoun choices.
  - **Referents:** Disambiguate callbacks, ongoing beats, or unclear references using prior visuals and dialogue."""  # noqa
    elif previous_context_image_count > 0:
        previous_context_rule = """
- **Previous Page Reference:** Earlier source pages are visual/narrative context only — do not transcribe, translate, number, or count them. Use them to maintain consistency:
  - **Proper Nouns:** Keep character names, place names, organizations, technique/skill/title names, honorifics, and stylized terms spelled exactly as they appeared previously.
  - **Character Voice:** Preserve each character's established voice, register, and pronoun choices.
  - **Referents:** Disambiguate callbacks, ongoing beats, or unclear references using prior context."""  # noqa
    elif previous_context_text_count > 0:
        previous_context_rule = """
- **Previous Page Transcripts:** Earlier source-page transcribed text is provided as narrative context only — do not translate, number, or count it. Use it to maintain consistency:
  - **Proper Nouns:** Keep character names, place names, organizations, technique/skill/title names, honorifics, and stylized terms aligned with their established usage.
  - **Character Voice:** Preserve each character's established voice, register, and pronoun choices.
  - **Referents:** Disambiguate callbacks, ongoing beats, or unclear references using prior dialogue."""  # noqa

    core_rules = f"""
## CORE RULES
- **Reading Context:** The {input_type} are presented in a {direction} reading order. Do not reorder them.
- **Cohesion:** Treat the input lines as a continuous narrative. Ensure the translation flows logically and naturally as a cohesive whole.{cohesion_visual}
- **Fidelity:** Focus on intent; translate functionally rather than literally.
- **Conciseness:** Keep translations idiomatic and concise.
- **Emphasis:** If the source text is visually emphasized (bold, slanted, etc.), mirror that emphasis using the STYLING GUIDE.
- **Punctuation:** Replace ellipses (e.g., "…") with consecutive periods (e.g., "...").
- **Quotes:** Do not wrap the translated text in quotation marks unless they are explicitly present in the source text.
- **Text Types:**
  - **Spoken Dialogue/Internal Monologue:** Translate naturally, matching the character's personality.
  - **Narration:** Translate neutrally without special styling.
  - **Audible SFX:** Translate physical sounds (Giongo) as standard onomatopoeia.
  - **Mimetic FX:** Translate atmospheric text (Gitaigo) or silent actions as descriptive verbs or adjectives. Do not add a period at the end.
{edge_cases}{previous_context_rule}
"""  # noqa

    shared_components = f"""
## ROLE
You are a professional manga localization translator and editor.

## OBJECTIVE
Your goal is to produce natural-sounding, high-quality translations in {output_language} that are faithful to the original source's meaning, tone, and visual emphasis.

## STYLING GUIDE
You must use the following markdown-style markers to convey emphasis:
- `*italic*`: Used for onomatopoeias, thoughts, flashbacks, distant sounds, or dialogue mediated by a device (e.g., phone, radio).
- `**bold**`: Used for sound effects (SFX), shouting, timestamps, or individual emphatic words.
- `***bold-italic***`: Used for extremely loud sounds or dialogue that also meets the criteria for italics (e.g., shouting over a radio).

{core_rules}
"""  # noqa

    if mode == "one-step":
        output_schema = f"""
## OUTPUT SCHEMA
- You must return your response as a single numbered list with exactly one line per input image.
- The numbering must correspond to the input image order (1, 2, 3...).
- For each item, provide both transcription and translation in the format:
  `i: <transcribed text> || <translated {output_language} text>` where `i` is the input image number.
- **Outside-bubble sound effects (SFX):** For items that are outside-speech-bubble text (OSB) AND are a sound effect (Audible SFX), prefix the translated portion with a `[SFX]` marker, e.g. `i: <transcribed text> || [SFX] <translated {output_language} text>`. Only use this marker for outside-bubble sound effects — never for in-bubble dialogue/narration or for OSB items that are not sound effects (e.g. captions, narration, mimetic FX describing an action).
- **Do not forget the `[SFX]` marker:** Before finalizing each line, re-check whether it is an outside-bubble sound effect. If it is, the `[SFX]` marker is mandatory — never omit it, even in a long batch. Apply this check independently to every line, not just the first few.
- **Non-story OSB text (SKIP):** For OSB items that are NOT part of the story — advertisements/promo banners (e.g. "new volume on sale"), series-title or chapter-title logos, author/publisher credits, copyright lines, URLs, QR codes, watermarks — prefix the translated portion with a `[SKIP]` marker (same position/format as `[SFX]`; keep your transcription as-is). These are left untouched on the page. Never use `[SKIP]` for dialogue, narration, captions or story SFX.
- Do not include section headers, explanations, or formatting outside of this list.
"""
    elif mode == "two-step":
        output_schema = f"""
## OUTPUT SCHEMA
- You must return your response as a single numbered list with exactly one line per input text.
- The numbering must correspond to the input order (1, 2, 3...).
- The format must be `i: <translated {output_language} text>` where `i` is the input text number.
- **Outside-bubble sound effects (SFX):** For items that are outside-speech-bubble text (OSB) AND are a sound effect (Audible SFX), prefix the translated text with a `[SFX]` marker, e.g. `i: [SFX] <translated {output_language} text>`. Only use this marker for outside-bubble sound effects — never for in-bubble dialogue/narration or for OSB items that are not sound effects (e.g. captions, narration, mimetic FX describing an action).
- **Do not forget the `[SFX]` marker:** Before finalizing each line, re-check whether it is an outside-bubble sound effect. If it is, the `[SFX]` marker is mandatory — never omit it, even in a long batch. Apply this check independently to every line, not just the first few.
- **Non-story OSB text (SKIP):** For OSB items that are NOT part of the story — advertisements/promo banners (e.g. "new volume on sale"), series-title or chapter-title logos, author/publisher credits, copyright lines, URLs, QR codes, watermarks — prefix the translated portion with a `[SKIP]` marker (same position/format as `[SFX]`; keep your transcription as-is). These are left untouched on the page. Never use `[SKIP]` for dialogue, narration, captions or story SFX.
- Do not include section headers, explanations, or formatting outside of this list.
"""  # noqa
    else:
        raise ValueError(
            f"Invalid mode '{mode}' specified for translation system prompt."
        )

    return shared_components + output_schema


def _is_reasoning_model_google(model_name: str) -> bool:
    """Check if a Google model is reasoning-capable."""
    return is_google_reasoning_model(model_name)


def _is_reasoning_model_openai(model_name: str) -> bool:
    """Check if an OpenAI model is reasoning-capable."""
    return _is_openai_reasoning_meta(model_name)


def _is_reasoning_model_anthropic(model_name: str) -> bool:
    """Check if an Anthropic model is reasoning-capable."""
    return is_anthropic_reasoning_model(model_name)


def _add_media_resolution_to_part(
    part: Dict[str, Any],
    media_resolution_ui: str,
) -> Dict[str, Any]:
    """
    Add media_resolution to an inline_data part.

    Args:
        part: Part dictionary with inline_data
        media_resolution_ui: UI format media resolution ("auto"/"high"/"medium"/"low")

    Returns:
        Part dictionary with media_resolution added
    """
    if "inline_data" not in part:
        return part

    media_resolution_mapping = {
        "auto": "MEDIA_RESOLUTION_UNSPECIFIED",
        "high": "MEDIA_RESOLUTION_HIGH",
        "medium": "MEDIA_RESOLUTION_MEDIUM",
        "low": "MEDIA_RESOLUTION_LOW",
    }
    backend_media_resolution = media_resolution_mapping.get(
        media_resolution_ui.lower(), "MEDIA_RESOLUTION_UNSPECIFIED"
    )

    result = part.copy()
    result["media_resolution"] = {"level": backend_media_resolution}
    return result


def _build_generation_config(
    provider: str,
    model_name: str,
    config: TranslationConfig,
    debug: bool = False,
    prompt_cache_key: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Build provider-specific generation config dictionary.

    Centralizes logic for:
    - Base parameters (temperature, top_p, top_k)
    - Provider-specific parameter names and constraints
    - Reasoning model detection and token limits
    - Special features (thinking, reasoning_effort, etc.)

    Args:
        provider: Provider name (Google, OpenAI, Anthropic, SpaceXAI, OpenRouter, OpenAI-Compatible)
        model_name: Model identifier
        config: TranslationConfig with all settings
        debug: Whether to log debug messages

    Returns:
        Dictionary with generation config parameters for the specific provider
    """
    temperature = config.temperature
    top_p = config.top_p
    top_k = config.top_k
    use_sampling = config.use_custom_sampling

    def normalize_image_detail() -> str:
        image_detail = (config.image_detail or "auto").lower()
        if image_detail not in ("auto", "original", "high", "low"):
            image_detail = "auto"
        if image_detail == "original" and not supports_openai_original_image_detail(
            model_name
        ):
            image_detail = "high"
        return image_detail

    if config.max_tokens is not None:
        max_tokens_value = config.max_tokens
    else:
        is_reasoning = False
        if provider == "Google":
            is_reasoning = _is_reasoning_model_google(model_name)
        elif provider == "OpenAI":
            is_reasoning = _is_reasoning_model_openai(model_name)
        elif provider == "Anthropic":
            is_reasoning = _is_reasoning_model_anthropic(model_name)
        elif provider == "SpaceXAI":
            is_reasoning = is_xai_reasoning_model(model_name)
        elif provider == "OpenRouter":
            is_reasoning = openrouter_is_reasoning_model(model_name, debug)
        elif provider == "OpenAI-Compatible":
            is_reasoning = is_openai_compatible_reasoning_model(model_name)
        elif provider == "DeepSeek":
            is_reasoning = is_deepseek_reasoning_model(model_name)
        elif provider == "Z.ai":
            is_reasoning = is_zai_reasoning_model(model_name)
        elif provider == "Moonshot AI":
            is_reasoning = is_moonshot_reasoning_model(model_name)
        elif provider == "Xiaomi MiMo":
            is_reasoning = is_mimo_reasoning_model(model_name)
        max_tokens_value = 16384 if is_reasoning else 4096

    max_tokens_cap = get_max_tokens_cap(provider, model_name)
    if max_tokens_cap is not None and max_tokens_value > max_tokens_cap:
        max_tokens_value = max_tokens_cap

    if provider == "Google":
        is_gemini_3 = is_gemini_3_model(model_name)
        is_gemma = is_gemma_model(model_name)
        generation_config = {
            "maxOutputTokens": max_tokens_value,
        }
        if use_sampling:
            generation_config.update(
                {
                    "temperature": temperature,
                    "topP": top_p,
                    "topK": top_k,
                }
            )
        if not is_gemini_3:
            media_resolution_mapping = {
                "auto": "MEDIA_RESOLUTION_UNSPECIFIED",
                "high": "MEDIA_RESOLUTION_HIGH",
                "medium": "MEDIA_RESOLUTION_MEDIUM",
                "low": "MEDIA_RESOLUTION_LOW",
            }
            backend_media_resolution = media_resolution_mapping.get(
                config.media_resolution.lower(), "MEDIA_RESOLUTION_UNSPECIFIED"
            )
            generation_config["media_resolution"] = backend_media_resolution
        if is_gemini_3 or is_gemma:
            reasoning_effort = config.reasoning_effort or "medium"
            generation_config["thinkingConfig"] = {"thinkingLevel": reasoning_effort}
            log_message(
                f"Using reasoning effort '{reasoning_effort}' for {model_name}",
                verbose=debug,
            )
        elif _is_reasoning_model_google(model_name) and not is_gemini_3:
            reasoning_effort = config.reasoning_effort or "auto"
            is_flash = is_gemini_25_flash_model(model_name)
            is_pro = is_gemini_25_pro_model(model_name)
            if reasoning_effort == "none":
                if is_flash:
                    generation_config["thinkingConfig"] = {"thinkingBudget": 0}
                    log_message(f"Disabled reasoning for {model_name}", verbose=debug)
                elif is_pro:
                    generation_config["thinkingConfig"] = {"thinkingBudget": 128}
                    log_message(
                        f"Using 'none' reasoning effort (thinkingBudget: 128) for {model_name}",
                        verbose=debug,
                    )
                else:
                    log_message(
                        f"Warning: 'none' not supported for {model_name}, using 'auto'",
                        verbose=debug,
                    )
            elif reasoning_effort == "auto":
                log_message(
                    f"Using auto reasoning allocation for {model_name}", verbose=debug
                )
            else:
                thinking_budget = calculate_reasoning_budget(
                    max_tokens_value, reasoning_effort
                )
                generation_config["thinkingConfig"] = {
                    "thinkingBudget": thinking_budget
                }
                log_message(
                    f"Using reasoning effort '{reasoning_effort}' (budget: {thinking_budget} tokens) for {model_name}",
                    verbose=debug,
                )
        return generation_config

    elif provider == "OpenAI":
        generation_config = {
            "max_output_tokens": max_tokens_value,
        }
        if use_sampling:
            generation_config.update(
                {
                    "temperature": temperature,
                    "top_p": top_p,
                }
            )  # top_k not supported by OpenAI
        generation_config["image_detail"] = normalize_image_detail()
        is_chat = is_gpt5_chat_variant(model_name)
        if _is_reasoning_model_openai(model_name) and not is_chat:
            gen = get_gpt5_generation(model_name)
            reasoning_effort = config.reasoning_effort or (
                "high" if is_gpt5_pro(model_name) and gen == "5" else "medium"
            )
            effort = reasoning_effort
            if effort == "max" and not supports_gpt5_max_effort(model_name):
                effort = "xhigh" if supports_gpt5_xhigh_effort(model_name) else "high"
            if effort == "xhigh" and not supports_gpt5_xhigh_effort(model_name):
                effort = "high"
            none_capable = gen is not None and gen != "5"
            if none_capable or effort != "none":
                generation_config["reasoning_effort"] = effort
            if is_gpt56_virtual_pro(model_name):
                generation_config["reasoning_mode"] = "pro"
        if is_gpt5_series(model_name) and not is_gpt5_chat_variant(model_name):
            generation_config["verbosity"] = config.verbosity or "low"
        return generation_config

    elif provider == "Anthropic":
        is_reasoning = _is_reasoning_model_anthropic(model_name)
        anthropic_flags = anthropic_model_flags(model_name)
        generation_config = {
            "max_tokens": max_tokens_value,
            "_metadata": dict(anthropic_flags),
        }
        if use_sampling:
            generation_config.update(
                {
                    "temperature": min(temperature, 1.0),
                    "top_k": top_k,
                }
            )
        if is_reasoning:
            omit_thinking = anthropic_flags.get("is_claude_omit_thinking", False)
            adaptive_default = anthropic_flags.get("is_claude_adaptive_default", False)
            reasoning_effort = config.reasoning_effort or (
                "auto" if adaptive_default else "none"
            )
            generation_config["reasoning_effort"] = reasoning_effort
            if adaptive_default and not omit_thinking:
                generation_config["thinking_type"] = (
                    "disabled" if reasoning_effort == "none" else "adaptive"
                )
            elif anthropic_flags.get("is_claude_effort_max") and not omit_thinking:
                if reasoning_effort == "auto":
                    generation_config["thinking_type"] = "adaptive"
            elif not omit_thinking:
                if reasoning_effort != "none":
                    generation_config["thinking_type"] = "enabled"
        if anthropic_flags and config.effort:
            generation_config["effort"] = config.effort
        return generation_config

    elif provider == "SpaceXAI":
        generation_config = {
            "max_tokens": max_tokens_value,
            "media_resolution": config.media_resolution,
        }
        if prompt_cache_key:
            generation_config["prompt_cache_key"] = prompt_cache_key
        if use_sampling:
            generation_config.update(
                {
                    "temperature": temperature,
                    "top_p": top_p,
                }
            )
        if supports_xai_reasoning_parameter(model_name):
            reasoning_effort = config.reasoning_effort or "medium"
            generation_config["reasoning_effort"] = reasoning_effort
        return generation_config

    elif provider == "DeepSeek":
        is_reasoning = is_deepseek_reasoning_model(model_name)
        generation_config = {
            "max_tokens": max_tokens_value,
        }
        if use_sampling:
            generation_config.update(
                {
                    "temperature": temperature,
                    "top_p": top_p,
                }
            )
        if is_reasoning:
            reasoning_effort = config.reasoning_effort or "high"
            thinking_type = "enabled" if reasoning_effort != "none" else "disabled"
            generation_config["thinking"] = {"type": thinking_type}
            if thinking_type == "enabled":
                generation_config["reasoning_effort"] = reasoning_effort
        return generation_config

    elif provider == "Z.ai":
        is_reasoning = is_zai_reasoning_model(model_name)
        generation_config = {
            "max_tokens": max_tokens_value,
        }
        if use_sampling:
            generation_config.update(
                {
                    "temperature": temperature,
                    "top_p": top_p,
                }
            )
        if is_reasoning:
            reasoning_effort = config.reasoning_effort or (
                "high" if supports_zai_reasoning_effort(model_name) else "auto"
            )
            thinking_type = "enabled" if reasoning_effort != "none" else "disabled"
            generation_config["thinking"] = {"type": thinking_type}
            if thinking_type == "enabled" and supports_zai_reasoning_effort(model_name):
                generation_config["reasoning_effort"] = reasoning_effort
        return generation_config

    elif provider == "Moonshot AI":
        is_reasoning = is_moonshot_reasoning_model(model_name)

        generation_config = {
            "max_tokens": max_tokens_value,
        }
        if use_sampling:
            generation_config.update(
                {
                    "temperature": min(temperature, 1.0),
                    "top_p": top_p,
                }
            )

        if is_reasoning:
            if is_moonshot_k3_model(model_name):
                generation_config["reasoning_effort"] = "max"
            else:
                reasoning_effort = config.reasoning_effort or "auto"
                thinking_type = "enabled" if reasoning_effort != "none" else "disabled"
                generation_config["thinking"] = {"type": thinking_type}
        return generation_config

    elif provider == "Xiaomi MiMo":
        is_reasoning = is_mimo_reasoning_model(model_name)

        generation_config = {
            "max_tokens": max_tokens_value,
        }
        if use_sampling:
            generation_config.update(
                {
                    "temperature": min(temperature, 1.0),
                    "top_p": top_p,
                }
            )

        if is_reasoning:
            reasoning_effort = config.reasoning_effort or "auto"
            thinking_type = "enabled" if reasoning_effort != "none" else "disabled"
            generation_config["thinking"] = {"type": thinking_type}
        return generation_config

    elif provider == "OpenRouter":
        model_lower = (model_name or "").lower()
        is_openai_model = is_openai_model_family(model_name)
        is_anthropic_model = is_anthropic_model_family(model_name)
        is_grok_model = "grok-4" in model_lower
        is_gemini_3 = is_gemini_3_model(model_name)
        is_google_model = is_google_model_family(model_name)

        generation_config = {"max_tokens": max_tokens_value}
        if use_sampling:
            generation_config.update(
                {
                    "temperature": temperature,
                    "top_p": top_p if not is_anthropic_model else None,
                    "top_k": top_k,
                }
            )
        if is_openai_model:
            generation_config["image_detail"] = normalize_image_detail()

        is_openai_reasoning = is_openai_model and is_openai_reasoning_model(model_name)
        is_gpt5_model = is_openai_model and is_gpt5_series(model_name)
        is_gpt5_1 = is_openai_model and "gpt-5.1" in model_lower
        is_gpt5 = is_openai_model and "gpt-5" in model_lower and not is_gpt5_1
        is_anthropic_reasoning = is_anthropic_reasoning_model(model_name)
        # OpenRouter Grok metadata omit explicit reasoning tags in name
        is_grok_reasoning = is_grok_model and "non-reasoning" not in model_lower

        anthropic_flags = anthropic_model_flags(model_name)
        generation_config["_metadata"] = {
            "is_openai_model": is_openai_model,
            "is_anthropic_model": is_anthropic_model,
            "is_grok_model": is_grok_model,
            "is_gemini_3": is_gemini_3,
            "is_google_model": is_google_model,
            "is_openai_reasoning": is_openai_reasoning,
            "is_anthropic_reasoning": is_anthropic_reasoning,
            "is_grok_reasoning": is_grok_reasoning,
            "is_gpt5_1": is_gpt5_1,
            "is_gpt5": is_gpt5,
            "is_gpt5_model": is_gpt5_model,
            **anthropic_flags,
        }

        if is_openai_reasoning or is_anthropic_reasoning or is_grok_reasoning:
            if is_anthropic_reasoning:
                is_claude_adaptive_default = anthropic_flags.get(
                    "is_claude_adaptive_default", False
                )
                is_claude_46 = (
                    anthropic_flags.get("is_claude_effort_max")
                    and not anthropic_flags.get("is_claude_effort_xhigh")
                    and not is_claude_adaptive_default
                )
                reasoning_effort = config.reasoning_effort or (
                    "auto" if (is_claude_46 or is_claude_adaptive_default) else "none"
                )
                generation_config["reasoning_effort"] = reasoning_effort
            elif is_gpt5_1:
                generation_config["reasoning_effort"] = config.reasoning_effort
            elif config.reasoning_effort and config.reasoning_effort != "none":
                generation_config["reasoning_effort"] = config.reasoning_effort
        elif is_google_model:
            if config.reasoning_effort:
                generation_config["reasoning_effort"] = config.reasoning_effort

        if anthropic_flags and config.effort:
            generation_config["effort"] = config.effort

        # GPT-5 series verbosity
        if is_gpt5_model and not is_gpt5_chat_variant(model_name):
            generation_config["verbosity"] = config.verbosity or "low"

        return generation_config

    elif provider == "OpenAI-Compatible":
        generation_config = {"max_tokens": max_tokens_value}
        if use_sampling:
            generation_config["temperature"] = temperature
            generation_config["top_p"] = top_p
            if top_k is not None:
                generation_config["top_k"] = top_k
        return generation_config

    else:
        raise TranslationError(f"Unknown provider for generation config: {provider}")


def _call_llm_endpoint(
    config: TranslationConfig,
    parts: List[Dict[str, Any]],
    prompt_text: str,
    debug: bool = False,
    system_prompt: Optional[str] = None,
    prompt_cache_key: Optional[str] = None,
) -> Optional[str]:
    """Internal helper to dispatch API calls based on provider."""
    provider = config.provider
    model_name = config.model_name
    api_parts = parts + [{"text": prompt_text}]
    coordinator = getattr(config, "request_coordinator", None)
    if coordinator is not None and not coordinator.in_slot():
        return coordinator.run(
            _call_llm_endpoint,
            config,
            parts,
            prompt_text,
            debug,
            system_prompt,
            prompt_cache_key,
        )

    try:
        if provider == "Google":
            api_key = config.google_api_key
            if not api_key:
                raise TranslationError("Google API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_gemini_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
                enable_code_execution=config.enable_code_execution,
            )
        elif provider == "OpenAI":
            api_key = config.openai_api_key
            if not api_key:
                raise TranslationError("OpenAI API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_openai_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
            )
        elif provider == "Anthropic":
            api_key = config.anthropic_api_key
            if not api_key:
                raise TranslationError("Anthropic API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_anthropic_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
            )
        elif provider == "SpaceXAI":
            api_key = config.xai_api_key
            if not api_key:
                raise TranslationError("SpaceXAI API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug, prompt_cache_key=prompt_cache_key
            )
            return call_xai_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
            )
        elif provider == "DeepSeek":
            api_key = config.deepseek_api_key
            if not api_key:
                raise TranslationError("DeepSeek API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_deepseek_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
            )
        elif provider == "Z.ai":
            api_key = config.zai_api_key
            if not api_key:
                raise TranslationError("Z.ai API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_zai_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
            )
        elif provider == "Moonshot AI":
            api_key = config.moonshot_api_key
            if not api_key:
                raise TranslationError("Moonshot API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_moonshot_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
            )
        elif provider == "Xiaomi MiMo":
            api_key = config.mimo_api_key
            if not api_key:
                raise TranslationError("MiMo API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_mimo_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
            )
        elif provider == "OpenRouter":
            api_key = config.openrouter_api_key
            if not api_key:
                raise TranslationError("OpenRouter API key is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_openrouter_endpoint(
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
                enable_web_search=config.enable_web_search,
            )
        elif provider == "OpenAI-Compatible":
            base_url = config.openai_compatible_url
            api_key = config.openai_compatible_api_key  # Optional
            if not base_url:
                raise TranslationError("OpenAI-Compatible URL is missing.")
            generation_config = _build_generation_config(
                provider, model_name, config, debug
            )
            return call_openai_compatible_endpoint(
                base_url=base_url,
                api_key=api_key,
                model_name=model_name,
                parts=api_parts,
                generation_config=generation_config,
                system_prompt=system_prompt,
                debug=debug,
            )
        else:
            raise TranslationError(
                f"Unknown translation provider specified: {provider}"
            )

    except (ValueError, RuntimeError):
        raise


def _parse_llm_response_unified(
    response_text: Optional[str],
    total_elements: int,
    provider: str,
    debug: bool = False,
) -> List[str]:
    """Parse LLM response with a single numbered list."""
    if response_text is None:
        log_message(f"API call failed: {provider} returned None", always_print=True)
        raise TranslationError(f"{provider}: API failed (returned None)")
    elif response_text == "":
        log_message(f"API call returned empty response: {provider}", always_print=True)
        raise TranslationError(f"{provider}: Empty response")

    try:
        log_message(
            f"Parsing {provider} unified response: {len(response_text)} chars",
            verbose=debug,
        )
        log_message(f"Raw response:\n---\n{response_text}\n---", always_print=True)

        # Pattern matches "1: text" or "1. text" or "1 text" etc.
        pattern = re.compile(
            r'^\s*(\d+)\s*[:.]\s*"?\s*(.*?)\s*"?\s*(?=\s*\n\s*\d+\s*[:.]|\s*$)',
            re.MULTILINE | re.DOTALL,
        )

        matches = pattern.findall(response_text)
        result_dict = {}
        dropped_items = []

        for num_str, text in matches:
            try:
                num = int(num_str)
                if 1 <= num <= total_elements:
                    result_dict[num] = text.strip()
                else:
                    dropped_items.append((num, text.strip()))
            except ValueError:
                continue

        if dropped_items:
            log_message(
                f"WARNING: {provider} OCR/translation returned "
                f"{len(dropped_items)} item(s) numbered beyond the "
                f"{total_elements} detected bubble(s)/region(s) - these are "
                "being dropped, likely because bubble/text detection missed "
                "a real text region on this page: "
                + "; ".join(f"item {n}: '{t[:40]}'" for n, t in dropped_items),
                always_print=True,
            )

        final_list = []
        for i in range(1, total_elements + 1):
            if i in result_dict:
                final_list.append(result_dict[i])
            else:
                final_list.append(f"[{provider}: Missing item {i}]")

        log_message(
            f"Parsed {len(result_dict)} items from unified response (expected {total_elements})",
            verbose=debug,
        )
        return final_list

    except Exception as e:
        log_message(
            f"Failed to parse {provider} unified response: {str(e)}",
            always_print=True,
        )
        return [f"[{provider}: Parse error]"] * total_elements


# Leading marker, tolerant of: bold/italic wrappers (*, **, ***, _), extra
# internal whitespace inside the brackets ("[ SFX ]"), a trailing colon/dash
# separator the model sometimes adds ("[SFX]:", "[SFX] -"), and SFX written
# without brackets at all ("SFX:", "SFX -") since some providers drop the
# brackets under long context even when they still intend the tag.
_SFX_MARKER_PATTERN = re.compile(
    r"^\s*(?:[\*_]{1,3})?"
    r"(?:\[\s*(?:SFX|SKIP)\s*\]|SFX\b)"
    r"(?:[\*_]{1,3})?"
    r"\s*[:\-–—]?\s*",
    re.IGNORECASE,
)

# Fallback: catches a [SFX] marker anywhere near the start of the string, in
# case the model prefixed it with something else (e.g. stray punctuation)
# before the marker itself.
_SFX_MARKER_PATTERN_ANYWHERE = re.compile(r"\[\s*(?:SFX|SKIP)\s*\]", re.IGNORECASE)


def _strip_sfx_marker(text: str) -> Tuple[str, bool]:
    """Detect and strip a leading [SFX] marker from translated text.

    Returns a tuple of (clean_text, is_sfx). The marker is stripped from the
    returned text regardless of the caller's eventual use of the flag —
    callers that don't apply the flag (e.g. non-OSB items) simply discard it,
    ensuring a stray/mistaken [SFX] marker is never shown to the user.
    """
    if not text:
        return text, False

    match = _SFX_MARKER_PATTERN.match(text)
    if match:
        return text[match.end():].strip(), True

    # Model sometimes emits the bracketed marker but not flush at the start
    # (e.g. a stray leading dash/quote before it). Only take this path if the
    # marker shows up early in the string, so a marker mentioned mid-sentence
    # elsewhere isn't mistaken for the actual tag.
    stray_match = _SFX_MARKER_PATTERN_ANYWHERE.search(text[:20])
    if stray_match:
        cleaned = (text[:stray_match.start()] + text[stray_match.end():]).strip()
        return cleaned, True

    return text, False


def _prepare_images_for_ocr(
    images_b64: List[str], verbose: bool = False
) -> List[Optional[Image.Image]]:
    """Prepare base64-encoded images for OCR by decoding and converting to RGB.

    Args:
        images_b64: List of base64-encoded image strings
        verbose: Whether to print verbose logging

    Returns:
        List of PIL Images (or None for decode failures), all in RGB mode
    """
    pil_images = []
    for img_b64 in images_b64:
        try:
            image_data = base64.b64decode(img_b64)
            pil_img = Image.open(BytesIO(image_data))
            if pil_img.mode != "RGB":
                pil_img = pil_img.convert("RGB")
            pil_images.append(pil_img)
        except Exception as e:
            log_message(
                f"Failed to decode image for manga-ocr: {e}",
                always_print=True,
            )
            pil_images.append(None)
    return pil_images


def _format_ocr_results(
    extracted_texts: List[str],
    bubble_metadata: List[Dict[str, Any]],
) -> None:
    """Format and log OCR results.

    Args:
        extracted_texts: List of extracted text strings
        bubble_metadata: List of metadata dicts for text elements
        verbose: Whether to print verbose logging
    """
    log_lines = []

    for i, text in enumerate(extracted_texts):
        metadata = bubble_metadata[i] if i < len(bubble_metadata) else {}
        is_osb = metadata.get("is_outside_text", False)
        prefix = f"{i + 1}"
        type_label = "[OSB]" if is_osb else "[Bubble]"

        log_lines.append(f"{prefix}: {type_label} {text}")

    if log_lines:
        log_message(
            f"Raw OCR output:\n---\n{chr(10).join(log_lines)}\n---",
            always_print=True,
        )


def _check_ocr_failure(texts: List[str], provider: Optional[str] = None) -> bool:
    """Check if all OCR results indicate failure.

    Args:
        texts: List of extracted text strings
        provider: Optional provider name for LLM OCR failure detection

    Returns:
        True if all texts indicate failure, False otherwise
    """
    if not texts:
        return True

    if provider:
        for text in texts:
            if f"[{provider}-OCR:" not in text:
                return False
        return True
    else:
        return all(text == "[OCR FAILED]" for text in texts)


def _format_previous_context_texts(
    previous_context_texts: Optional[List[List[str]]],
) -> str:
    """Format previous-page OCR transcripts as a labeled context block.

    Pages are listed oldest-to-newest (matching the previous-image convention).
    Empty/failed entries are omitted, and the section is suppressed entirely
    when no usable transcripts remain.
    """
    if not previous_context_texts:
        return ""

    page_blocks = []
    for page_index, page_texts in enumerate(previous_context_texts, start=1):
        if not page_texts:
            continue
        lines = []
        for idx, text in enumerate(page_texts, start=1):
            cleaned = (text or "").strip()
            if not cleaned or cleaned == "[OCR FAILED]":
                continue
            lines.append(f"{idx}: {cleaned}")
        if not lines:
            continue
        page_blocks.append(f"### Previous Page {page_index}\n" + "\n".join(lines))

    if not page_blocks:
        return ""

    return (
        "\n## PREVIOUS PAGE TRANSCRIPTS\n"
        "Listed oldest-to-newest. These are reference only — do not translate or renumber.\n"
        + "\n\n".join(page_blocks)
        + "\n"
    )


def _format_special_instructions(config: TranslationConfig) -> str:
    """Format user's special instructions section for prompts.

    Args:
        config: TranslationConfig with special_instructions

    Returns:
        Formatted special instructions string (empty if none)
    """
    if config.special_instructions and config.special_instructions.strip():
        return f"""

## SPECIAL INSTRUCTIONS
{config.special_instructions.strip()}
"""
    return ""


def _build_rosetta_instruction(
    output_language: str,
    special_instructions: Optional[str] = None,
) -> str:
    """Build instruction prompt for YanoljaNEXT Rosetta translation models.

    Follows the Rosetta chat template format: concise instruction with target
    language, context, tone, optional glossary, and output format.
    Special instructions are mapped to the Glossary field.
    """
    instruction = (
        f"Translate the user's text to {output_language}. "
        f"Keep the JSON structure and keys.\n"
        f"Context: Manga dialogue, sound effects, and narration.\n"
        f"Tone: Natural-sounding manga localization"
    )

    if special_instructions and special_instructions.strip():
        glossary_lines = []
        for line in special_instructions.strip().splitlines():
            line = line.strip()
            if line:
                entry = line if line.startswith("- ") else f"- {line}"
                glossary_lines.append(entry)
        if glossary_lines:
            instruction += "\nGlossary:\n" + "\n".join(glossary_lines)

    instruction += (
        "\nOutput format: JSON\n"
        "Provide the final translation immediately without any other text."
    )
    return instruction


def _build_rosetta_source_prompt(extracted_texts: List[str]) -> str:
    """Format OCR texts as JSON for Rosetta models.

    Returns a JSON object with string keys "1", "2", etc.
    """
    data = {str(i + 1): text for i, text in enumerate(extracted_texts)}
    return json.dumps(data, ensure_ascii=False)


def _parse_rosetta_response(
    response_text: Optional[str],
    total_elements: int,
    provider: str,
    debug: bool = False,
) -> List[str]:
    """Parse JSON response from a Rosetta (or Hy-MT2) model.

    Falls back to _parse_llm_response_unified if JSON parsing fails.
    """
    if response_text is None:
        raise TranslationError(f"{provider}: API failed (returned None)")
    if response_text == "":
        raise TranslationError(f"{provider}: Empty response")

    log_message(f"Raw response:\n---\n{response_text}\n---", always_print=True)

    # Strip markdown code fences if present
    cleaned = response_text.strip()
    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()

    try:
        parsed = json.loads(cleaned)
        if isinstance(parsed, dict):
            result = []
            for i in range(1, total_elements + 1):
                val = parsed.get(str(i))
                if val is not None:
                    result.append(str(val).strip())
                else:
                    result.append(f"[{provider}: Missing item {i}]")
            log_message(
                f"Parsed {len(parsed)} items from JSON (expected {total_elements})",
                verbose=debug,
            )
            return result
    except (json.JSONDecodeError, TypeError):
        log_message(
            "JSON response invalid, falling back to numbered-list parser",
            verbose=debug,
        )

    return _parse_llm_response_unified(response_text, total_elements, provider, debug)


def _build_hy_mt2_prompt(
    output_language: str,
    extracted_texts: List[str],
    special_instructions: Optional[str] = None,
) -> str:
    """Build user-only prompt for Hy-MT2 (no system prompt per model card).

    Follows the card's default/terminology templates; source is JSON for multi-bubble.
    """
    source_data = json.dumps(
        {str(i + 1): text for i, text in enumerate(extracted_texts)},
        ensure_ascii=False,
    )

    prompt = ""
    if special_instructions and special_instructions.strip():
        term_lines = []
        for line in special_instructions.strip().splitlines():
            line = line.strip().removeprefix("- ").strip()
            if not line:
                continue
            if "->" in line:
                src, _, tgt = line.partition("->")
                term_lines.append(f"{src.strip()} translates to {tgt.strip()}")
            elif "=>" in line:
                src, _, tgt = line.partition("=>")
                term_lines.append(f"{src.strip()} translates to {tgt.strip()}")
            else:
                term_lines.append(line)
        if term_lines:
            prompt += (
                "Reference the following translations:\n"
                + "\n".join(term_lines)
                + "\n\n"
            )

    prompt += (
        f"Translate the following text into {output_language}. "
        f"Keep the JSON structure and keys. "
        f"Note that you should **only output the translated result without any "
        f"additional explanation**:\n\n"
        f"{source_data}"
    )
    return prompt


def _perform_manga_ocr(
    images_b64: List[str],
    bubble_metadata: List[Dict[str, Any]],
    debug: bool = False,
) -> List[str]:
    """Perform OCR using manga-ocr model.

    Args:
        images_b64: List of base64-encoded images
        bubble_metadata: List of metadata dicts for text elements
        debug: Whether to print verbose logging

    Returns:
        List of extracted text strings, or early return with failure list
    """
    total_elements = len(images_b64)
    log_message("Using manga-ocr for text extraction", verbose=debug)

    cache = get_cache()
    cache_key = cache.get_manga_ocr_cache_key(images_b64, total_elements)
    cached_ocr = cache.get_manga_ocr_result(cache_key)
    if cached_ocr is not None:
        if len(cached_ocr) == total_elements:
            log_message("Using cached manga-ocr results", verbose=debug)
            return cached_ocr
        log_message("Discarding manga-ocr cache due to length mismatch", verbose=debug)

    pil_images = _prepare_images_for_ocr(images_b64, verbose=debug)
    extracted_texts = extract_text_with_manga_ocr(pil_images, verbose=debug)

    formatted_texts = []
    for i, text in enumerate(extracted_texts):
        if text == "[OCR FAILED]" or not text:
            formatted_texts.append(text if text else "[OCR FAILED]")
        else:
            formatted_texts.append(text)

    extracted_texts = formatted_texts

    _format_ocr_results(extracted_texts, bubble_metadata)

    if len(extracted_texts) != total_elements:
        msg = (
            f"Warning: extracted_texts length ({len(extracted_texts)}) "
            f"doesn't match total_elements ({total_elements})"
        )
        log_message(msg, always_print=True)
        while len(extracted_texts) < total_elements:
            extracted_texts.append("[OCR FAILED]")
        extracted_texts = extracted_texts[:total_elements]

    if not extracted_texts:
        log_message("manga-ocr returned empty results", verbose=debug)
        failure_results = ["[OCR FAILED]"] * total_elements
        cache.set_manga_ocr_result(cache_key, failure_results, debug)
        return failure_results

    if _check_ocr_failure(extracted_texts):
        log_message("manga-ocr returned only failures", verbose=debug)
        cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
        return extracted_texts

    cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
    return extracted_texts


def _perform_paddle_ocr_vl(
    images_b64: List[str],
    bubble_metadata: List[Dict[str, Any]],
    debug: bool = False,
) -> List[str]:
    """Perform OCR using PaddleOCR-VL-1.6 model.

    Args:
        images_b64: List of base64-encoded images
        bubble_metadata: List of metadata dicts for text elements
        debug: Whether to print verbose logging

    Returns:
        List of extracted text strings, or early return with failure list
    """
    total_elements = len(images_b64)
    log_message("Using PaddleOCR-VL-1.6 for text extraction", verbose=debug)

    cache = get_cache()
    cache_key = cache.get_manga_ocr_cache_key(
        images_b64, total_elements, prefix="pocr16_"
    )
    cached_ocr = cache.get_manga_ocr_result(cache_key)
    if cached_ocr is not None:
        if len(cached_ocr) == total_elements:
            log_message("Using cached PaddleOCR-VL-1.6 results", verbose=debug)
            return cached_ocr
        log_message(
            "Discarding PaddleOCR-VL-1.6 cache due to length mismatch", verbose=debug
        )

    pil_images = _prepare_images_for_ocr(images_b64, verbose=debug)
    extracted_texts = extract_text_with_paddle_ocr_vl(pil_images, verbose=debug)

    formatted_texts = []
    for i, text in enumerate(extracted_texts):
        if text == "[OCR FAILED]" or not text:
            formatted_texts.append(text if text else "[OCR FAILED]")
        else:
            # Collapse newlines hallucinated by PaddleOCR-VL
            formatted_texts.append(" ".join(text.split()))

    extracted_texts = formatted_texts

    _format_ocr_results(extracted_texts, bubble_metadata)

    if len(extracted_texts) != total_elements:
        msg = (
            f"Warning: extracted_texts length ({len(extracted_texts)}) "
            f"doesn't match total_elements ({total_elements})"
        )
        log_message(msg, always_print=True)
        while len(extracted_texts) < total_elements:
            extracted_texts.append("[OCR FAILED]")
        extracted_texts = extracted_texts[:total_elements]

    if not extracted_texts:
        log_message("PaddleOCR-VL-1.6 returned empty results", verbose=debug)
        failure_results = ["[OCR FAILED]"] * total_elements
        cache.set_manga_ocr_result(cache_key, failure_results, debug)
        return failure_results

    if _check_ocr_failure(extracted_texts):
        log_message("PaddleOCR-VL-1.6 returned only failures", verbose=debug)
        cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
        return extracted_texts

    cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
    return extracted_texts





def _perform_paddleocr_classic(
    images_b64: List[str],
    bubble_metadata: List[Dict[str, Any]],
    input_language: Optional[str] = None,
    debug: bool = False,
) -> List[str]:
    """Perform OCR using classic PaddleOCR (PP-OCRv4, NOT the PaddleOCR-VL VLM).

    Args:
        images_b64: List of base64-encoded images
        bubble_metadata: List of metadata dicts for text elements
        input_language: Source language hint, selects which PP-OCRv4
            language model to run (falls back to trying Japanese/Korean/
            Chinese per image when unset/"auto")
        debug: Whether to print verbose logging

    Returns:
        List of extracted text strings, or early return with failure list
    """
    total_elements = len(images_b64)
    log_message("Using PaddleOCR (Classic) for text extraction", verbose=debug)

    cache = get_cache()
    cache_key = cache.get_manga_ocr_cache_key(
        images_b64,
        total_elements,
        prefix=f"pocrcls_{input_language or 'auto'}_",
    )
    cached_ocr = cache.get_manga_ocr_result(cache_key)
    if cached_ocr is not None:
        if len(cached_ocr) == total_elements:
            log_message("Using cached PaddleOCR (Classic) results", verbose=debug)
            return cached_ocr
        log_message(
            "Discarding PaddleOCR (Classic) cache due to length mismatch",
            verbose=debug,
        )

    pil_images = _prepare_images_for_ocr(images_b64, verbose=debug)
    extracted_texts = extract_text_with_classic_paddleocr(
        pil_images, input_language=input_language, verbose=debug
    )

    formatted_texts = []
    for i, text in enumerate(extracted_texts):
        if text == "[OCR FAILED]" or not text:
            formatted_texts.append(text if text else "[OCR FAILED]")
        else:
            formatted_texts.append(" ".join(text.split()))

    extracted_texts = formatted_texts

    _format_ocr_results(extracted_texts, bubble_metadata)

    if len(extracted_texts) != total_elements:
        msg = (
            f"Warning: extracted_texts length ({len(extracted_texts)}) "
            f"doesn't match total_elements ({total_elements})"
        )
        log_message(msg, always_print=True)
        while len(extracted_texts) < total_elements:
            extracted_texts.append("[OCR FAILED]")
        extracted_texts = extracted_texts[:total_elements]

    if not extracted_texts:
        log_message("PaddleOCR (Classic) returned empty results", verbose=debug)
        failure_results = ["[OCR FAILED]"] * total_elements
        cache.set_manga_ocr_result(cache_key, failure_results, debug)
        return failure_results

    if _check_ocr_failure(extracted_texts):
        log_message("PaddleOCR (Classic) returned only failures", verbose=debug)
        cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
        return extracted_texts

    cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
    return extracted_texts


def _perform_paddleocr_classic_v5(
    images_b64: List[str],
    bubble_metadata: List[Dict[str, Any]],
    input_language: Optional[str] = None,
    debug: bool = False,
) -> List[str]:
    """Perform OCR using classic PaddleOCR PP-OCRv5 (mobile), NOT the
    PaddleOCR-VL VLM.

    Args:
        images_b64: List of base64-encoded images
        bubble_metadata: List of metadata dicts for text elements
        input_language: Source language hint. Only used to route Korean
            input to the dedicated Korean PP-OCRv5 model (see
            extract_text_with_classic_paddleocr_v5); any other value
            (or unset/"auto") uses the unified CJK+English+Pinyin model.
        debug: Whether to print verbose logging

    Returns:
        List of extracted text strings, or early return with failure list
    """
    total_elements = len(images_b64)
    log_message("Using PaddleOCR (Classic, PP-OCRv5) for text extraction", verbose=debug)

    cache = get_cache()
    cache_key = cache.get_manga_ocr_cache_key(
        images_b64,
        total_elements,
        prefix=f"pocrclsv5_{input_language or 'auto'}_",
    )
    cached_ocr = cache.get_manga_ocr_result(cache_key)
    if cached_ocr is not None:
        if len(cached_ocr) == total_elements:
            log_message(
                "Using cached PaddleOCR (Classic, PP-OCRv5) results", verbose=debug
            )
            return cached_ocr
        log_message(
            "Discarding PaddleOCR (Classic, PP-OCRv5) cache due to length mismatch",
            verbose=debug,
        )

    pil_images = _prepare_images_for_ocr(images_b64, verbose=debug)
    extracted_texts = extract_text_with_classic_paddleocr_v5(
        pil_images, input_language=input_language, verbose=debug
    )

    formatted_texts = []
    for i, text in enumerate(extracted_texts):
        if text == "[OCR FAILED]" or not text:
            formatted_texts.append(text if text else "[OCR FAILED]")
        else:
            formatted_texts.append(" ".join(text.split()))

    extracted_texts = formatted_texts

    _format_ocr_results(extracted_texts, bubble_metadata)

    if len(extracted_texts) != total_elements:
        msg = (
            f"Warning: extracted_texts length ({len(extracted_texts)}) "
            f"doesn't match total_elements ({total_elements})"
        )
        log_message(msg, always_print=True)
        while len(extracted_texts) < total_elements:
            extracted_texts.append("[OCR FAILED]")
        extracted_texts = extracted_texts[:total_elements]

    if not extracted_texts:
        log_message(
            "PaddleOCR (Classic, PP-OCRv5) returned empty results", verbose=debug
        )
        failure_results = ["[OCR FAILED]"] * total_elements
        cache.set_manga_ocr_result(cache_key, failure_results, debug)
        return failure_results

    if _check_ocr_failure(extracted_texts):
        log_message(
            "PaddleOCR (Classic, PP-OCRv5) returned only failures", verbose=debug
        )
        cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
        return extracted_texts

    cache.set_manga_ocr_result(cache_key, extracted_texts, debug)
    return extracted_texts


def _perform_llm_ocr(
    config: TranslationConfig,
    images_b64: List[str],
    mime_types: List[str],
    ocr_prompt: str,
    provider: str,
    input_language: Optional[str],
    reading_direction: str,
    debug: bool = False,
    prompt_cache_key: Optional[str] = None,
) -> List[str]:
    """Perform OCR using vision LLM.

    Args:
        config: TranslationConfig
        images_b64: List of base64-encoded images
        mime_types: List of MIME types for each image
        ocr_prompt: OCR prompt text
        provider: Provider name
        input_language: Input language
        reading_direction: Reading direction
        debug: Whether to print verbose logging

    Returns:
        List of extracted text strings, or early return with failure list
    """
    total_elements = len(images_b64)
    ocr_parts = []
    for i, img_b64 in enumerate(images_b64):
        mime_type = mime_types[i] if i < len(mime_types) else "image/jpeg"
        bubble_part = {"inline_data": {"mime_type": mime_type, "data": img_b64}}
        supports_per_part_res = (
            provider == "Google" and is_gemini_3_model(config.model_name)
        ) or provider == "SpaceXAI"
        if supports_per_part_res:
            bubble_part = _add_media_resolution_to_part(
                bubble_part, config.media_resolution_bubbles
            )
        ocr_parts.append(bubble_part)

    ocr_system = _build_system_prompt_ocr(input_language, reading_direction)
    ocr_response_text = _call_llm_endpoint(
        config,
        ocr_parts,
        ocr_prompt,
        debug,
        system_prompt=ocr_system,
        prompt_cache_key=prompt_cache_key,
    )
    extracted_texts = _parse_llm_response_unified(
        ocr_response_text,
        total_elements,
        provider + "-OCR",
        debug,
    )

    if extracted_texts is None:
        log_message("OCR API call failed", always_print=True)
        return [f"[{provider}: OCR failed]"] * total_elements

    if _check_ocr_failure(extracted_texts, provider):
        log_message("OCR returned only placeholders", verbose=debug)
        return extracted_texts

    return extracted_texts


def perform_ocr_only_batch(
    config: TranslationConfig,
    images_b64: List[str],
    mime_types: List[str],
    bubble_metadata: List[Dict[str, Any]],
    debug: bool = False,
) -> List[str]:
    """
    Run OCR only (no translation call) for a batch of text-element crops.

    This mirrors the OCR sub-step of the "two-step" translation_mode branch in
    call_translation_api_batch, but stops right after transcription so callers
    (e.g. Manual translation mode) can capture the original-language text
    without spending a translation API call.

    Args:
        config: TranslationConfig (provider/model/ocr_method settings apply).
        images_b64: List of base64-encoded text-element crops, in reading order.
        mime_types: MIME type for each crop.
        bubble_metadata: Metadata dicts (only used for parity with the batch
            translation call signature; not required to have translation-only
            fields populated).
        debug: Verbose logging toggle.

    Returns:
        List of transcribed strings (source-language text), one per input
        image, in the same order as images_b64. On OCR failure for an item,
        returns the placeholder "[OCR FAILED]" for that item.
    """
    import uuid

    provider = config.provider
    input_language = config.input_language
    reading_direction = config.reading_direction
    session_prompt_cache_key = f"manga-ocr-only-{uuid.uuid4()}"

    if not images_b64:
        return []

    if config.ocr_method == "manga-ocr":
        extracted_texts = _perform_manga_ocr(images_b64, bubble_metadata, debug)
    elif config.ocr_method == "paddleocr-vl-1.6":
        extracted_texts = _perform_paddle_ocr_vl(images_b64, bubble_metadata, debug)
    elif config.ocr_method == "paddleocr-classic":
        extracted_texts = _perform_paddleocr_classic(
            images_b64, bubble_metadata, input_language, debug
        )
    elif config.ocr_method == "paddleocr-classic-v5":
        extracted_texts = _perform_paddleocr_classic_v5(
            images_b64, bubble_metadata, input_language, debug
        )
    else:
        special_instructions_section = _format_special_instructions(config)
        ocr_prompt = f"""
## CONTEXT
You have been provided with {len(images_b64)} individual text images from a manga page.

## TASK
Apply your OCR transcription rules to each image provided.{special_instructions_section}
"""  # noqa
        extracted_texts = _perform_llm_ocr(
            config,
            images_b64,
            mime_types,
            ocr_prompt,
            provider,
            input_language,
            reading_direction,
            debug,
            prompt_cache_key=session_prompt_cache_key,
        )

    # Normalize provider-tagged failure strings to the standard placeholder so
    # downstream consumers only need to check for one sentinel value.
    normalized_texts = []
    for text in extracted_texts:
        if f"[{provider}-OCR:" in text or f"[{provider}:" in text:
            normalized_texts.append("[OCR FAILED]")
        else:
            normalized_texts.append(text)

    return normalized_texts


def call_translation_api_batch(
    config: TranslationConfig,
    images_b64: List[str],
    full_image_b64: str,
    mime_types: List[str],
    full_image_mime_type: str,
    bubble_metadata: List[Dict[str, Any]],
    previous_context_images: Optional[List[Dict[str, str]]] = None,
    previous_context_texts: Optional[List[List[str]]] = None,
    ocr_texts_output: Optional[List[str]] = None,
    sfx_flags_output: Optional[List[bool]] = None,
    debug: bool = False,
) -> List[str]:
    """
    Generates prompts and calls the appropriate LLM API endpoint based on the provider and mode
    specified in the configuration, translating text from speech bubbles and outside-bubble text.

    Supports "one-step" (OCR+Translate+Style) and "two-step" (OCR then Translate+Style) modes.

    Args:
        config (TranslationConfig): Configuration object.
        images_b64 (list): List of base64 encoded images of all text elements, in reading order.
        full_image_b64 (str): Base64 encoded image of the full manga page.
        mime_types (List[str]): List of MIME types for each text element image.
        full_image_mime_type (str): MIME type of the full page image.
        bubble_metadata (List[Dict]): List of metadata dicts with 'is_outside_text' flags for each image.
        previous_context_images: Previous source page images, oldest-to-newest, as reference only.
        previous_context_texts: Per-previous-page OCR transcripts (oldest-to-newest) included as
            narrative reference only. Each inner list contains the OCR strings for that page in reading order.
        ocr_texts_output: Optional mutable list. When provided, OCR transcripts (source-language text) for
            the current page's bubbles are appended in reading order so callers can propagate them as
            previous-page text context for subsequent calls.
        sfx_flags_output: Optional mutable list. When provided, per-item is_sfx booleans are appended in
            reading order (True only for OSB items detected as sound effects) so callers can skip OSB
            inpainting for those regions.
        debug (bool): Whether to print debugging information.

    Returns:
        list: List of translated strings (potentially with style markers), one for each input text element.
              Returns placeholder messages on errors or empty responses.

    Raises:
        ValueError: If required config (API key, provider, URL) is missing or invalid.
        RuntimeError: If an API call fails irrecoverably after retries (raised by endpoint functions).
    """
    provider = config.provider
    import uuid

    session_prompt_cache_key = f"manga-translation-{uuid.uuid4()}"
    input_language = config.input_language
    output_language = config.output_language
    reading_direction = config.reading_direction
    translation_mode = config.translation_mode
    previous_context_images = previous_context_images or []
    if not config.send_full_page_context or config.ocr_method != "LLM":
        previous_context_images = []
    previous_context_image_count = len(previous_context_images)
    # Filter out empty pages (no usable OCR) and trim to configured cap so the
    # request order matches the prompt order regardless of upstream history gaps.
    cleaned_previous_texts: List[List[str]] = []
    configured_text_count = int(getattr(config, "previous_context_text_count", 0) or 0)
    if previous_context_texts and configured_text_count > 0:
        for page_texts in previous_context_texts:
            usable = [
                (t or "").strip()
                for t in (page_texts or [])
                if (t or "").strip() and (t or "").strip() != "[OCR FAILED]"
            ]
            if usable:
                cleaned_previous_texts.append(usable)
        cleaned_previous_texts = cleaned_previous_texts[-configured_text_count:]
    previous_context_text_count = len(cleaned_previous_texts)
    previous_text_section = _format_previous_context_texts(cleaned_previous_texts)

    # Include conditional bubble hints
    total_elements = len(images_b64)
    dialogue_indices = [
        i + 1
        for i, meta in enumerate(bubble_metadata)
        if not meta.get("is_outside_text", False)
    ]
    osb_indices = [
        i + 1
        for i, meta in enumerate(bubble_metadata)
        if meta.get("is_outside_text", False)
    ]

    hints = []
    if dialogue_indices:
        dialogue_list_str = ", ".join(map(str, dialogue_indices))
        hints.append(f"Items [{dialogue_list_str}] contain spoken dialogue.")
    if osb_indices:
        osb_list_str = ", ".join(map(str, osb_indices))
        hints.append(
            f"Items [{osb_list_str}] are outside-bubble (OSB) text — this can be an "
            "audible sound effect (SFX), a mimetic effect, narration, or an internal "
            "monologue; judge each one individually from its image/context. Only "
            "items in this list are eligible for the [SFX] marker, and only when "
            "they are specifically an audible sound effect (e.g. a bang, crash, or "
            "impact noise) — not mimetic FX, narration, or monologue. Items in "
            "this list that are advertisements, series/chapter-title logos, credits, "
            "URLs or watermarks must get the [SKIP] marker instead."
        )

    context_hints = ""
    if hints:
        context_hints = "\nNote: " + " ".join(hints) + " Translate them accordingly."

    cache = get_cache()
    cache_key = cache.get_translation_cache_key(
        images_b64,
        full_image_b64,
        config,
        previous_context_images=previous_context_images,
        previous_context_texts=cleaned_previous_texts,
    )
    cached_translation, cached_ocr_texts, cached_sfx_flags = cache.get_translation(
        cache_key
    )
    if cached_translation is not None:
        log_message("  - Using cached translation", verbose=debug)
        if ocr_texts_output is not None and cached_ocr_texts is not None:
            ocr_texts_output.extend(cached_ocr_texts)
        if sfx_flags_output is not None and cached_sfx_flags is not None:
            sfx_flags_output.extend(cached_sfx_flags)
        return cached_translation

    model_name = config.model_name
    is_gemini_3 = provider == "Google" and is_gemini_3_model(model_name)
    supports_per_part_res = is_gemini_3 or provider == "SpaceXAI"

    base_parts = []
    for i, img_b64 in enumerate(images_b64):
        mime_type = mime_types[i] if i < len(mime_types) else "image/jpeg"
        bubble_part = {"inline_data": {"mime_type": mime_type, "data": img_b64}}
        if supports_per_part_res:
            bubble_part = _add_media_resolution_to_part(
                bubble_part, config.media_resolution_bubbles
            )
        base_parts.append(bubble_part)

    if config.send_full_page_context and full_image_b64:
        context_part = {
            "inline_data": {
                "mime_type": full_image_mime_type,
                "data": full_image_b64,
            }
        }
        if supports_per_part_res:
            context_part = _add_media_resolution_to_part(
                context_part, config.media_resolution_context
            )
        base_parts.append(context_part)

    for image in previous_context_images:
        previous_part = {
            "inline_data": {
                "mime_type": image.get("mime_type", "image/jpeg"),
                "data": image.get("data", ""),
            }
        }
        if supports_per_part_res:
            previous_part = _add_media_resolution_to_part(
                previous_part, config.media_resolution_context
            )
        base_parts.append(previous_part)

    try:
        if translation_mode == "two-step":
            special_instructions_section = _format_special_instructions(config)

            ocr_prompt = f"""
## CONTEXT
You have been provided with {total_elements} individual text images from a manga page.

## TASK
Apply your OCR transcription rules to each image provided.{special_instructions_section}
"""  # noqa

            log_message("Starting OCR step", verbose=debug)

            if config.ocr_method == "manga-ocr":
                extracted_texts = _perform_manga_ocr(
                    images_b64,
                    bubble_metadata,
                    debug,
                )
            elif config.ocr_method == "paddleocr-vl-1.6":
                extracted_texts = _perform_paddle_ocr_vl(
                    images_b64,
                    bubble_metadata,
                    debug,
                )
            elif config.ocr_method == "paddleocr-classic":
                extracted_texts = _perform_paddleocr_classic(
                    images_b64,
                    bubble_metadata,
                    input_language,
                    debug,
                )
            elif config.ocr_method == "paddleocr-classic-v5":
                extracted_texts = _perform_paddleocr_classic_v5(
                    images_b64,
                    bubble_metadata,
                    input_language,
                    debug,
                )
            else:
                extracted_texts = _perform_llm_ocr(
                    config,
                    images_b64,
                    mime_types,
                    ocr_prompt,
                    provider,
                    input_language,
                    reading_direction,
                    debug,
                    prompt_cache_key=session_prompt_cache_key,
                )

            log_message("Starting translation step", verbose=debug)

            formatted_texts = []
            ocr_failed_indices = set()
            for i, text in enumerate(extracted_texts):
                if f"[{provider}-OCR:" in text or text == "[OCR FAILED]":
                    formatted_texts.append("[OCR FAILED]")
                    ocr_failed_indices.add(i)
                else:
                    formatted_texts.append(text)

            ocr_input_section = """
## INPUT DATA
"""
            for i, text in enumerate(formatted_texts):
                meta = bubble_metadata[i] if i < len(bubble_metadata) else {}
                type_tag = "[OSB]" if meta.get("is_outside_text", False) else "[Bubble]"
                ocr_input_section += f"{i + 1}: {type_tag} {text}\n"

            full_page_context = (
                "A full-page image is also provided for visual and narrative context."
                if (
                    config.ocr_method not in LOCAL_OCR_METHODS
                    and config.send_full_page_context
                    and full_image_b64
                )
                else ""
            )
            previous_page_context = _format_previous_context_prompt_note(
                previous_context_image_count,
                previous_context_text_count,
                (
                    "current full page first (when present), then previous "
                    "source pages oldest-to-newest"
                ),
            )

            special_instructions_section = _format_special_instructions(config)

            translation_prompt = f"""
## CONTEXT
You have been provided with a list of {total_elements} transcribed text segments from a manga page. {full_page_context}{previous_page_context}
{context_hints}
{previous_text_section}
{ocr_input_section}

## TASK
Apply your translation and styling rules to the text in the `## INPUT DATA` section. 
The target language is {output_language}. Use the appropriate translation approach for each text type.{special_instructions_section}
"""  # noqa

            translation_parts = []
            if (
                config.ocr_method not in LOCAL_OCR_METHODS
                and config.send_full_page_context
                and full_image_b64
            ):
                context_part = {
                    "inline_data": {
                        "mime_type": full_image_mime_type,
                        "data": full_image_b64,
                    }
                }
                if supports_per_part_res:
                    context_part = _add_media_resolution_to_part(
                        context_part, config.media_resolution_context
                    )
                translation_parts.append(context_part)

            for image in previous_context_images:
                previous_part = {
                    "inline_data": {
                        "mime_type": image.get("mime_type", "image/jpeg"),
                        "data": image.get("data", ""),
                    }
                }
                if supports_per_part_res:
                    previous_part = _add_media_resolution_to_part(
                        previous_part, config.media_resolution_context
                    )
                translation_parts.append(previous_part)

            use_rosetta = is_rosetta_model(model_name)
            use_hy_mt2 = is_hy_mt2_model(model_name)
            if use_rosetta:
                log_message(
                    "YanoljaNEXT Rosetta model detected — using Rosetta prompt format",
                    always_print=True,
                )
                translation_system = _build_rosetta_instruction(
                    output_language,
                    config.special_instructions,
                )
                translation_prompt = _build_rosetta_source_prompt(formatted_texts)
                translation_parts = []  # text-only model, no image parts
            elif use_hy_mt2:
                log_message(
                    "Hy-MT2 model detected — using Hy-MT2 prompt format",
                    always_print=True,
                )
                translation_system = None
                translation_prompt = _build_hy_mt2_prompt(
                    output_language,
                    formatted_texts,
                    config.special_instructions,
                )
                translation_parts = []
            else:
                translation_system = _build_system_prompt_translation(
                    output_language,
                    mode="two-step",
                    reading_direction=reading_direction,
                    full_page_context=(
                        config.send_full_page_context and bool(full_image_b64)
                    ),
                    previous_context_image_count=previous_context_image_count,
                    previous_context_text_count=previous_context_text_count,
                )
            translation_response_text = _call_llm_endpoint(
                config,
                translation_parts,
                translation_prompt,
                debug,
                system_prompt=translation_system,
                prompt_cache_key=session_prompt_cache_key,
            )
            if use_rosetta or use_hy_mt2:
                final_translations = _parse_rosetta_response(
                    translation_response_text,
                    total_elements,
                    provider + "-Translate",
                    debug,
                )
            else:
                final_translations = _parse_llm_response_unified(
                    translation_response_text,
                    total_elements,
                    provider + "-Translate",
                    debug,
                )

            if final_translations is None:
                log_message("Translation API call failed", always_print=True)
                combined_results = []
                for i in range(total_elements):
                    if i in ocr_failed_indices:
                        combined_results.append(f"[{provider}: OCR Failed]")
                    else:
                        combined_results.append(f"[{provider}: Translation failed]")
                if ocr_texts_output is not None:
                    ocr_texts_output.extend(extracted_texts)
                if sfx_flags_output is not None:
                    sfx_flags_output.extend([False] * total_elements)
                return combined_results

            combined_results = []
            sfx_flags = []
            for i in range(total_elements):
                if i in ocr_failed_indices:
                    if final_translations[i] == "[OCR FAILED]":
                        combined_results.append("[OCR FAILED]")
                    else:
                        log_message(
                            f"Element {i + 1}: LLM ignored OCR failure instruction",
                            verbose=debug,
                        )
                        combined_results.append("[OCR FAILED]")
                    sfx_flags.append(False)
                else:
                    clean_text, marker_found = _strip_sfx_marker(final_translations[i])
                    # Only OSB items may carry the sfx flag — for bubbles/captions the
                    # marker is stripped from the displayed text but never sets the flag.
                    is_osb = (i + 1) in osb_indices
                    combined_results.append(clean_text)
                    sfx_flags.append(bool(marker_found and is_osb))

            cache.set_translation(
                cache_key,
                combined_results,
                ocr_texts=extracted_texts,
                sfx_flags=sfx_flags,
            )
            if ocr_texts_output is not None:
                ocr_texts_output.extend(extracted_texts)
            if sfx_flags_output is not None:
                sfx_flags_output.extend(sfx_flags)
            return combined_results

        elif translation_mode == "one-step":
            log_message("Starting one-step translation", verbose=debug)

            full_page_context = (
                "A full-page image is also provided for visual and narrative context."
                if config.send_full_page_context
                else ""
            )
            previous_page_context = _format_previous_context_prompt_note(
                previous_context_image_count,
                previous_context_text_count,
                (
                    "text crops first, optional current full page, then previous "
                    "source pages oldest-to-newest"
                ),
            )

            special_instructions_section = _format_special_instructions(config)

            one_step_prompt = f"""
## CONTEXT
You have been provided with {total_elements} individual text images from a manga page. {full_page_context}{previous_page_context}
{context_hints}
{previous_text_section}
## TASK
For each image, you must perform two steps:
1.  **Transcribe:** Extract the original text exactly as it appears.
2.  **Translate:** Translate the text you just transcribed into {output_language}, applying your translation and styling rules.{special_instructions_section}
"""  # noqa

            one_step_system = _build_system_prompt_translation(
                output_language,
                mode="one-step",
                reading_direction=reading_direction,
                full_page_context=(
                    config.send_full_page_context and bool(full_image_b64)
                ),
                previous_context_image_count=previous_context_image_count,
                previous_context_text_count=previous_context_text_count,
            )
            response_text = _call_llm_endpoint(
                config,
                base_parts,
                one_step_prompt,
                debug,
                system_prompt=one_step_system,
                prompt_cache_key=session_prompt_cache_key,
            )

            # Parse one-step format ("Original || Translated")
            raw_lines = _parse_llm_response_unified(
                response_text, total_elements, provider, debug
            )

            translations = []
            ocr_texts = []
            sfx_flags = []
            for idx, line in enumerate(raw_lines):
                if "||" in line:
                    parts = line.split("||", 1)
                    ocr_texts.append(parts[0].strip())
                    translated_text = parts[1].strip()
                else:
                    # Model violated the format — keep the line as the translation
                    # and mark OCR as failed so it isn't reused as prior context.
                    ocr_texts.append("[OCR FAILED]")
                    translated_text = line

                clean_text, marker_found = _strip_sfx_marker(translated_text)
                # Only OSB items may carry the sfx flag — for bubbles/captions the
                # marker is stripped from the displayed text but never sets the flag,
                # even if the model mistakenly emitted it.
                is_osb = (idx + 1) in osb_indices
                translations.append(clean_text)
                sfx_flags.append(bool(marker_found and is_osb))

            cache.set_translation(
                cache_key, translations, ocr_texts=ocr_texts, sfx_flags=sfx_flags
            )
            if ocr_texts_output is not None:
                ocr_texts_output.extend(ocr_texts)
            if sfx_flags_output is not None:
                sfx_flags_output.extend(sfx_flags)
            return translations
        else:
            raise TranslationError(
                f"Unknown translation_mode specified in config: {translation_mode}"
            )
    except TranslationError:
        raise
    except (ValueError, RuntimeError) as e:
        log_message(f"Translation error: {e}", always_print=True)
        return [f"[Translation Error: {e}]"] * total_elements


def prepare_bubble_images_for_translation(
    bubble_data: List[Dict[str, Any]],
    original_cv_image: np.ndarray,
    upscale_model: Any,
    device: Any,
    mime_type: str,
    bubble_min_side_pixels: int,
    upscale_method: str = "model_lite",
    whiteout_conjoined_bubbles: bool = True,
    verbose: bool = False,
) -> List[Dict[str, Any]]:
    """
    Prepare bubble images for translation by cropping, upscaling, color matching, and encoding.

    This function processes each speech bubble to prepare it for the translation API:
    1. Crops the bubble from the original image
    2. Upscales the bubble to meet minimum size requirements (based on upscale_method)
    3. Matches colors to preserve visual consistency (only for model upscaling)
    4. Encodes the processed bubble as base64 for API transmission

    Args:
        bubble_data: List of bubble detection dicts with 'bbox' keys
        original_cv_image: OpenCV image array of the original image
        upscale_model: Loaded upscaling model
        device: PyTorch device for model inference
        mime_type: MIME type for image encoding
        upscale_method: Method for upscaling - "model", "lanczos", or "none"
        verbose: Whether to print detailed logging

    Returns:
        List of bubble dicts with added 'image_b64' and 'mime_type' keys
        (immutable approach - returns new list without mutating input)
    """
    cv2_ext = ".png" if mime_type == "image/png" else ".jpg"

    prepared_bubbles = []

    mask_lookup = {}
    for b in bubble_data:
        b_bbox = tuple(int(round(v)) for v in b["bbox"])
        mask_lookup[b_bbox] = b.get("sam_mask")

    if upscale_method == "model":
        log_message(
            f"Upscaling {len(bubble_data)} bubble images with 2x-AnimeSharpV4_RCAN",
            always_print=True,
        )
    elif upscale_method == "model_lite":
        log_message(
            f"Upscaling {len(bubble_data)} bubble images with 2x-AnimeSharpV4_Fast_RCAN_PU (Lite)",
            always_print=True,
        )
    elif upscale_method == "lanczos":
        log_message(
            f"Upscaling {len(bubble_data)} bubble images with LANCZOS",
            always_print=True,
        )
    else:
        log_message(
            f"Processing {len(bubble_data)} bubble images without upscaling",
            always_print=True,
        )

    for bubble in bubble_data:
        prepared_bubble = bubble.copy()
        x1, y1, x2, y2 = bubble["bbox"]

        # Use the tight bbox of the mask
        _mask = bubble.get("sam_mask")
        _ma = None
        if _mask is not None:
            _ma = np.asarray(_mask)
            if _ma.ndim == 3:
                _ma = _ma[..., 0]
            if _ma.ndim == 2:
                _rows, _cols = np.where(_ma > 0)
                if _rows.size and _cols.size:
                    mx1, my1 = int(_cols.min()), int(_rows.min())
                    mx2, my2 = int(_cols.max()) + 1, int(_rows.max()) + 1
                    x1 = min(x1, mx1)
                    y1 = min(y1, my1)
                    x2 = max(x2, mx2)
                    y2 = max(y2, my2)

        # Clamp to image bounds (negative / oversized coords produce empty or
        # 1px-wide crops that crash cvtColor / the upscaler) and skip junk boxes.
        _img_h, _img_w = original_cv_image.shape[:2]
        x1 = max(0, int(x1))
        y1 = max(0, int(y1))
        x2 = min(_img_w, int(x2))
        y2 = min(_img_h, int(y2))
        if (x2 - x1) < 8 or (y2 - y1) < 8:
            log_message(
                f"Skipping degenerate bubble crop {bubble['bbox']} "
                f"({x2 - x1}x{y2 - y1}px, page {_img_w}x{_img_h})",
                always_print=True,
            )
            continue

        bubble_image_cv = original_cv_image[y1:y2, x1:x2].copy()

        # White-out conjoined neighbor text regions visible in this crop
        neighbor_bboxes = bubble.get("conjoined_neighbor_bboxes")
        if whiteout_conjoined_bubbles and neighbor_bboxes:
            own_mask_crop = (
                _ma[y1:y2, x1:x2] > 0 if (_ma is not None and _ma.ndim == 2) else None
            )

            for nb in neighbor_bboxes:
                nb_tuple = tuple(int(round(v)) for v in nb)
                neighbor_mask = mask_lookup.get(nb_tuple)

                if neighbor_mask is not None:
                    _nm = np.asarray(neighbor_mask)
                    if _nm.ndim == 3:
                        _nm = _nm[..., 0]
                    if _nm.ndim == 2:
                        nm_crop = _nm[y1:y2, x1:x2] > 0

                        if own_mask_crop is not None:
                            region_mask = nm_crop & ~own_mask_crop
                        else:
                            region_mask = nm_crop

                        # Apply whiteout precisely on neighbor's mask pixels
                        bubble_image_cv[region_mask] = 255

        # Tall manhwa/webtoon pages: stacked bubbles sit close together, so this
        # crop can also contain the text of the bubble above/below it. Blank out
        # every OTHER bubble's area (outside our own area) so OCR/translation
        # only sees this bubble's own text.
        if (_img_h / float(max(_img_w, 1))) > 1.3 and len(bubble_data) > 1:
            own_bx = tuple(int(round(v)) for v in bubble["bbox"])
            own_area = None
            if _ma is not None and _ma.ndim == 2:
                own_area = _ma[y1:y2, x1:x2] > 0
            else:
                own_area = np.zeros((y2 - y1, x2 - x1), dtype=bool)
                bx1_, by1_, bx2_, by2_ = own_bx
                own_area[
                    max(0, by1_ - y1) : max(0, by2_ - y1),
                    max(0, bx1_ - x1) : max(0, bx2_ - x1),
                ] = True
            blanked = 0
            for other in bubble_data:
                ob = tuple(int(round(v)) for v in other["bbox"])
                if ob == own_bx:
                    continue
                ox1, oy1, ox2, oy2 = ob
                if ox2 <= x1 or ox1 >= x2 or oy2 <= y1 or oy1 >= y2:
                    continue
                other_area = np.zeros((y2 - y1, x2 - x1), dtype=bool)
                _om = other.get("sam_mask")
                if _om is not None:
                    _omn = np.asarray(_om)
                    if _omn.ndim == 3:
                        _omn = _omn[..., 0]
                    if _omn.ndim == 2:
                        other_area = _omn[y1:y2, x1:x2] > 0
                if not other_area.any():
                    other_area[
                        max(0, oy1 - y1) : max(0, oy2 - y1),
                        max(0, ox1 - x1) : max(0, ox2 - x1),
                    ] = True
                region = other_area & ~own_area
                if region.any():
                    bubble_image_cv[region] = 255
                    blanked += 1
            if blanked:
                log_message(
                    f"Blanked {blanked} neighbouring bubble(s) in crop {own_bx}",
                    verbose=verbose,
                )

        bubble_image_pil = cv2_to_pil(bubble_image_cv)

        try:
            if upscale_method == "model" or upscale_method == "model_lite":
                final_bubble_pil = process_bubble_image_cached(
                    bubble_image_pil,
                    upscale_model,
                    device,
                    bubble_min_side_pixels,
                    "min",
                    upscale_method,
                    verbose,
                )
            elif upscale_method == "lanczos":
                w, h = bubble_image_pil.size
                min_side = min(w, h)
                if min_side < bubble_min_side_pixels:
                    scale_factor = bubble_min_side_pixels / min_side
                    new_w = int(w * scale_factor)
                    new_h = int(h * scale_factor)
                    resized_bubble = bubble_image_pil.resize((new_w, new_h), Image.LANCZOS)
                else:
                    resized_bubble = bubble_image_pil
                final_bubble_pil = resized_bubble
            else:
                final_bubble_pil = bubble_image_pil

        except Exception as _up_err:
            log_message(
                f"Upscale failed for bubble {bubble['bbox']} "
                f"({type(_up_err).__name__}: {_up_err}); using LANCZOS fallback",
                always_print=True,
            )
            _w, _h = bubble_image_pil.size
            _min_side = max(1, min(_w, _h))
            if _min_side < bubble_min_side_pixels:
                _sf = bubble_min_side_pixels / _min_side
                final_bubble_pil = bubble_image_pil.resize(
                    (max(1, int(_w * _sf)), max(1, int(_h * _sf))), Image.LANCZOS
                )
            else:
                final_bubble_pil = bubble_image_pil

        final_bubble_cv = pil_to_cv2(final_bubble_pil)

        try:
            is_success, buffer = cv2.imencode(cv2_ext, final_bubble_cv)
            if is_success:
                image_b64 = base64.b64encode(buffer).decode("utf-8")
                prepared_bubble["image_b64"] = image_b64
                prepared_bubble["mime_type"] = mime_type
                log_message(
                    f"Bubble {x1},{y1} ({final_bubble_pil.size[0]}x{final_bubble_pil.size[1]})",
                    verbose=verbose,
                )
            else:
                log_message(
                    f"Failed to encode bubble {bubble['bbox']}", verbose=verbose
                )
                prepared_bubble["image_b64"] = None
        except Exception as e:
            log_message(f"Error encoding bubble {bubble['bbox']}: {e}", verbose=verbose)
            prepared_bubble["image_b64"] = None

        prepared_bubbles.append(prepared_bubble)

    return prepared_bubbles
