"""Estimate how much the ORIGINAL text of a bubble is tilted.

The returned angle is in the same convention as ``rotation_deg`` used by
``render_text_skia`` (Skia canvas.rotate): positive = clockwise on screen.
Works for horizontal text (Korean/English manhwa, tilted lines) and for
vertical text (Japanese manga columns): the whole block's tilt is returned and
the translated (horizontal) text is rotated by the same amount.

Method: projection-profile search. The ink mask is rotated through a range of
angles; at the right angle the text lines (or columns) line up and the
row/column ink profile becomes as "spiky" as possible. The angle with the
sharpest profile wins, but only if it is clearly better than 0 degrees, so
straight text stays at exactly 0 and noisy/short text never gets a random tilt.
"""

from typing import Optional

import cv2
import numpy as np

MAX_ANGLE_DEG = 30.0  # search range: +-30 degrees
COARSE_STEP_DEG = 1.0
FINE_STEP_DEG = 0.25
MIN_APPLY_DEG = 2.5  # smaller tilts are treated as 0 (jitter / not worth it)
MIN_INK_PIXELS = 40
MIN_GAIN = 1.06  # best profile must be >= 6% sharper than the unrotated one
WORK_MAX_SIDE = 240


def _profile_scores(binary: np.ndarray, angle_deg: float) -> tuple:
    """Return (row_score, col_score) of the ink mask rotated by angle_deg (CCW)."""
    h, w = binary.shape
    mat = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle_deg, 1.0)
    rot = cv2.warpAffine(binary, mat, (w, h), flags=cv2.INTER_LINEAR)
    rows = rot.sum(axis=1, dtype=np.float64)
    cols = rot.sum(axis=0, dtype=np.float64)
    total = rows.sum()
    if total <= 0:
        return 0.0, 0.0
    # sum of squares of the profile, normalised so it is scale independent
    return float((rows**2).sum() / total**2), float((cols**2).sum() / total**2)


def estimate_text_rotation_deg(ink_mask: Optional[np.ndarray]) -> float:
    """Estimate the tilt of the text in ``ink_mask`` (uint8, 255 = ink).

    Returns degrees, positive = clockwise (matches ``rotation_deg`` in
    ``render_text_skia``). Returns 0.0 when the text is straight or the
    estimate isn't trustworthy.
    """
    try:
        if ink_mask is None or ink_mask.ndim != 2:
            return 0.0
        from .format_analysis import clean_ink_mask

        ink_mask = clean_ink_mask(ink_mask)
        if int(np.count_nonzero(ink_mask)) < MIN_INK_PIXELS:
            return 0.0

        ys, xs = np.where(ink_mask > 0)
        crop = ink_mask[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1]
        ch, cw = crop.shape
        if ch < 6 or cw < 6:
            return 0.0

        scale = min(1.0, WORK_MAX_SIDE / float(max(ch, cw)))
        if scale < 1.0:
            crop = cv2.resize(
                crop,
                (max(1, int(round(cw * scale))), max(1, int(round(ch * scale)))),
                interpolation=cv2.INTER_AREA,
            )
        crop = (crop > 64).astype(np.uint8) * 255
        ch, cw = crop.shape

        # pad so rotating by up to MAX_ANGLE never clips the ink
        diag = int(np.ceil(np.hypot(ch, cw))) + 4
        canvas = np.zeros((diag, diag), dtype=np.uint8)
        oy, ox = (diag - ch) // 2, (diag - cw) // 2
        canvas[oy : oy + ch, ox : ox + cw] = crop

        def sweep(angles):
            best = (-1.0, 0.0, "h")
            for a in angles:
                rs, cs = _profile_scores(canvas, float(a))
                if rs > best[0]:
                    best = (rs, float(a), "h")
                if cs > best[0]:
                    best = (cs, float(a), "v")
            return best

        base_r, base_c = _profile_scores(canvas, 0.0)

        coarse = np.arange(-MAX_ANGLE_DEG, MAX_ANGLE_DEG + 1e-6, COARSE_STEP_DEG)
        score, angle, axis = sweep(coarse)
        fine = np.arange(angle - COARSE_STEP_DEG, angle + COARSE_STEP_DEG + 1e-6, FINE_STEP_DEG)
        score, angle, axis = sweep(fine)

        base = base_r if axis == "h" else base_c
        if base <= 0 or score / base < MIN_GAIN:
            return 0.0
        if abs(angle) < MIN_APPLY_DEG:
            return 0.0
        # cv2 rotation by +angle is CCW and levels the text, which means the
        # text itself was tilted clockwise by `angle` -> Skia rotate(+angle).
        return float(round(angle, 2))
    except Exception:
        return 0.0
