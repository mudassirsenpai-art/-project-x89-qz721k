"""Measure where the ORIGINAL text sat (centre + tilt) so the translation can be
drawn in the same place and at the same angle.

Used by the "Copy Bubble Text Position" / "Copy Outside Text Position"
options. Everything here is best-effort: any failure returns None and the
caller falls back to the normal placement, so a page never breaks.

Angle convention: degrees, positive = clockwise on screen (same as Skia's
canvas.rotate and the `rotation_deg` argument of render_text_skia).
"""

from typing import Any, Dict, Optional, Tuple

import cv2
import numpy as np
from PIL import Image

MIN_ELONGATION = 1.4  # block must be clearly wider than tall to trust its angle
MIN_ANGLE_DEG = 1.5  # ignore tiny tilts (measurement noise)
MAX_ANGLE_DEG = 45.0  # beyond this the text is vertical -> do not rotate
COLOR_DISTANCE = 70.0  # RGB distance still counted as "text colour"


def bbox_center(bbox) -> Optional[Tuple[float, float]]:
    """Centre of an (x1, y1, x2, y2) box in the same coordinate frame."""
    try:
        x1, y1, x2, y2 = [float(v) for v in bbox]
    except Exception:
        return None
    if x2 <= x1 or y2 <= y1:
        return None
    return ((x1 + x2) / 2.0, (y1 + y2) / 2.0)


def _text_pixel_mask(
    crop_rgb: np.ndarray,
    text_color_rgb: Optional[Tuple[int, int, int]],
    is_dark_text: bool,
) -> Optional[np.ndarray]:
    h, w = crop_rgb.shape[:2]
    if h < 4 or w < 4:
        return None
    mask = None
    if text_color_rgb is not None:
        diff = crop_rgb.astype(np.float32) - np.array(text_color_rgb, np.float32)
        dist = np.sqrt((diff**2).sum(axis=2))
        cand = (dist < COLOR_DISTANCE).astype(np.uint8) * 255
        frac = cand.mean() / 255.0
        if 0.002 < frac < 0.6:
            mask = cand
    if mask is None:
        gray = cv2.cvtColor(crop_rgb, cv2.COLOR_RGB2GRAY)
        _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        mask = (255 - otsu) if is_dark_text else otsu
    k = max(2, int(round(min(h, w) * 0.02)))
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    # drop specks
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    min_area = max(6, int(0.0004 * h * w))
    keep = np.zeros_like(mask)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            keep[labels == i] = 255
    if keep.sum() == 0:
        return None
    return keep


def measure_text_geometry(
    crop: Image.Image,
    text_color_rgb: Optional[Tuple[int, int, int]] = None,
    is_dark_text: bool = True,
) -> Optional[Dict[str, Any]]:
    """Return {'center': (cx, cy), 'angle': deg, 'size': (w, h)} in CROP coords."""
    try:
        rgb = np.asarray(crop.convert("RGB"))
        mask = _text_pixel_mask(rgb, text_color_rgb, is_dark_text)
        if mask is None:
            return None
        ys, xs = np.where(mask > 0)
        if xs.size < 12:
            return None
        center = (
            (float(xs.min()) + float(xs.max()) + 1.0) / 2.0,
            (float(ys.min()) + float(ys.max()) + 1.0) / 2.0,
        )
        pts = np.column_stack([xs, ys]).astype(np.float32)
        hull = cv2.convexHull(pts)
        (_, _), (rw, rh), ang = cv2.minAreaRect(hull)
        # make `rw` the long side; angle then describes the long side direction
        if rw < rh:
            rw, rh = rh, rw
            ang += 90.0
        # normalise to (-90, 90]
        while ang > 90.0:
            ang -= 180.0
        while ang <= -90.0:
            ang += 180.0
        angle = 0.0
        if rh > 0 and (rw / rh) >= MIN_ELONGATION:
            if abs(ang) > 90.0 - 1e-6:
                ang = 0.0
            if abs(ang) <= MAX_ANGLE_DEG and abs(ang) >= MIN_ANGLE_DEG:
                angle = float(ang)
        return {
            "center": center,
            "angle": angle,
            "size": (float(xs.max() - xs.min() + 1), float(ys.max() - ys.min() + 1)),
        }
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Bubble placement: shift the text centre to where the ORIGINAL text sat
# without the old hard 20% clamp, by growing the largest box that is centred on
# that spot and still lies fully inside the bubble's safe area.
# ---------------------------------------------------------------------------

MIN_BOX_FRACTION = 0.5  # shifted box must keep >= 50% of the normal safe box


def safe_region_mask(cleaned_mask: np.ndarray, padding_pixels: float):
    """Bool mask of pixels at least `padding_pixels` inside the bubble.

    Returns (safe_bool, off_x, off_y) where safe_bool[0, 0] sits at page pixel
    (off_x, off_y), or None on failure. Works on a crop so it stays cheap.
    """
    try:
        m = (np.asarray(cleaned_mask) > 0).astype(np.uint8)
        x, y, w, h = cv2.boundingRect(m)
        if w <= 0 or h <= 0:
            return None
        crop = np.zeros((h + 2, w + 2), dtype=np.uint8)
        crop[1:-1, 1:-1] = m[y : y + h, x : x + w] * 255
        dist = cv2.distanceTransform(crop, cv2.DIST_L2, cv2.DIST_MASK_PRECISE)
        safe = dist >= float(padding_pixels)
        if not safe.any():
            return None
        return safe, x - 1, y - 1
    except Exception:
        return None


def _integral(safe: np.ndarray) -> np.ndarray:
    ii = np.zeros((safe.shape[0] + 1, safe.shape[1] + 1), dtype=np.int64)
    ii[1:, 1:] = safe.astype(np.int64).cumsum(0).cumsum(1)
    return ii


def _rect_fits(ii, px, py, hw, hh) -> bool:
    h, w = ii.shape[0] - 1, ii.shape[1] - 1
    x0, x1 = int(round(px - hw)), int(round(px + hw))
    y0, y1 = int(round(py - hh)), int(round(py + hh))
    if x0 < 0 or y0 < 0 or x1 >= w or y1 >= h:
        return False
    area = (x1 - x0 + 1) * (y1 - y0 + 1)
    tot = ii[y1 + 1, x1 + 1] - ii[y0, x1 + 1] - ii[y1 + 1, x0] + ii[y0, x0]
    return int(tot) == int(area)


def largest_centered_box(safe, off_x, off_y, cx, cy, max_w, max_h):
    """Largest (w, h) box centred on (cx, cy) fully inside `safe`, capped to
    (max_w, max_h). None if the centre itself is outside the safe area."""
    px, py = int(round(cx - off_x)), int(round(cy - off_y))
    hgt, wid = safe.shape
    if not (0 <= px < wid and 0 <= py < hgt) or not safe[py, px]:
        return None
    ii = _integral(safe)
    cap_hw, cap_hh = max_w / 2.0, max_h / 2.0
    # 1) same aspect ratio as the normal safe box
    lo, hi = 0.0, 1.0
    for _ in range(16):
        mid = (lo + hi) / 2.0
        if _rect_fits(ii, px, py, cap_hw * mid, cap_hh * mid):
            lo = mid
        else:
            hi = mid
    hw, hh = cap_hw * lo, cap_hh * lo
    if not _rect_fits(ii, px, py, hw, hh):
        hw, hh = 0.0, 0.0
    # 2) greedily grow each axis on its own (bubbles are usually wider than tall)
    step_x, step_y = max(1.0, cap_hw / 60.0), max(1.0, cap_hh / 60.0)
    for _ in range(4):
        changed = False
        while hw + step_x <= cap_hw and _rect_fits(ii, px, py, hw + step_x, hh):
            hw += step_x
            changed = True
        while hh + step_y <= cap_hh and _rect_fits(ii, px, py, hw, hh + step_y):
            hh += step_y
            changed = True
        if not changed:
            break
    if hw < 1.0 or hh < 1.0:
        return None
    return 2.0 * hw, 2.0 * hh


def plan_copy_box(region, safe_center, safe_size, target_center):
    """Place the text centre on `target_center` (the original text spot).

    Returns (cx, cy, box_w, box_h) in page coords, or None if nothing sensible
    could be planned (caller then uses the normal placement). If the exact spot
    would leave less than MIN_BOX_FRACTION of the normal box, the centre is
    pulled back towards the safe-box centre only as far as needed.
    """
    try:
        safe, ox, oy = region
        scx, scy = float(safe_center[0]), float(safe_center[1])
        sw, sh = float(safe_size[0]), float(safe_size[1])
        tx, ty = float(target_center[0]), float(target_center[1])
        for t in (1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0.0):
            cx, cy = scx + t * (tx - scx), scy + t * (ty - scy)
            box = largest_centered_box(safe, ox, oy, cx, cy, sw, sh)
            if box is None:
                continue
            if t == 0.0 or (
                box[0] >= MIN_BOX_FRACTION * sw and box[1] >= MIN_BOX_FRACTION * sh
            ):
                return cx, cy, box[0], box[1]
        return None
    except Exception:
        return None


def render_crop_bounds(bbox, text_rect, img_size, margin):
    """Crop used for supersampled drawing: the bubble bbox UNION the text rect
    (+ margin for outline/glow/AA), clamped to the page. Using the bbox alone
    clips any text that sticks out of it (seen with merged/overlapping bubbles
    where the safe area is larger than the detector's box)."""
    iw, ih = img_size
    x1, y1, x2, y2 = [float(v) for v in bbox]
    if text_rect is not None:
        tx1, ty1, tx2, ty2 = [float(v) for v in text_rect]
        x1, y1 = min(x1, tx1 - margin), min(y1, ty1 - margin)
        x2, y2 = max(x2, tx2 + margin), max(y2, ty2 + margin)
    cx1, cy1 = max(0, int(np.floor(x1))), max(0, int(np.floor(y1)))
    cx2, cy2 = min(int(iw), int(np.ceil(x2))), min(int(ih), int(np.ceil(y2)))
    return cx1, cy1, cx2, cy2
