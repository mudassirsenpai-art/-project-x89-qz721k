"""Duplicate text-box removal for tall manhwa/manhua/webtoon pages.

Symptom this fixes: the same speech bubble is drawn twice with two different
font sizes (two overlapping text layers inside one bubble). It happens when
the same bubble ends up as two entries (bubble + bubble from tile overlap /
secondary detector, or bubble + OSB "text_free" box on top of it) and both
entries get translated and rendered.

Only used on tall pages (webtoon strips); regular manga pages are untouched.
"""

from typing import Any, Dict, List, Optional

from utils.logging import log_message

TALL_ASPECT_THRESHOLD = 1.3  # same value as tiled_inference.TALL_ASPECT_THRESHOLD
DUP_IOA_THRESHOLD = 0.6  # smaller box this much inside the other => duplicate


def is_tall_page(width: int, height: int) -> bool:
    return width > 0 and (height / float(width)) > TALL_ASPECT_THRESHOLD


def _area(b) -> float:
    return max(0.0, float(b[2]) - float(b[0])) * max(0.0, float(b[3]) - float(b[1]))


def _inter(a, b) -> float:
    iw = min(a[2], b[2]) - max(a[0], b[0])
    ih = min(a[3], b[3]) - max(a[1], b[1])
    return iw * ih if iw > 0 and ih > 0 else 0.0


def dedupe_overlapping_text_items(
    items: List[Dict[str, Any]],
    img_w: Optional[int] = None,
    img_h: Optional[int] = None,
    only_tall: bool = True,
    threshold: float = DUP_IOA_THRESHOLD,
    verbose: bool = False,
) -> List[Dict[str, Any]]:
    """Drop items whose bbox is mostly covered by another item.

    Keep priority: real speech bubble > OSB text, then larger box.
    Never drops SFX-flagged items in favour of nothing: an SFX/OSB item is only
    dropped if a speech bubble covers it.
    """
    if not items or len(items) < 2:
        return items
    if only_tall and img_w and img_h and not is_tall_page(img_w, img_h):
        return items

    # Step 1: a "merged" box = one big box that swallows 2+ separate bubbles
    # (text of both bubbles lands in it). Drop the big box, keep the children.
    merged = set()
    for a in range(len(items)):
        ba = items[a].get("bbox")
        if not ba or len(ba) != 4:
            continue
        kids = []
        for b in range(len(items)):
            if b == a:
                continue
            bb = items[b].get("bbox")
            if not bb or len(bb) != 4:
                continue
            ab = max(_area(bb), 1e-6)
            if _area(bb) < _area(ba) and _inter(ba, bb) / ab > threshold:
                kids.append(bb)
        distinct = []
        for k in kids:
            if all(
                _inter(k, d) / max(min(_area(k), _area(d)), 1e-6) < 0.3
                for d in distinct
            ):
                distinct.append(k)
        if len(distinct) >= 2:
            merged.add(a)
    if merged:
        log_message(
            f"Removed {len(merged)} merged box(es) that covered 2+ separate bubbles",
            always_print=True,
        )
        items = [it for i, it in enumerate(items) if i not in merged]
        if len(items) < 2:
            return items

    def rank(it):
        bbox = it.get("bbox")
        # higher = more worth keeping
        return (0 if it.get("is_outside_text", False) else 1, _area(bbox))

    valid = [i for i, it in enumerate(items) if it.get("bbox") and len(it["bbox"]) == 4]
    order = sorted(valid, key=lambda i: rank(items[i]), reverse=True)
    kept: List[int] = []
    dropped = set()
    for i in order:
        bi = items[i]["bbox"]
        ai = _area(bi)
        dup = False
        for j in kept:
            bj = items[j]["bbox"]
            smaller = max(min(ai, _area(bj)), 1e-6)
            if _inter(bi, bj) / smaller > threshold:
                dup = True
                break
        if dup:
            dropped.add(i)
        else:
            kept.append(i)

    if not dropped:
        return items
    log_message(
        f"Removed {len(dropped)} duplicate overlapping text box(es) (tall page)",
        always_print=True,
    )
    # keep original order of the input list
    return [it for i, it in enumerate(items) if i not in dropped]
