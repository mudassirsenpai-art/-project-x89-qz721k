import asyncio
import base64
import math
import os
import pickle
import re
import threading
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, Tuple, Union

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from core.batch_coordinator import BatchRequestCoordinator
from core.caching import get_cache
from core.config import MangaTranslatorConfig, PreprocessingConfig, RenderingConfig
from core.scaling import scale_font_size, scale_length, scale_scalar
from core.validation import validate_config
from utils.exceptions import (
    CancellationError,
    CleaningError,
    FontError,
    ImageProcessingError,
    RenderingError,
    TranslationError,
)
from utils.logging import log_message
from utils.path_list import resolve_source_path, write_failed_paths

from .image.cleaning import (
    clean_speech_bubbles,
    retry_cleaning_with_otsu,
    sweep_residual_text_for_bubbles,
)
from .image.dedupe import dedupe_overlapping_text_items, dedupe_translation_texts
from .image.detection import detect_panels, detect_speech_bubbles
from .image.image_utils import (
    convert_image_to_target_mode,
    cv2_to_pil,
    pil_to_cv2,
    resize_to_max_side,
    save_image_with_compression,
    upscale_image,
    upscale_image_to_dimension,
)
from .image.sorting import sort_bubbles_by_reading_order, sort_panels_by_reading_order
from .ml.model_manager import get_model_manager
from .outside_text_processor import (
    drop_sfx_skip_regions,
    finish_outside_text_work,
    prepare_outside_text_work,
    process_outside_text,
)
from .services.translation import (
    call_translation_api_batch,
    perform_ocr_only_batch,
    prepare_bubble_images_for_translation,
)
from .text.placeholders import generate_test_placeholders
from .text.style_extraction import describe_style, resolve_style_overrides
from .text.text_processing import supports_long_word_breaking
from .text.text_renderer import render_text_skia

if TYPE_CHECKING:
    from ui.cancellation import CancellationManager


ENABLE_COMPONENT_ORDER_DEBUG = False
PREVIOUS_CONTEXT_CACHE_MAX_SIZE = 32
NATURAL_SORT_TOKEN_RE = re.compile(r"(\d+)")

# "Copy Original Text Style" support. Typical fonts have a cap-height
# (uppercase letter height, roughly what a detected text-ink bbox measures)
# that's about 70% of the nominal font size (em height). Dividing measured
# ink height by this ratio gives an approximate font size that will visually
# match the original text's height when rendered in the (different) target
# font. This is a rough, font-independent heuristic, not an exact match -
# real fonts vary, and translated text length differs from source text
# length, which is why target_font_size_tolerance exists as a safety net.
CAP_HEIGHT_TO_FONT_SIZE_RATIO = 0.7
MIN_ORIGINAL_TEXT_PX_HEIGHT_FOR_MATCHING = 6  # ignore noise-sized detections


from .skip_regions import (
    align_sfx_flags,
    looks_like_non_story_text,
    restore_skipped_regions,
)


def estimate_target_font_size_from_line_height(
    median_line_height: Optional[float],
) -> Optional[float]:
    """Estimate a target font size (px) from a measured original-text
    single-line ink height, for use with RenderingConfig.target_font_size.

    Args:
        median_line_height: Median height (px) of individual text-line ink
            contours, as computed by cleaning.py's process_single_bubble
            (stored as bubble["text_median_line_height"]) or the equivalent
            OSB glyph-mask measurement. None if unavailable.

    Returns:
        Estimated font size in px, or None if unavailable/too small to
        trust (very small measurements are more likely noise/punctuation
        than a reliable line-height sample).
    """
    if median_line_height is None or median_line_height <= 0:
        return None
    if median_line_height < MIN_ORIGINAL_TEXT_PX_HEIGHT_FOR_MATCHING:
        return None
    return float(median_line_height) / CAP_HEIGHT_TO_FONT_SIZE_RATIO


def _should_overlap_llm_with_inpaint(
    config: MangaTranslatorConfig,
    manual_checkpoint_save_path: Optional[Union[str, Path]] = None,
) -> bool:
    return (
        bool(getattr(config, "overlap_llm_with_inpaint", False))
        and not config.cleaning_only
        and not getattr(config, "test_mode", False)
        # Manual mode Pass 1 only OCRs (no LLM translation call happens
        # here - that runs later in Pass 2, from the user's edited JSON),
        # so cleaning/inpainting deferred "to overlap with the LLM call"
        # would never actually get triggered, silently checkpointing the
        # uncleaned image. Always take the eager path in Pass 1.
        and manual_checkpoint_save_path is None
    )


def _clean_speech_bubbles_for_page(
    pil_image_processed: Image.Image,
    bubble_data: List[Dict[str, Any]],
    config: MangaTranslatorConfig,
    device,
    processing_scale: float,
    verbose: bool,
    fallback_cv_image: np.ndarray,
) -> Tuple[np.ndarray, List[Dict[str, Any]]]:
    """Clean bubbles (including optional colored-bubble Flux). Returns (cv_image, info)."""
    try:
        use_otsu = config.cleaning.use_otsu_threshold
        if config.cleaning.inpaint_colored_bubbles:
            log_message(
                "Flux inpainting enabled for colored bubbles",
                verbose=verbose,
            )

        cleaned_image_cv, processed_bubbles_info = clean_speech_bubbles(
            pil_image_processed,
            config.yolo_model_path,
            config.detection.confidence,
            pre_computed_detections=bubble_data,
            device=device,
            thresholding_value=config.cleaning.thresholding_value,
            use_otsu_threshold=use_otsu,
            roi_shrink_px=config.cleaning.roi_shrink_px,
            verbose=verbose,
            processing_scale=processing_scale,
            conjoined_confidence=config.detection.conjoined_confidence,
            inpaint_colored_bubbles=config.cleaning.inpaint_colored_bubbles,
            flux_hf_token=config.outside_text.huggingface_token,
            flux_num_inference_steps=config.outside_text.flux_num_inference_steps,
            flux_residual_diff_threshold=config.outside_text.flux_residual_diff_threshold,
            flux_seed=config.outside_text.seed,
            osb_text_verification=config.detection.use_osb_text_verification,
            osb_text_hf_token=config.outside_text.huggingface_token,
            inpaint_method=config.outside_text.inpainting_method,
            flux_backend=config.outside_text.flux_backend,
            flux_low_vram=config.outside_text.flux_low_vram,
            flux_sdcpp_cache_mode=config.outside_text.flux_sdcpp_cache_mode,
            flux_sdcpp_diffusion_quant=config.outside_text.flux_sdcpp_diffusion_quant,
            flux_sdcpp_text_encoder_quant=config.outside_text.flux_sdcpp_text_encoder_quant,
            flux_luminance_correction=config.outside_text.flux_luminance_correction,
            flux_upscale_small_crops=config.outside_text.flux_upscale_small_crops,
            bubble_detector_model=config.detection.bubble_detector_model,
            request_coordinator=getattr(config, "request_coordinator", None),
        )
        return cleaned_image_cv, processed_bubbles_info
    except CleaningError as e:
        log_message(f"Cleaning failed: {e}", always_print=True)
        return fallback_cv_image.copy(), []
    except Exception as e:
        log_message(f"Error during cleaning: {e}", always_print=True)
        return fallback_cv_image.copy(), []


def _bubble_text_anchor(render_info):
    """Bounding box of the ORIGINAL text of a speech bubble (page coords), used
    to keep the translated text where the original sat. None if unknown."""
    try:
        tb = render_info.get("text_bbox") if render_info else None
        if tb is not None and len(tb) == 4 and tb[2] > tb[0] and tb[3] > tb[1]:
            return tuple(int(v) for v in tb)
    except Exception:
        pass
    return None


def compute_bubble_id(bbox, is_outside_text: bool = False, salt: str = "") -> str:
    """
    Build a stable identifier for a bubble/OSB text-element from its bbox.

    The id is derived only from geometry (and the outside-text flag), so it
    stays identical between Manual mode's Pass 1 (OCR capture) and Pass 2
    (checkpoint reload) runs, as long as detection/cleaning are not re-run
    with different settings in between. `salt` can be used by callers to
    additionally namespace ids per-image when needed (e.g. multi-file jobs
    sharing one combined JSON).
    """
    try:
        bx = tuple(int(round(float(v))) for v in bbox)
    except Exception:
        bx = tuple(bbox) if bbox else ()
    kind = "osb" if is_outside_text else "bubble"
    base = (
        f"{salt}:{kind}:{bx[0]}_{bx[1]}_{bx[2]}_{bx[3]}"
        if len(bx) == 4
        else f"{salt}:{kind}:{bx}"
    )
    return base.strip(":")


def save_manual_checkpoint(
    checkpoint_path: Union[str, Path],
    *,
    pil_cleaned_image: Image.Image,
    sorted_bubble_data: List[Dict[str, Any]],
    processed_bubbles_info: List[Dict[str, Any]],
    outside_text_data: List[Dict[str, Any]],
    ocr_texts: List[str],
    target_mode: str,
    image_path: Union[str, Path],
    config: "MangaTranslatorConfig",
) -> None:
    """
    Persist everything Pass 2 (manual translation render) needs to disk, so
    detection/cleaning/OCR never have to run twice for the same page.

    This is a plain pickle of picklable, already in-memory objects (PIL
    image, numpy mask arrays, plain dict/list metadata) - nothing here talks
    to the network or re-invokes any model.
    """
    checkpoint_path = Path(checkpoint_path)
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)

    # Strip heavy/non-essential transient fields we don't need for rendering
    # (e.g. base64 crops already consumed by OCR) to keep checkpoints small,
    # but keep everything the render loop reads.
    slim_bubbles = []
    for i, bubble in enumerate(sorted_bubble_data):
        slim = dict(bubble)
        slim.pop("image_b64", None)
        bbox = slim.get("bbox")
        slim["bubble_id"] = compute_bubble_id(
            bbox, is_outside_text=slim.get("is_outside_text", False)
        )
        slim["ocr_text"] = (
            ocr_texts[i] if i < len(ocr_texts) else slim.get("ocr_text", "")
        )
        slim_bubbles.append(slim)

    payload = {
        "version": 1,
        "image_path": str(image_path),
        "target_mode": target_mode,
        "pil_cleaned_image": pil_cleaned_image,
        "sorted_bubble_data": slim_bubbles,
        "processed_bubbles_info": processed_bubbles_info,
        "outside_text_data": outside_text_data,
        "translation_config_snapshot": {
            "output_language": config.translation.output_language,
            "input_language": config.translation.input_language,
        },
    }

    tmp_path = checkpoint_path.with_suffix(checkpoint_path.suffix + ".tmp")
    with open(tmp_path, "wb") as f:
        pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(tmp_path, checkpoint_path)


def load_manual_checkpoint(checkpoint_path: Union[str, Path]) -> Dict[str, Any]:
    """Load a checkpoint previously written by save_manual_checkpoint."""
    with open(checkpoint_path, "rb") as f:
        return pickle.load(f)


def _render_from_manual_checkpoint(
    checkpoint_path: Union[str, Path],
    manual_translations: Dict[str, Any],
    *,
    output_path: Optional[Union[str, Path]],
    config: MangaTranslatorConfig,
    verbose: bool,
) -> Image.Image:
    """
    Manual translation mode, Pass 2: load a checkpoint saved during Pass 1 and
    render user-supplied translations onto the already-cleaned page image.

    No detection, cleaning, or OCR runs here - only text layout/drawing
    (render_text_skia) against the masks/colors captured in Pass 1.
    """
    checkpoint = load_manual_checkpoint(checkpoint_path)
    pil_cleaned_image: Image.Image = checkpoint["pil_cleaned_image"]
    sorted_bubble_data: List[Dict[str, Any]] = checkpoint["sorted_bubble_data"]
    processed_bubbles_info: List[Dict[str, Any]] = checkpoint["processed_bubbles_info"]
    target_mode: str = checkpoint.get("target_mode", pil_cleaned_image.mode)

    if pil_cleaned_image.mode != target_mode:
        pil_cleaned_image = pil_cleaned_image.convert(target_mode)

    processing_scale = 1.0  # baked into the checkpointed masks/geometry already
    main_min_font = scale_font_size(
        config.rendering.min_font_size, processing_scale, minimum=4, maximum=256
    )
    main_max_font = scale_font_size(
        config.rendering.max_font_size,
        processing_scale,
        minimum=main_min_font,
        maximum=384,
    )
    padding_pixels = scale_scalar(
        config.rendering.padding_pixels, processing_scale, minimum=1.0, maximum=80.0
    )
    osb_min_font = scale_font_size(
        config.outside_text.osb_min_font_size,
        processing_scale,
        minimum=4,
        maximum=512,
    )
    osb_max_font = scale_font_size(
        config.outside_text.osb_max_font_size,
        processing_scale,
        minimum=osb_min_font,
        maximum=640,
    )
    osb_outline_width = scale_scalar(
        config.outside_text.osb_outline_width,
        processing_scale,
        minimum=0.0,
        maximum=24.0,
    )

    bubble_render_info_map = {
        tuple(info["bbox"]): {
            "color": info["color"],
            "mask": info.get("mask"),
            "base_mask": info.get("base_mask"),
            "is_sam": info.get("is_sam", False),
            "is_colored": info.get("is_colored", False),
            "text_bbox": info.get("text_bbox"),
            "text_color_bgr": info.get("text_color_bgr"),
            "text_median_line_height": info.get("text_median_line_height"),
            "lettering_style": info.get("lettering_style"),
        }
        for info in processed_bubbles_info
        if "bbox" in info and "color" in info and "mask" in info
    }

    # Safety net for old/new checkpoints: if a bubble was skipped or only
    # partly cleaned in Pass 1, the original text is still in the cleaned
    # image and the translation would be drawn right on top of it. Erase any
    # leftover text from white bubbles BEFORE rendering anything.
    try:
        _sweep_cv = pil_to_cv2(pil_cleaned_image)
        _swept = sweep_residual_text_for_bubbles(
            _sweep_cv, sorted_bubble_data, verbose=verbose
        )
        if _swept:
            log_message(
                f"Manual render: erased {_swept}px of leftover bubble text "
                f"before rendering ({Path(str(checkpoint_path)).name})",
                always_print=True,
            )
            pil_cleaned_image = cv2_to_pil(_sweep_cv)
            if pil_cleaned_image.mode != target_mode:
                pil_cleaned_image = pil_cleaned_image.convert(target_mode)
    except Exception as _sweep_exc:
        log_message(f"Residual sweep skipped: {_sweep_exc}", verbose=verbose)

    # Old checkpoints may still hold the same bubble twice (tall pages only).
    try:
        sorted_bubble_data = dedupe_overlapping_text_items(
            sorted_bubble_data,
            img_w=pil_cleaned_image.width,
            img_h=pil_cleaned_image.height,
            verbose=verbose,
        )
    except Exception as _dd_exc:
        log_message(f"Duplicate-box cleanup skipped: {_dd_exc}", verbose=verbose)

    original_cv_image = pil_to_cv2(pil_cleaned_image)
    missing_bubble_ids: List[str] = []
    final_image_to_save = pil_cleaned_image

    # Pre-pass: resolve each bubble's text and strip duplicated sentences
    # (same line inside two bubbles / bubble + outside-text twin).
    _text_override: Dict[int, str] = {}
    try:
        _pre_texts: List[str] = []
        for _b in sorted_bubble_data:
            _bb = _b["bbox"]
            _osb = _b.get("is_outside_text", False)
            _bid = _b.get("bubble_id") or compute_bubble_id(_bb, _osb)
            _re = manual_translations.get(_bid)
            if isinstance(_re, dict):
                _t = (_re.get("translation") or "").strip()
                if _re.get("sfx") and _osb:
                    _t = ""  # SFX items are never drawn, keep them out of dedupe
            else:
                _t = (_re or "").strip()
            _pre_texts.append(_t)
        _deduped = dedupe_translation_texts(
            [b["bbox"] for b in sorted_bubble_data],
            _pre_texts,
            [bool(b.get("is_outside_text", False)) for b in sorted_bubble_data],
            verbose=verbose,
        )
        for _i, (_old, _new) in enumerate(zip(_pre_texts, _deduped)):
            if _old and _new != _old:
                _text_override[_i] = _new
    except Exception as _tdd_exc:
        log_message(f"Text duplicate cleanup skipped: {_tdd_exc}", verbose=verbose)

    for i, bubble in enumerate(sorted_bubble_data):
        bbox = bubble["bbox"]
        is_outside_text = bubble.get("is_outside_text", False)
        bubble_id = bubble.get("bubble_id") or compute_bubble_id(bbox, is_outside_text)
        ocr_text = (bubble.get("ocr_text") or "").strip()

        # manual_translations entries may be a plain translated-text string
        # (legacy shape) or a {"translation": str, "sfx": bool} dict written
        # by Manual Pass 1/2's combined_translations.json. "sfx" is only
        # meaningful for OSB items - a human editor marking a sound effect so
        # Pass 2 leaves its original pixels untouched instead of rendering
        # translated text over it.
        raw_entry = manual_translations.get(bubble_id)
        if isinstance(raw_entry, dict):
            text = (raw_entry.get("translation") or "").strip()
            is_sfx = bool(raw_entry.get("sfx", False)) and is_outside_text
        else:
            text = (raw_entry or "").strip()
            is_sfx = False
        if i in _text_override:
            text = _text_override[i]
            if not text:
                # whole entry was a duplicate of another bubble: nothing to draw
                continue
        if not text:
            # Fall back to the original OCR text so the page still renders in
            # full even if this bubble's translation is missing/unmatched.
            if bubble_id not in manual_translations:
                missing_bubble_ids.append(bubble_id)
            text = ocr_text
        if not text:
            log_message(
                f"Skipping {bbox} - no translation and no OCR fallback text",
                verbose=verbose,
            )
            continue
        bubble["translation"] = text
        bubble["is_sfx"] = is_sfx

        render_info = None
        base_mask = None
        is_sam_mask = False
        text_bg_rgb = None
        target_font_size = None
        glow_color = None
        glow_radius = 0.0
        outline_color = None
        outline_width_override = None

        if is_outside_text:
            if is_sfx and "original_crop_pil" in bubble:
                # Human-flagged SFX: skip rendering entirely, leave the
                # original (already-cleaned-in-Pass-1) pixels untouched.
                rendered_image = pil_cleaned_image.copy()
                original_patch = bubble["original_crop_pil"]
                rendered_image.paste(original_patch, (bbox[0], bbox[1]))
                pil_cleaned_image = rendered_image
                final_image_to_save = pil_cleaned_image
                continue
            if ocr_text and ocr_text == text and "original_crop_pil" in bubble:
                rendered_image = pil_cleaned_image.copy()
                original_patch = bubble["original_crop_pil"]
                rendered_image.paste(original_patch, (bbox[0], bbox[1]))
                pil_cleaned_image = rendered_image
                final_image_to_save = pil_cleaned_image
                continue
            text = text.upper()
            font_dir = (
                config.outside_text.osb_font_dir
                if config.outside_text.osb_font_dir
                else config.rendering.font_dir
            )
            min_font = osb_min_font
            max_font = osb_max_font
            line_spacing = config.outside_text.osb_line_spacing
            use_ligs = config.outside_text.osb_use_ligatures
            cleaned_mask = None
            is_dark_text = bubble.get("is_dark_text", True)
            text_color_rgb = bubble.get("text_color_rgb", None)
            bubble_color_bgr = (50, 50, 50) if is_dark_text else (255, 255, 255)
            rotation_deg = 0.0
            vertical_stack = False
            if config.rendering.match_original_style:
                target_font_size = estimate_target_font_size_from_line_height(
                    bubble.get("text_median_line_height")
                )
                if target_font_size is not None:
                    target_font_size = scale_font_size(
                        target_font_size,
                        processing_scale,
                        minimum=osb_min_font,
                        maximum=osb_max_font,
                    )
            if config.rendering.detect_glow:
                glow_color = bubble.get("glow_color_rgb")
                glow_radius = bubble.get("glow_radius") or 0.0
            # Solid text-background boxes are reserved for genuinely
            # un-inpainted OSB regions (inpainting_method == "none", where the
            # original pixels are still underneath). When real inpainting ran
            # (Flux or OpenCV texture inpaint), the art has already been
            # erased/reconstructed, so OSB/SFX text renders with only its
            # outline stroke for readability instead of a box that covers art.
            if (
                bubble.get("needs_text_background")
                and config.outside_text.inpainting_method == "none"
            ):
                if text_color_rgb:
                    lum = (
                        0.299 * text_color_rgb[0]
                        + 0.587 * text_color_rgb[1]
                        + 0.114 * text_color_rgb[2]
                    )
                    text_bg_rgb = (255, 255, 255) if lum < 128 else (0, 0, 0)
                else:
                    text_bg_rgb = (0, 0, 0) if is_dark_text else (255, 255, 255)
        else:
            font_dir = config.rendering.font_dir
            min_font = main_min_font
            max_font = main_max_font
            line_spacing = config.rendering.line_spacing_mult
            use_ligs = config.rendering.use_ligatures
            render_info = bubble_render_info_map.get(tuple(bbox))
            bubble_color_bgr = (255, 255, 255)
            cleaned_mask = None
            text_color_rgb = None
            if render_info:
                bubble_color_bgr = render_info["color"]
                cleaned_mask = render_info.get("mask")
                base_mask = render_info.get("base_mask")
                is_sam_mask = render_info.get("is_sam", False)
                text_color_bgr_val = render_info.get("text_color_bgr")
                if text_color_bgr_val:
                    text_color_rgb = (
                        text_color_bgr_val[2],
                        text_color_bgr_val[1],
                        text_color_bgr_val[0],
                    )
                if config.rendering.match_original_style:
                    target_font_size = estimate_target_font_size_from_line_height(
                        render_info.get("text_median_line_height")
                    )
                    if target_font_size is not None:
                        target_font_size = scale_font_size(
                            target_font_size,
                            processing_scale,
                            minimum=main_min_font,
                            maximum=main_max_font,
                        )
                if config.rendering.detect_glow:
                    glow_color = render_info.get("glow_color_rgb")
                    glow_radius = render_info.get("glow_radius") or 0.0
                if config.rendering.match_original_style:
                    style_overrides = resolve_style_overrides(
                        render_info.get("lettering_style"),
                        base_min_font=main_min_font,
                        base_max_font=main_max_font,
                        tolerance=config.rendering.match_original_style_tolerance,
                    )
                    if style_overrides:
                        log_message(
                            f"  - Lettering style {bbox}: "
                            f"{describe_style(render_info.get('lettering_style'))} "
                            f"-> {style_overrides.summary()}",
                            verbose=verbose,
                        )
                        if style_overrides.text_color_rgb:
                            text_color_rgb = style_overrides.text_color_rgb
                        if style_overrides.outline_color_rgb and style_overrides.outline_width:
                            outline_color = style_overrides.outline_color_rgb
                            outline_width_override = style_overrides.outline_width
                        if (
                            config.rendering.detect_glow
                            and style_overrides.glow_color_rgb
                            and style_overrides.glow_radius
                            and not glow_color
                        ):
                            glow_color = style_overrides.glow_color_rgb
                            glow_radius = style_overrides.glow_radius
                        if style_overrides.max_font_size:
                            target_font_size = style_overrides.max_font_size
            vertical_stack = False
            rotation_deg = 0.0

        should_hyphenate = config.rendering.hyphenate_before_scaling
        if not supports_long_word_breaking(config.translation.output_language):
            should_hyphenate = False

        render_config = RenderingConfig(
            min_font_size=min_font,
            max_font_size=max_font,
            line_spacing_mult=line_spacing,
            use_subpixel_rendering=(
                config.outside_text.osb_use_subpixel_rendering
                if is_outside_text
                else config.rendering.use_subpixel_rendering
            ),
            font_hinting=(
                config.outside_text.osb_font_hinting
                if is_outside_text
                else config.rendering.font_hinting
            ),
            use_ligatures=use_ligs,
            hyphenate_before_scaling=should_hyphenate,
            hyphen_penalty=config.rendering.hyphen_penalty,
            hyphenation_min_word_length=config.rendering.hyphenation_min_word_length,
            badness_exponent=config.rendering.badness_exponent,
            padding_pixels=padding_pixels,
            outline_width=(
                osb_outline_width
                if is_outside_text
                else (outline_width_override or 0.0)
            ),
            supersampling_factor=config.rendering.supersampling_factor,
            detach_trailing_punctuation=config.rendering.detach_trailing_punctuation,
            auto_vertical_text=(
                False if is_outside_text else config.rendering.auto_vertical_text
            ),
            target_font_size=target_font_size,
            target_font_size_tolerance=config.rendering.match_original_style_tolerance,
            glow_color=glow_color,
            glow_radius=glow_radius,
            outline_color=outline_color if not is_outside_text else None,
        )

        success = False
        try:
            rendered_image = render_text_skia(
                pil_image=pil_cleaned_image,
                text=text,
                bbox=bbox,
                font_dir=font_dir,
                cleaned_mask=cleaned_mask,
                bubble_color_bgr=bubble_color_bgr,
                config=render_config,
                verbose=verbose,
                bubble_id=str(i + 1),
                rotation_deg=rotation_deg,
                vertical_stack=vertical_stack,
                text_color_rgb=text_color_rgb,
                raise_on_safe_error=not is_outside_text,
                text_background_color=text_bg_rgb if is_outside_text else None,
                anchor_bbox=bubble.get("original_bbox") if is_outside_text else _bubble_text_anchor(render_info),
            )
            success = True
        except Exception as e:
            log_message(f"Text rendering failed for {bbox}: {e}", verbose=verbose)
            retry_result = None
            if not is_outside_text and "Safe area calculation failed" in str(e):
                retry_result = retry_cleaning_with_otsu(
                    original_cv_image,
                    {
                        "base_mask": base_mask,
                        "bbox": bbox,
                        "is_sam": is_sam_mask,
                        "is_colored": (
                            render_info.get("is_colored", False)
                            if render_info
                            else False
                        ),
                        "text_bbox": (
                            render_info.get("text_bbox") if render_info else None
                        ),
                        "text_color_bgr": (
                            render_info.get("text_color_bgr") if render_info else None
                        ),
                    },
                    config.cleaning.thresholding_value,
                    config.cleaning.roi_shrink_px,
                    processing_scale,
                    verbose=verbose,
                    classify_colored=config.cleaning.inpaint_colored_bubbles,
                )
            if retry_result and retry_result.get("mask") is not None:
                try:
                    rendered_image = render_text_skia(
                        pil_image=pil_cleaned_image,
                        text=text,
                        bbox=bbox,
                        font_dir=font_dir,
                        cleaned_mask=retry_result["mask"],
                        bubble_color_bgr=retry_result.get("color", bubble_color_bgr),
                        config=render_config,
                        verbose=verbose,
                        bubble_id=str(i + 1),
                        rotation_deg=rotation_deg,
                        vertical_stack=vertical_stack,
                        raise_on_safe_error=False,
                    )
                    success = True
                except Exception as e2:
                    log_message(
                        f"Text rendering failed after Otsu retry: {e2}",
                        verbose=verbose,
                    )
                    rendered_image = pil_cleaned_image
                    success = False
            elif is_outside_text and "original_crop_pil" in bubble:
                rendered_image = pil_cleaned_image.copy()
                original_patch = bubble["original_crop_pil"]
                rendered_image.paste(original_patch, (bbox[0], bbox[1]))
                success = True
            else:
                rendered_image = pil_cleaned_image
                success = False

        # Last resort for normal bubbles: the cleaning mask was unusable (e.g. a
        # starburst bubble gave a ~2x2px safe box), so the original text is still
        # on the page and the translation could not be placed. Wipe an ellipse
        # inscribed in the bubble bbox with the bubble colour and render there.
        if not success and not is_outside_text:
            try:
                _w_img, _h_img = pil_cleaned_image.size
                _bx1, _by1, _bx2, _by2 = [int(round(v)) for v in bbox]
                _bx1, _by1 = max(0, _bx1), max(0, _by1)
                _bx2, _by2 = min(_w_img, _bx2), min(_h_img, _by2)
                if (_bx2 - _bx1) >= 16 and (_by2 - _by1) >= 16:
                    _fb_mask = np.zeros((_h_img, _w_img), dtype=np.uint8)
                    cv2.ellipse(
                        _fb_mask,
                        ((_bx1 + _bx2) // 2, (_by1 + _by2) // 2),
                        (
                            max(1, int((_bx2 - _bx1) / 2 * 0.92)),
                            max(1, int((_by2 - _by1) / 2 * 0.92)),
                        ),
                        0,
                        0,
                        360,
                        255,
                        -1,
                    )
                    _rgb = np.array(pil_cleaned_image.convert("RGB"))
                    _col = bubble_color_bgr if bubble_color_bgr else (255, 255, 255)
                    _rgb[_fb_mask > 0] = (_col[2], _col[1], _col[0])
                    _wiped = Image.fromarray(_rgb).convert(pil_cleaned_image.mode)
                    rendered_image = render_text_skia(
                        pil_image=_wiped,
                        text=text,
                        bbox=(_bx1, _by1, _bx2, _by2),
                        font_dir=font_dir,
                        cleaned_mask=_fb_mask,
                        bubble_color_bgr=bubble_color_bgr,
                        config=render_config,
                        verbose=verbose,
                        bubble_id=str(i + 1),
                        rotation_deg=0.0,
                        vertical_stack=False,
                        text_color_rgb=text_color_rgb,
                        raise_on_safe_error=False,
                    )
                    success = True
                    log_message(
                        f"Bubble {bbox}: bad mask, rendered with bbox-ellipse fallback",
                        always_print=True,
                    )
            except Exception as _fb_err:
                log_message(
                    f"Bbox-ellipse fallback failed for {bbox}: {_fb_err}",
                    always_print=True,
                )

        if success:
            pil_cleaned_image = rendered_image
            final_image_to_save = pil_cleaned_image
        else:
            log_message(f"Failed to render bubble {bbox}", verbose=verbose)

    if missing_bubble_ids:
        log_message(
            f"Manual mode: {len(missing_bubble_ids)} bubble(s) had no translation "
            f"in the supplied JSON, kept original OCR text: {missing_bubble_ids}",
            always_print=True,
        )

    if config.output.upscale_final_image:
        final_image_to_save = upscale_image(
            final_image_to_save,
            config.output.image_upscale_factor,
            model_type=config.output.image_upscale_model,
            verbose=verbose,
        )

    if output_path:
        if final_image_to_save.mode != target_mode:
            final_image_to_save = final_image_to_save.convert(target_mode)
        try:
            save_image_with_compression(
                final_image_to_save,
                output_path,
                jpeg_quality=config.output.jpeg_quality,
                png_compression=config.output.png_compression,
                verbose=verbose,
            )
        except ImageProcessingError as e:
            log_message(f"Failed to save image: {e}", always_print=True)
            raise

    return final_image_to_save


def _natural_text_sort_key(text: str) -> Tuple[Tuple[int, Union[int, str], str], ...]:
    return tuple(
        (0, int(part), part) if part.isdigit() else (1, part.lower(), part)
        for part in NATURAL_SORT_TOKEN_RE.split(text)
        if part
    )


def _natural_path_sort_key(path: Path):
    return tuple(_natural_text_sort_key(part) for part in path.parts)


def list_manual_mode_images(input_dir: Union[str, Path]) -> List[Path]:
    """
    List images in a directory in the same natural, page-number-aware order
    used by batch_translate_images. Used by Manual mode's Pass 1/Pass 2 CLI
    loops in main.py so page ordering (and therefore the combined JSON's
    page order) matches what a normal --batch run would produce.
    """
    input_dir = Path(input_dir)
    image_extensions = [".jpg", ".jpeg", ".png", ".webp"]
    image_files = [
        f
        for f in input_dir.iterdir()
        if f.is_file() and f.suffix.lower() in image_extensions
    ]
    image_files.sort(key=lambda p: _natural_path_sort_key(Path(p.name)))
    return image_files


def _debug_mask_bbox(mask):
    """Return full-image bbox for a debug mask, or None when empty/invalid."""
    normalized = (
        _normalize_debug_mask(mask, (mask.shape[1], mask.shape[0]))
        if isinstance(mask, np.ndarray) and mask.ndim >= 2
        else None
    )
    if normalized is None:
        try:
            mask_array = np.asarray(mask)
            if mask_array.ndim == 3:
                mask_array = mask_array[..., 0]
            if mask_array.ndim != 2:
                return None
            normalized = mask_array > 0
        except Exception:
            return None
    coords = np.where(normalized)
    if coords[0].size == 0 or coords[1].size == 0:
        return None
    return [
        int(coords[1].min()),
        int(coords[0].min()),
        int(coords[1].max()) + 1,
        int(coords[0].max()) + 1,
    ]


def get_image_encoding_params(pil_image_format: Optional[str]) -> Tuple[str, str]:
    """Returns (mime_type, cv2_ext) for a given PIL image format."""
    if pil_image_format and pil_image_format.upper() == "PNG":
        return "image/png", ".png"
    return "image/jpeg", ".jpg"


def _normalize_context_image_mode(
    image: Image.Image,
    mime_type: str,
    verbose: bool = False,
) -> Image.Image:
    if mime_type == "image/jpeg":
        if image.mode in ("RGBA", "LA"):
            background = Image.new("RGB", image.size, (255, 255, 255))
            background.paste(image, mask=image.split()[-1])
            return background
        if image.mode != "RGB":
            log_message(
                f"Converting {image.mode} previous context image to RGB",
                verbose=verbose,
            )
            return image.convert("RGB")
        return image

    if image.mode not in ("RGB", "RGBA", "L"):
        log_message(
            f"Converting {image.mode} previous context image to RGBA",
            verbose=verbose,
        )
        return image.convert("RGBA")
    return image


def _encode_previous_context_source_page(
    image_path: Path,
    config: MangaTranslatorConfig,
    verbose: bool = False,
) -> Optional[Dict[str, str]]:
    try:
        with Image.open(image_path) as source_image:
            image_format = source_image.format
            mime_type, cv2_ext = get_image_encoding_params(image_format)
            context_image_pil = _normalize_context_image_mode(
                source_image.copy(),
                mime_type,
                verbose,
            )

        effective_context_max_side = scale_length(
            config.translation.context_image_max_side_pixels,
            None,
            minimum=512,
            maximum=4096,
        )
        context_upscale_method = (
            "none" if config.test_mode else config.translation.upscale_method
        )

        if context_upscale_method in ("model", "model_lite"):
            model_manager = get_model_manager()
            if context_upscale_method == "model":
                upscale_model = model_manager.load_upscale(verbose=verbose)
            else:
                upscale_model = model_manager.load_upscale_lite(verbose=verbose)
            context_image_pil = upscale_image_to_dimension(
                upscale_model,
                context_image_pil,
                effective_context_max_side,
                config.device,
                "max",
                context_upscale_method,
                verbose,
            )
            context_image_pil = resize_to_max_side(
                context_image_pil,
                effective_context_max_side,
                verbose=verbose,
            )
            model_manager.clear_cache()
        elif context_upscale_method == "lanczos":
            context_image_pil = resize_to_max_side(
                context_image_pil,
                effective_context_max_side,
                verbose=verbose,
            )

        context_image_cv = pil_to_cv2(context_image_pil)
        is_success, buffer = cv2.imencode(cv2_ext, context_image_cv)
        if not is_success:
            raise ImageProcessingError(
                f"Previous context image encoding to {cv2_ext} failed"
            )
        return {
            "mime_type": mime_type,
            "data": base64.b64encode(buffer).decode("utf-8"),
        }
    except Exception as e:
        log_message(
            f"Warning: Failed to encode previous context image {image_path}: {e}",
            always_print=True,
        )
        return None


def _previous_context_cache_key(
    image_path: Path,
    config: MangaTranslatorConfig,
) -> Tuple[Any, ...]:
    stat = image_path.stat()
    context_upscale_method = (
        "none" if config.test_mode else config.translation.upscale_method
    )
    return (
        str(image_path.resolve()),
        stat.st_mtime_ns,
        stat.st_size,
        config.translation.context_image_max_side_pixels,
        context_upscale_method,
    )


def _get_cached_previous_context_image(
    image_path: Path,
    config: MangaTranslatorConfig,
    context_cache: Optional[OrderedDict],
    context_cache_lock: Optional[threading.Lock],
) -> Optional[Dict[str, str]]:
    verbose = config.verbose
    if context_cache is None:
        return _encode_previous_context_source_page(image_path, config, verbose)

    try:
        cache_key = _previous_context_cache_key(image_path, config)
    except Exception:
        return _encode_previous_context_source_page(image_path, config, verbose)

    if context_cache_lock:
        with context_cache_lock:
            cached = context_cache.get(cache_key)
            if cached is not None:
                context_cache.move_to_end(cache_key)
                return cached

    encoded = _encode_previous_context_source_page(image_path, config, verbose)
    if encoded is None:
        return None

    if context_cache_lock:
        with context_cache_lock:
            context_cache[cache_key] = encoded
            context_cache.move_to_end(cache_key)
            while len(context_cache) > PREVIOUS_CONTEXT_CACHE_MAX_SIZE:
                context_cache.popitem(last=False)
    return encoded


def _build_previous_context_images(
    image_files: List[Path],
    image_index: int,
    config: MangaTranslatorConfig,
    context_cache: Optional[OrderedDict] = None,
    context_cache_lock: Optional[threading.Lock] = None,
) -> List[Dict[str, str]]:
    if not getattr(config.translation, "send_full_page_context", False):
        return []
    if getattr(config.translation, "ocr_method", "LLM") != "LLM":
        return []

    requested_count = int(
        getattr(config.translation, "previous_context_image_count", 0) or 0
    )
    if requested_count <= 0:
        return []

    start_index = max(0, image_index - requested_count)
    previous_paths = image_files[start_index:image_index]
    previous_images = []
    for previous_path in previous_paths:
        encoded = _get_cached_previous_context_image(
            previous_path,
            config,
            context_cache,
            context_cache_lock,
        )
        if encoded is not None:
            previous_images.append(encoded)
    return previous_images


def _build_previous_context_texts(
    image_files: List[Path],
    image_index: int,
    config: MangaTranslatorConfig,
    ocr_text_history: Optional[Dict[Path, List[str]]] = None,
    ocr_text_history_lock: Optional[threading.Lock] = None,
) -> List[List[str]]:
    """Collect OCR transcripts from up to N already-processed prior pages.

    Parallel callers that require deterministic prior-page text context should
    wait for the required previous pages before calling this helper.
    """
    requested_count = int(
        getattr(config.translation, "previous_context_text_count", 0) or 0
    )
    if requested_count <= 0 or ocr_text_history is None:
        return []

    start_index = max(0, image_index - requested_count)
    previous_paths = image_files[start_index:image_index]
    if not previous_paths:
        return []

    previous_texts: List[List[str]] = []
    if ocr_text_history_lock is not None:
        with ocr_text_history_lock:
            for previous_path in previous_paths:
                texts = ocr_text_history.get(previous_path)
                if texts:
                    previous_texts.append(list(texts))
    else:
        for previous_path in previous_paths:
            texts = ocr_text_history.get(previous_path)
            if texts:
                previous_texts.append(list(texts))
    return previous_texts


def _load_debug_font(size: int):
    """Load a bold-ish font for the debug overlay, falling back safely."""
    font_candidates = [
        "arialbd.ttf",
        "arial.ttf",
        "C:/Windows/Fonts/arialbd.ttf",
        "C:/Windows/Fonts/arial.ttf",
    ]
    for candidate in font_candidates:
        try:
            return ImageFont.truetype(candidate, size=size)
        except Exception:
            continue
    return ImageFont.load_default()


def _draw_dashed_rectangle(draw, bbox, color, width=2, dash=12, gap=7):
    """Draw a dashed rectangle matching the requested debug style."""
    x0, y0, x1, y1 = [int(v) for v in bbox]
    if x1 <= x0 or y1 <= y0:
        return

    def _draw_dashed_line(start, end, horizontal=True):
        if horizontal:
            fixed = start[1]
            pos = start[0]
            limit = end[0]
            while pos < limit:
                seg_end = min(pos + dash, limit)
                draw.line((pos, fixed, seg_end, fixed), fill=color, width=width)
                pos += dash + gap
        else:
            fixed = start[0]
            pos = start[1]
            limit = end[1]
            while pos < limit:
                seg_end = min(pos + dash, limit)
                draw.line((fixed, pos, fixed, seg_end), fill=color, width=width)
                pos += dash + gap

    _draw_dashed_line((x0, y0), (x1, y0), horizontal=True)
    _draw_dashed_line((x0, y1), (x1, y1), horizontal=True)
    _draw_dashed_line((x0, y0), (x0, y1), horizontal=False)
    _draw_dashed_line((x1, y0), (x1, y1), horizontal=False)


def _draw_centered_index(draw, bbox, value, font, color):
    """Draw the index at the visual center of the box."""
    x0, y0, x1, y1 = bbox
    cx = int(round((x0 + x1) / 2))
    cy = int(round((y0 + y1) / 2))
    label = str(value)
    try:
        draw.text((cx, cy), label, fill=color, font=font, anchor="mm")
    except TypeError:
        left, top, right, bottom = draw.textbbox((0, 0), label, font=font)
        draw.text(
            (cx - (right - left) / 2, cy - (bottom - top) / 2),
            label,
            fill=color,
            font=font,
        )


def _normalize_debug_mask(mask, image_size):
    """Normalize a debug mask into a full-image boolean array."""
    if mask is None:
        return None

    try:
        mask_array = np.asarray(mask)
    except Exception:
        return None

    if mask_array.ndim == 3:
        mask_array = mask_array[..., 0]

    if mask_array.ndim != 2:
        return None

    width, height = image_size
    if mask_array.shape != (height, width):
        return None

    return mask_array > 0


def _apply_mask_debug_overlay(canvas, mask, color=(255, 0, 0, 84)):
    """Alpha-composite a semi-transparent mask overlay onto the debug canvas."""
    normalized_mask = _normalize_debug_mask(mask, canvas.size)
    if normalized_mask is None or not np.any(normalized_mask):
        return

    overlay = np.zeros((canvas.size[1], canvas.size[0], 4), dtype=np.uint8)
    overlay[normalized_mask] = color
    canvas.alpha_composite(Image.fromarray(overlay, mode="RGBA"))


def _write_component_order_debug_image(
    image_size,
    sorted_items,
    panels,
    bubble_masks,
    reading_direction,
    image_path,
    output_path,
    verbose=False,
):
    """Write a debug PNG showing panel order and merged text-element order."""
    width, height = image_size
    if width <= 0 or height <= 0:
        return

    canvas = Image.new("RGBA", (width, height), (238, 238, 238, 255))
    draw = ImageDraw.Draw(canvas)

    panel_color = (32, 63, 255)
    osb_color = (255, 0, 255)
    bubble_color = (34, 160, 34)
    index_color = (255, 0, 0)

    font_size = max(14, min(width, height) // 28)
    font = _load_debug_font(font_size)

    panel_order = (
        sort_panels_by_reading_order(panels, reading_direction) if panels else []
    )

    for item in sorted_items:
        if item.get("is_outside_text", False):
            continue
        bbox = tuple(int(round(v)) for v in item.get("bbox", (0, 0, 0, 0)))
        _apply_mask_debug_overlay(
            canvas, bubble_masks.get(bbox) if bubble_masks else None
        )

    for panel_index, panel_id in enumerate(panel_order, start=1):
        panel_bbox = tuple(int(round(v)) for v in panels[panel_id])
        draw.rectangle(panel_bbox, outline=panel_color, width=3)
        _draw_centered_index(draw, panel_bbox, panel_index, font, index_color)

    for item_index, item in enumerate(sorted_items, start=1):
        bbox = tuple(int(round(v)) for v in item.get("bbox", (0, 0, 0, 0)))
        if item.get("is_outside_text", False):
            draw.rectangle(bbox, outline=osb_color, width=2)
            draw_bbox = bbox
        else:
            mask_bbox = (
                _debug_mask_bbox(bubble_masks.get(bbox)) if bubble_masks else None
            )
            draw_bbox = tuple(mask_bbox) if mask_bbox is not None else bbox
            _draw_dashed_rectangle(draw, draw_bbox, bubble_color, width=2)
        _draw_centered_index(draw, draw_bbox, item_index, font, index_color)

    base_path = Path(output_path) if output_path else Path(image_path)
    debug_path = base_path.parent / f"{base_path.stem}.component-order-debug.png"
    debug_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.convert("RGB").save(debug_path, format="PNG")
    log_message(
        f"Wrote component-order debug image: {debug_path}",
        verbose=verbose,
        always_print=True,
    )


def _write_llm_crop_debug_images(
    sorted_items,
    image_path,
    output_path,
    verbose=False,
):
    """Save the exact image crops the LLM sees to a debug subfolder."""
    base_path = Path(output_path) if output_path else Path(image_path)
    crop_dir = base_path.parent / f"{base_path.stem}.llm-crops"
    crop_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    for i, item in enumerate(sorted_items, start=1):
        img_b64 = item.get("image_b64")
        if not img_b64:
            continue
        try:
            img_bytes = base64.b64decode(img_b64)
            img_arr = np.frombuffer(img_bytes, dtype=np.uint8)
            img_cv = cv2.imdecode(img_arr, cv2.IMREAD_COLOR)
            if img_cv is None:
                continue
            label = "osb" if item.get("is_outside_text", False) else "bubble"
            crop_path = crop_dir / f"{i:03d}_{label}.png"
            cv2.imwrite(str(crop_path), img_cv)
            count += 1
        except Exception:
            pass

    log_message(
        f"Wrote {count} LLM crop debug images to: {crop_dir}",
        verbose=verbose,
        always_print=True,
    )


def _resolve_pre_upscale_factor(
    pre_cfg: Optional[PreprocessingConfig],
    verbose: bool = False,
) -> float:
    if pre_cfg is None or not pre_cfg.enabled:
        return 1.0

    factor = max(1.0, min(float(pre_cfg.factor or 1.0), 8.0))
    if factor <= 1.01:
        return 1.0

    log_message(f"Initial upscaling enabled: {factor:.2f}x", verbose=verbose)
    return factor


def _apply_pre_upscale_if_needed(
    image: Image.Image,
    config: MangaTranslatorConfig,
    verbose: bool = False,
) -> Tuple[Image.Image, float]:
    factor = _resolve_pre_upscale_factor(
        getattr(config, "preprocessing", None), verbose
    )
    if factor == 1.0:
        return image, 1.0

    # Use the output upscale model setting for initial upscaling as well
    model_type = (
        getattr(config.output, "image_upscale_model", "model_lite")
        if hasattr(config, "output")
        else "model_lite"
    )
    upscaled = upscale_image(image, factor, model_type=model_type, verbose=verbose)
    return upscaled, factor


def translate_and_render(
    image_path: Union[str, Path],
    config: MangaTranslatorConfig,
    output_path: Optional[Union[str, Path]] = None,
    cancellation_manager: Optional["CancellationManager"] = None,
    previous_context_images: Optional[List[Dict[str, str]]] = None,
    previous_context_texts: Optional[List[List[str]]] = None,
    previous_context_texts_provider: Optional[Callable[[], List[List[str]]]] = None,
    ocr_texts_out: Optional[List[str]] = None,
    manual_checkpoint_save_path: Optional[Union[str, Path]] = None,
    manual_checkpoint_load_path: Optional[Union[str, Path]] = None,
    manual_translations: Optional[Dict[str, Any]] = None,
):
    """
    Main function to translate manga speech bubbles and render translations using a config object.

    Args:
        image_path (str or Path): Path to input image
        config (MangaTranslatorConfig): Configuration object containing all settings.
        output_path (str or Path, optional): Path to save the final image. If None, image is not saved.
        previous_context_images: Batch-only previous source page images for LLM reference.
        previous_context_texts: Batch-only previous source page OCR transcripts for LLM reference
            (oldest-to-newest, one inner list per page).
        previous_context_texts_provider: Optional callback used to fetch previous-page
            OCR transcripts immediately before the translation API call.
        ocr_texts_out: Optional mutable list. When provided, the current page's OCR transcripts
            (in reading order) are appended so the orchestrator can chain them as previous-page
            text context for subsequent pages.
        manual_checkpoint_save_path: Manual translation mode, Pass 1. When provided, detection,
            cleaning, and OCR (transcription only - no translation API call) run as normal, the
            resulting state (cleaned image, bubble geometry/masks, per-bubble OCR text) is
            pickled to this path, and the function returns early with the cleaned-but-untranslated
            image. Rendering is skipped entirely in this pass.
        manual_checkpoint_load_path: Manual translation mode, Pass 2. When provided, detection,
            cleaning, and OCR are skipped entirely; the checkpoint written via
            manual_checkpoint_save_path is loaded from this path and rendering resumes directly
            from it using `manual_translations`. All other args except `output_path` and
            `manual_translations` are ignored in this mode.
        manual_translations: Manual translation mode, Pass 2. Mapping of bubble_id -> either a
            plain translated-text string, or a dict {"translation": str, "sfx": bool} (see
            compute_bubble_id / the "bubble_id" field written into each checkpoint bubble entry).
            "sfx" is only honored for OSB items: when true, rendering is skipped for that item and
            its original (already-cleaned) pixels are left untouched, mirroring the automatic
            [SFX]-marker skip-inpaint behavior from the non-manual translation flow. A bubble whose
            id is missing or has empty text falls back to that bubble's captured OCR text
            (untranslated) so the page still renders in full.

    Returns:
        PIL.Image: Final translated image
    """
    if manual_checkpoint_load_path is not None:
        return _render_from_manual_checkpoint(
            manual_checkpoint_load_path,
            manual_translations or {},
            output_path=output_path,
            config=config,
            verbose=getattr(config, "verbose", False),
        )

    start_time = time.time()
    validate_config(config)
    image_path = Path(image_path)
    verbose = config.verbose
    device = config.device
    previous_context_images = previous_context_images or []
    previous_context_texts = previous_context_texts or []
    config.translation.request_coordinator = getattr(
        config, "request_coordinator", None
    )

    log_message(f"Using device: {device}", verbose=verbose)

    # Set global HF token for model downloads
    hf_token = config.outside_text.huggingface_token
    get_model_manager().set_hf_token(hf_token)

    try:
        pil_original = Image.open(image_path)
        image_format = pil_original.format
        mime_type, cv2_ext = get_image_encoding_params(image_format)
        log_message(
            f"Original image format: {image_format} -> MIME: {mime_type}",
            verbose=verbose,
        )
    except FileNotFoundError:
        log_message(f"Error: Input image not found at {image_path}", always_print=True)
        raise
    except Exception as e:
        log_message(f"Error opening image {image_path}: {e}", always_print=True)
        raise

    if cancellation_manager and cancellation_manager.is_cancelled():
        raise TranslationError("Process cancelled by user.")

    desired_format = config.output.output_format
    output_ext_for_mode = (
        Path(output_path).suffix.lower() if output_path else image_path.suffix.lower()
    )

    if desired_format == "jpeg" or (
        desired_format == "auto" and output_ext_for_mode in [".jpg", ".jpeg"]
    ):
        target_mode = "RGB"
    else:  # Default to RGBA for PNG, WEBP, or other formats in auto mode
        target_mode = "RGBA"
    log_message(f"Target mode: {target_mode}", verbose=verbose)

    pil_image_processed = convert_image_to_target_mode(
        pil_original, target_mode, verbose
    )
    pil_image_processed, _ = _apply_pre_upscale_if_needed(
        pil_image_processed, config, verbose
    )
    # Pristine page (pre-cleaning) used to restore skipped regions halo-free.
    pil_page_original = pil_image_processed.copy()

    # Check for Upscaling Only Mode (skip detection, cleaning, and translation)
    if config.upscaling_only:
        log_message(
            "Upscaling only mode - skipping detection and translation",
            always_print=True,
        )
        final_image_to_save = pil_image_processed

        if config.output.upscale_final_image:
            log_message("Upscaling final image...", verbose=verbose, always_print=True)
            final_image_to_save = upscale_image(
                final_image_to_save,
                config.output.image_upscale_factor,
                model_type=config.output.image_upscale_model,
                verbose=verbose,
            )

        if output_path:
            if final_image_to_save.mode != target_mode:
                log_message(f"Converting final image to {target_mode}", verbose=verbose)
                final_image_to_save = final_image_to_save.convert(target_mode)

            try:
                save_image_with_compression(
                    final_image_to_save,
                    output_path,
                    jpeg_quality=config.output.jpeg_quality,
                    png_compression=config.output.png_compression,
                    verbose=verbose,
                )
            except ImageProcessingError as e:
                log_message(f"Failed to save image: {e}", always_print=True)
                raise

        end_time = time.time()
        processing_time = end_time - start_time
        log_message(
            f"Processing completed in {processing_time:.2f}s", always_print=True
        )

        return final_image_to_save

    # Calculate dynamic processing scale based on image area relative to 1MP (if enabled)
    if config.preprocessing.auto_scale:
        width, height = pil_image_processed.size
        processing_scale = math.sqrt((width * height) / 1_000_000)
        log_message(
            f"Dynamic processing scale: {processing_scale:.2f}x", verbose=verbose
        )
    else:
        processing_scale = 1.0

    get_cache().set_current_image(pil_image_processed, verbose)

    original_cv_image = pil_to_cv2(pil_image_processed)
    full_page_context_source = pil_image_processed.copy()

    # Detect speech bubbles first so OSB processing can respect bubble regions
    log_message("Detecting speech bubbles...", verbose=verbose)
    try:
        bubble_data, text_free_boxes = detect_speech_bubbles(
            image_path,
            config.yolo_model_path,
            config.detection.confidence,
            verbose=verbose,
            device=device,
            seg_model=config.detection.seg_model,
            conjoined_detection=config.detection.conjoined_detection,
            conjoined_confidence=config.detection.conjoined_confidence,
            image_override=pil_image_processed,
            osb_enabled=config.outside_text.enabled,
            osb_text_verification=config.detection.use_osb_text_verification,
            osb_text_hf_token=config.outside_text.huggingface_token,
            bubble_detector_model=config.detection.bubble_detector_model,
            iou_duplicate_threshold=config.detection.iou_duplicate_threshold,
        )
    except Exception as e:
        log_message(f"Error during detection: {e}", always_print=True)
        bubble_data = []
        text_free_boxes = []

    panels = None
    debug_panels = None
    if config.detection.use_panel_sorting or ENABLE_COMPONENT_ORDER_DEBUG:
        try:
            log_message(
                "Detecting panels...",
                verbose=verbose,
            )
            debug_panels = detect_panels(
                image_path,
                confidence=config.detection.panel_confidence,
                device=device,
                verbose=verbose,
            )
            if debug_panels:
                log_message(
                    f"Detected {len(debug_panels)} panels",
                    always_print=True,
                )
            else:
                log_message(
                    "No panels detected",
                    verbose=verbose,
                )
        except Exception as e:
            log_message(
                f"Panel detection failed: {e}. Using global sorting.",
                always_print=True,
            )
            debug_panels = None

        if config.detection.use_panel_sorting:
            panels = debug_panels

    # Process outside text (detect always; defer inpainting whenever OSB
    # SFX-skip is enabled OR the user asked for LLM/inpaint overlap - both
    # need the model's is_sfx flags, which only exist after translation runs,
    # so inpainting must happen after translation rather than before/during
    # it. Only when neither applies do we take the eager (detect+inpaint
    # immediately) path.
    sfx_skip_inpaint_enabled = bool(
        getattr(config.outside_text, "sfx_skip_inpaint", True)
    )
    use_llm_inpaint_overlap = _should_overlap_llm_with_inpaint(
        config, manual_checkpoint_save_path
    )
    defer_osb_inpaint = (
        use_llm_inpaint_overlap or sfx_skip_inpaint_enabled
    ) and not config.cleaning_only and not getattr(config, "test_mode", False)
    outside_work = None
    skip_restore_bboxes: List[Tuple[int, int, int, int]] = []
    keep_restore_bboxes: List[Tuple[int, int, int, int]] = []
    if defer_osb_inpaint:
        outside_work = prepare_outside_text_work(
            pil_image_processed,
            config,
            image_path,
            image_format,
            verbose,
            bubble_data=bubble_data,
            text_free_boxes=text_free_boxes,
            panels=panels,
        )
        outside_text_data = (
            outside_work.outside_text_data if outside_work is not None else []
        )
        # Bubble/OSB LLM crops use the pre-inpaint page image
        original_cv_image = pil_to_cv2(pil_image_processed)
    else:
        pil_image_processed, outside_text_data = process_outside_text(
            pil_image_processed,
            config,
            image_path,
            image_format,
            verbose,
            bubble_data=bubble_data,
            text_free_boxes=text_free_boxes,
            panels=panels,
        )
        original_cv_image = pil_to_cv2(pil_image_processed)

    full_image_b64 = None
    full_image_mime_type = None
    if config.translation.send_full_page_context:
        try:
            # processing_scale is intentionally not used for context_image_max_side_pixels
            context_image_pil = full_page_context_source.copy()
            effective_context_max_side = scale_length(
                config.translation.context_image_max_side_pixels,
                None,
                minimum=512,
                maximum=4096,
            )

            # Disable upscaling in test_mode
            context_upscale_method = (
                "none" if config.test_mode else config.translation.upscale_method
            )

            if context_upscale_method in ("model", "model_lite"):
                model_manager = get_model_manager()
                if context_upscale_method == "model":
                    upscale_model = model_manager.load_upscale(verbose=verbose)
                else:
                    upscale_model = model_manager.load_upscale_lite(verbose=verbose)
                context_image_pil = upscale_image_to_dimension(
                    upscale_model,
                    context_image_pil,
                    effective_context_max_side,
                    config.device,
                    "max",
                    context_upscale_method,
                    verbose,
                )
                context_image_pil = resize_to_max_side(
                    context_image_pil,
                    effective_context_max_side,
                    verbose=verbose,
                )
                model_manager.clear_cache()
                log_message(
                    f"Upscaled full image for context with {context_upscale_method}",
                    verbose=verbose,
                )
            elif context_upscale_method == "lanczos":
                # Use LANCZOS resampling
                context_image_pil = resize_to_max_side(
                    context_image_pil,
                    effective_context_max_side,
                    verbose=verbose,
                )
                log_message(
                    "Resized full image for context with LANCZOS", verbose=verbose
                )
            else:  # upscale_method == "none"
                # No resizing/upscaling
                log_message(
                    "Using full image for context without resizing", verbose=verbose
                )

            context_image_cv = pil_to_cv2(context_image_pil)
            is_success, buffer = cv2.imencode(cv2_ext, context_image_cv)
            if not is_success:
                raise ImageProcessingError(f"Full image encoding to {cv2_ext} failed")
            full_image_b64 = base64.b64encode(buffer).decode("utf-8")
            full_image_mime_type = mime_type
            log_message("Encoded full image for context", verbose=verbose)
        except Exception as e:
            log_message(
                f"Warning: Failed to encode full image context: {e}", always_print=True
            )

    if cancellation_manager and cancellation_manager.is_cancelled():
        raise CancellationError("Process cancelled by user.")

    final_image_to_save = pil_image_processed

    if not bubble_data and not outside_text_data:
        log_message("No speech bubbles or outside text detected", always_print=True)
        if manual_checkpoint_save_path is not None:
            save_manual_checkpoint(
                manual_checkpoint_save_path,
                pil_cleaned_image=final_image_to_save,
                sorted_bubble_data=[],
                processed_bubbles_info=[],
                outside_text_data=[],
                ocr_texts=[],
                target_mode=target_mode,
                image_path=image_path,
                config=config,
            )
            if output_path:
                final_to_save = final_image_to_save
                if final_to_save.mode != target_mode:
                    final_to_save = final_to_save.convert(target_mode)
                try:
                    save_image_with_compression(
                        final_to_save,
                        output_path,
                        jpeg_quality=config.output.jpeg_quality,
                        png_compression=config.output.png_compression,
                        verbose=verbose,
                    )
                except ImageProcessingError as e:
                    log_message(
                        f"Failed to save cleaned preview image: {e}",
                        always_print=True,
                    )
            log_message(
                "Manual mode Pass 1 checkpoint saved (no bubbles or outside text on this page)",
                always_print=True,
            )
            return final_image_to_save
    else:
        if bubble_data:
            log_message(f"Detected {len(bubble_data)} bubbles", verbose=verbose)
        if outside_text_data:
            log_message(
                f"Detected {len(outside_text_data)} outside text regions",
                verbose=verbose,
            )

        if cancellation_manager and cancellation_manager.is_cancelled():
            raise CancellationError("Process cancelled by user.")

        processed_bubbles_info: List[Dict[str, Any]] = []
        pil_cleaned_image = pil_image_processed
        if not use_llm_inpaint_overlap:
            if bubble_data:
                log_message("Cleaning speech bubbles...", verbose=verbose)
                cleaned_image_cv, processed_bubbles_info = (
                    _clean_speech_bubbles_for_page(
                        pil_image_processed,
                        bubble_data,
                        config,
                        device,
                        processing_scale,
                        verbose,
                        original_cv_image,
                    )
                )
                pil_cleaned_image = cv2_to_pil(cleaned_image_cv)
                if pil_cleaned_image.mode != target_mode:
                    log_message(
                        f"Converting cleaned image to {target_mode}", verbose=verbose
                    )
                    pil_cleaned_image = pil_cleaned_image.convert(target_mode)
                final_image_to_save = pil_cleaned_image
            else:
                processed_bubbles_info = []
                pil_cleaned_image = pil_image_processed
                if pil_cleaned_image.mode != target_mode:
                    log_message(f"Converting image to {target_mode}", verbose=verbose)
                    pil_cleaned_image = pil_cleaned_image.convert(target_mode)
                final_image_to_save = pil_cleaned_image
        else:
            # Cleaning deferred until it can run concurrently with the LLM
            if pil_cleaned_image.mode != target_mode:
                pil_cleaned_image = pil_cleaned_image.convert(target_mode)
            final_image_to_save = pil_cleaned_image

        # Check for Cleaning Only Mode
        if config.cleaning_only:
            log_message("Cleaning only mode - skipping translation", always_print=True)
        else:
            main_min_font = scale_font_size(
                config.rendering.min_font_size, processing_scale, minimum=4, maximum=256
            )
            main_max_font = scale_font_size(
                config.rendering.max_font_size,
                processing_scale,
                minimum=main_min_font,
                maximum=384,
            )
            padding_pixels = scale_scalar(
                config.rendering.padding_pixels,
                processing_scale,
                minimum=1.0,
                maximum=80.0,
            )
            osb_min_font = scale_font_size(
                config.outside_text.osb_min_font_size,
                processing_scale,
                minimum=4,
                maximum=512,
            )
            osb_max_font = scale_font_size(
                config.outside_text.osb_max_font_size,
                processing_scale,
                minimum=osb_min_font,
                maximum=640,
            )
            osb_outline_width = scale_scalar(
                config.outside_text.osb_outline_width,
                processing_scale,
                minimum=0.0,
                maximum=24.0,
            )
            # Prepare images for Translation
            log_message("Preparing bubble images...", verbose=verbose)

            # Enrich bubble_data with refined cleaning masks
            if processed_bubbles_info:
                _mask_lut: Dict[tuple, Any] = {}
                for _info in processed_bubbles_info:
                    _bk = tuple(int(round(v)) for v in _info.get("bbox", ()))
                    if len(_bk) != 4:
                        continue
                    _m = _info.get("mask")
                    if _m is None:
                        _m = _info.get("base_mask")
                    if _m is not None:
                        _mask_lut[_bk] = _m
                for _b in bubble_data:
                    _bk = tuple(int(round(v)) for v in _b.get("bbox", ()))
                    if _bk in _mask_lut:
                        _b["sam_mask"] = _mask_lut[_bk]

            # Disable upscaling in test_mode
            bubble_upscale_method = (
                "none" if config.test_mode else config.translation.upscale_method
            )

            model_manager = get_model_manager()
            upscale_model = None
            if bubble_upscale_method == "model":
                upscale_model = model_manager.load_upscale(verbose=verbose)
            elif bubble_upscale_method == "model_lite":
                upscale_model = model_manager.load_upscale_lite(verbose=verbose)

            bubble_data = prepare_bubble_images_for_translation(
                bubble_data,
                original_cv_image,
                upscale_model,
                config.device,
                mime_type,
                config.translation.bubble_min_side_pixels,
                bubble_upscale_method,
                config.translation.whiteout_conjoined_bubbles,
                verbose,
            )
            if upscale_model is not None:
                model_manager.clear_cache()

            if bubble_upscale_method != "none":
                log_message(
                    f"Upscaled {len(bubble_data)} bubble images for translation",
                    always_print=True,
                )
            else:
                log_message(
                    f"Prepared {len(bubble_data)} bubble images for translation",
                    always_print=True,
                )
            valid_bubble_data = [b for b in bubble_data if b.get("image_b64")]
            if not valid_bubble_data and not outside_text_data:
                log_message(
                    "No valid bubble images or outside text for translation",
                    always_print=True,
                )
                if manual_checkpoint_save_path is not None:
                    save_manual_checkpoint(
                        manual_checkpoint_save_path,
                        pil_cleaned_image=pil_cleaned_image,
                        sorted_bubble_data=[],
                        processed_bubbles_info=processed_bubbles_info,
                        outside_text_data=[],
                        ocr_texts=[],
                        target_mode=target_mode,
                        image_path=image_path,
                        config=config,
                    )
                    if output_path:
                        final_to_save = pil_cleaned_image
                        if final_to_save.mode != target_mode:
                            final_to_save = final_to_save.convert(target_mode)
                        try:
                            save_image_with_compression(
                                final_to_save,
                                output_path,
                                jpeg_quality=config.output.jpeg_quality,
                                png_compression=config.output.png_compression,
                                verbose=verbose,
                            )
                        except ImageProcessingError as e:
                            log_message(
                                f"Failed to save cleaned preview image: {e}",
                                always_print=True,
                            )
                    log_message(
                        "Manual mode Pass 1 checkpoint saved (no bubbles on this page)",
                        always_print=True,
                    )
                    return pil_cleaned_image
                if defer_osb_inpaint and (
                    outside_work is not None or bubble_data
                ):
                    page_image = pil_image_processed
                    osb_data = outside_text_data
                    if outside_work is not None:
                        page_image, osb_data = finish_outside_text_work(outside_work)
                    fallback_cv = pil_to_cv2(page_image)
                    if bubble_data:
                        log_message("Cleaning speech bubbles...", verbose=verbose)
                        cleaned_image_cv, processed_bubbles_info = (
                            _clean_speech_bubbles_for_page(
                                page_image,
                                bubble_data,
                                config,
                                device,
                                processing_scale,
                                verbose,
                                fallback_cv,
                            )
                        )
                    else:
                        cleaned_image_cv = fallback_cv
                        processed_bubbles_info = []
                    pil_image_processed = page_image
                    outside_text_data = osb_data
                    pil_cleaned_image = cv2_to_pil(cleaned_image_cv)
                    if pil_cleaned_image.mode != target_mode:
                        pil_cleaned_image = pil_cleaned_image.convert(target_mode)
                    final_image_to_save = pil_cleaned_image
            else:  # Proceed if we have valid bubble data or outside text
                if cancellation_manager and cancellation_manager.is_cancelled():
                    raise CancellationError("Process cancelled by user.")

                # Sort and Translate
                reading_direction = config.translation.reading_direction
                # Merge outside text data with speech bubbles for reading order calculation
                if outside_text_data:
                    log_message(
                        f"Including {len(outside_text_data)} outside text regions in reading order calculation",
                        verbose=verbose,
                    )
                    # Combine speech bubbles and OSB text for unified reading order sorting
                    all_text_data = valid_bubble_data + outside_text_data
                else:
                    all_text_data = valid_bubble_data

                # Tall manhwa/webtoon pages: drop the same bubble detected twice
                # (bubble+bubble or bubble+OSB) so it is not translated/drawn twice.
                try:
                    all_text_data = dedupe_overlapping_text_items(
                        all_text_data,
                        img_w=pil_original.width,
                        img_h=pil_original.height,
                        verbose=verbose,
                    )
                except Exception as _dd_exc:
                    log_message(f"Duplicate-box cleanup skipped: {_dd_exc}", verbose=verbose)

                log_message(
                    f"Sorting all text elements ({reading_direction.upper()})",
                    verbose=verbose,
                )

                panels = None
                debug_panels = None
                if ENABLE_COMPONENT_ORDER_DEBUG:
                    try:
                        log_message(
                            "Detecting panels for ordering debug...",
                            verbose=verbose,
                        )
                        debug_panels = detect_panels(
                            image_path,
                            confidence=config.detection.panel_confidence,
                            device=config.device,
                            verbose=verbose,
                        )
                        if debug_panels:
                            log_message(
                                f"Detected {len(debug_panels)} panels",
                                always_print=True,
                            )
                        else:
                            log_message(
                                "No panels detected",
                                verbose=verbose,
                            )
                    except Exception as e:
                        log_message(
                            f"Panel detection failed: {e}. Using global sorting.",
                            always_print=True,
                        )
                        debug_panels = None

                    if config.detection.use_panel_sorting:
                        panels = debug_panels
                elif config.detection.use_panel_sorting:
                    try:
                        log_message(
                            "Detecting panels for panel-aware sorting...",
                            verbose=verbose,
                        )
                        panels = detect_panels(
                            image_path,
                            confidence=config.detection.panel_confidence,
                            device=config.device,
                            verbose=verbose,
                        )
                        if panels:
                            log_message(
                                f"Detected {len(panels)} panels for sorting",
                                always_print=True,
                            )
                        else:
                            log_message(
                                "No panels detected, using global sorting",
                                verbose=verbose,
                            )
                    except Exception as e:
                        log_message(
                            f"Panel detection failed: {e}. Using global sorting.",
                            always_print=True,
                        )
                        panels = None

                # Sort all text elements (speech bubbles + OSB text) by reading order
                sorted_bubble_data = sort_bubbles_by_reading_order(
                    all_text_data, reading_direction, panels=panels
                )
                if ENABLE_COMPONENT_ORDER_DEBUG:
                    bubble_debug_masks = {}
                    for bubble in sorted_bubble_data:
                        if bubble.get("is_outside_text", False):
                            continue
                        bbox = tuple(int(round(v)) for v in bubble.get("bbox", ()))
                        if len(bbox) != 4:
                            continue
                        mask = bubble.get("sam_mask")
                        if mask is not None:
                            bubble_debug_masks[bbox] = mask

                    for info in processed_bubbles_info:
                        bbox = tuple(int(round(v)) for v in info.get("bbox", ()))
                        if len(bbox) != 4:
                            continue
                        mask = info.get("mask")
                        if mask is None:
                            mask = info.get("base_mask")
                        if mask is not None:
                            bubble_debug_masks[bbox] = mask

                    try:
                        _write_component_order_debug_image(
                            pil_image_processed.size,
                            sorted_bubble_data,
                            debug_panels,
                            bubble_debug_masks,
                            reading_direction,
                            image_path,
                            output_path,
                            verbose=verbose,
                        )
                    except Exception as e:
                        log_message(
                            f"Failed to write component-order debug image: {e}",
                            always_print=True,
                        )

                    try:
                        _write_llm_crop_debug_images(
                            sorted_bubble_data,
                            image_path,
                            output_path,
                            verbose=verbose,
                        )
                    except Exception as e:
                        log_message(
                            f"Failed to write LLM crop debug images: {e}",
                            always_print=True,
                        )

                bubble_images_b64 = [
                    bubble["image_b64"]
                    for bubble in sorted_bubble_data
                    if "image_b64" in bubble
                ]
                bubble_mime_types = [
                    bubble["mime_type"]
                    for bubble in sorted_bubble_data
                    if "image_b64" in bubble and "mime_type" in bubble
                ]

                if manual_checkpoint_save_path is not None:
                    # Manual translation mode, Pass 1: run OCR only (no translation
                    # API call), then checkpoint everything Pass 2 needs and stop
                    # before rendering. Detection/cleaning above already ran once;
                    # this is the only extra network call this pass makes.
                    #
                    # OSB inpainting is normally deferred until after translation
                    # (so the LLM's per-item is_sfx flags can exclude SFX regions
                    # from cleaning). Manual Pass 1 never translates, so it has no
                    # is_sfx flags yet - inpaint every OSB region now instead of
                    # leaving the original (un-inpainted) text in the checkpoint
                    # image, which would otherwise show through underneath the
                    # translated text Pass 2 renders on top of it. Pass 2 can
                    # still honor a human "sfx" flag from the edited JSON by
                    # pasting back original_crop_pil (captured pre-inpaint,
                    # before this call), so marking something SFX in the JSON
                    # still restores the original pixels correctly.
                    if outside_work is not None:
                        pil_image_processed, outside_text_data = (
                            finish_outside_text_work(outside_work)
                        )
                        outside_work = None
                        # finish_outside_text_work() only inpaints OSB text on the
                        # original page - it knows nothing about speech bubbles.
                        # Re-run speech-bubble cleaning on top of that OSB-cleaned
                        # page (mirroring _run_deferred_inpaint_and_clean() below)
                        # instead of overwriting pil_cleaned_image with it directly,
                        # or the bubble inpainting done earlier at the top of this
                        # function gets silently discarded and Pass 2 renders text
                        # over un-inpainted bubbles.
                        if bubble_data:
                            log_message(
                                "Cleaning speech bubbles...", verbose=verbose
                            )
                            cleaned_image_cv, processed_bubbles_info = (
                                _clean_speech_bubbles_for_page(
                                    pil_image_processed,
                                    bubble_data,
                                    config,
                                    device,
                                    processing_scale,
                                    verbose,
                                    pil_to_cv2(pil_image_processed),
                                )
                            )
                            pil_cleaned_image = cv2_to_pil(cleaned_image_cv)
                        else:
                            pil_cleaned_image = pil_image_processed
                        if pil_cleaned_image.mode != target_mode:
                            pil_cleaned_image = pil_cleaned_image.convert(target_mode)
                        final_image_to_save = pil_cleaned_image

                    manual_ocr_texts: List[str] = []
                    if bubble_images_b64:
                        try:
                            manual_ocr_texts = perform_ocr_only_batch(
                                config=config.translation,
                                images_b64=bubble_images_b64,
                                mime_types=bubble_mime_types,
                                bubble_metadata=sorted_bubble_data,
                                debug=verbose,
                            )
                        except Exception as e:
                            log_message(
                                f"Manual mode OCR failed: {e}", always_print=True
                            )
                            manual_ocr_texts = ["[OCR FAILED]"] * len(
                                bubble_images_b64
                            )
                    save_manual_checkpoint(
                        manual_checkpoint_save_path,
                        pil_cleaned_image=pil_cleaned_image,
                        sorted_bubble_data=sorted_bubble_data,
                        processed_bubbles_info=processed_bubbles_info,
                        outside_text_data=outside_text_data,
                        ocr_texts=manual_ocr_texts,
                        target_mode=target_mode,
                        image_path=image_path,
                        config=config,
                    )
                    if output_path:
                        final_to_save = pil_cleaned_image
                        if final_to_save.mode != target_mode:
                            final_to_save = final_to_save.convert(target_mode)
                        try:
                            save_image_with_compression(
                                final_to_save,
                                output_path,
                                jpeg_quality=config.output.jpeg_quality,
                                png_compression=config.output.png_compression,
                                verbose=verbose,
                            )
                        except ImageProcessingError as e:
                            log_message(
                                f"Failed to save cleaned preview image: {e}",
                                always_print=True,
                            )
                    log_message(
                        "Manual mode Pass 1 checkpoint saved "
                        f"({len(manual_ocr_texts)} bubble(s) OCR'd)",
                        always_print=True,
                    )
                    return pil_cleaned_image

                translated_texts = []
                current_ocr_texts: List[str] = []
                current_sfx_flags: List[bool] = []
                _provider_tag = f"[{config.translation.provider}:"

                def _run_deferred_inpaint_and_clean():
                    page_image = pil_image_processed
                    osb_data = outside_text_data
                    if outside_work is not None:
                        page_image, osb_data = finish_outside_text_work(outside_work)
                    fallback_cv = pil_to_cv2(page_image)
                    clean_info: List[Dict[str, Any]] = []
                    if bubble_data:
                        log_message("Cleaning speech bubbles...", verbose=verbose)
                        cleaned_cv, clean_info = _clean_speech_bubbles_for_page(
                            page_image,
                            bubble_data,
                            config,
                            device,
                            processing_scale,
                            verbose,
                            fallback_cv,
                        )
                    else:
                        cleaned_cv = fallback_cv
                    return page_image, osb_data, cleaned_cv, clean_info

                def _run_llm_translation() -> Tuple[List[str], List[str], List[bool]]:
                    ocr_texts: List[str] = []
                    sfx_flags: List[bool] = []
                    if previous_context_texts_provider is not None:
                        resolved_previous_texts = (
                            previous_context_texts_provider() or []
                        )
                    else:
                        resolved_previous_texts = previous_context_texts
                    context_parts = []
                    if previous_context_images:
                        image_page_count = len(previous_context_images)
                        context_parts.append(
                            f"Previous Context Images: {image_page_count} page(s)"
                        )
                    if resolved_previous_texts:
                        usable_context_text_pages = sum(
                            1
                            for page_texts in resolved_previous_texts
                            if any(
                                (text or "").strip()
                                and (text or "").strip() != "[OCR FAILED]"
                                for text in (page_texts or [])
                            )
                        )
                        if usable_context_text_pages:
                            context_parts.append(
                                "Previous Context OCR Text: "
                                f"{usable_context_text_pages} page(s)"
                            )
                    context_suffix = (
                        f" ({', '.join(context_parts)})" if context_parts else ""
                    )
                    log_message(
                        f"Translating {len(bubble_images_b64)} bubbles: "
                        f"{config.translation.input_language} → {config.translation.output_language}"
                        f"{context_suffix}",
                        always_print=True,
                    )
                    texts = call_translation_api_batch(
                        config=config.translation,
                        images_b64=bubble_images_b64,
                        full_image_b64=full_image_b64 or "",
                        mime_types=bubble_mime_types,
                        full_image_mime_type=full_image_mime_type or "image/jpeg",
                        bubble_metadata=sorted_bubble_data,
                        previous_context_images=previous_context_images,
                        previous_context_texts=resolved_previous_texts,
                        ocr_texts_output=ocr_texts,
                        sfx_flags_output=sfx_flags,
                        debug=verbose,
                    )
                    return texts, ocr_texts, sfx_flags

                if not bubble_images_b64:
                    log_message("No valid bubbles after sorting", always_print=True)
                    if defer_osb_inpaint:
                        (
                            pil_image_processed,
                            outside_text_data,
                            cleaned_image_cv,
                            processed_bubbles_info,
                        ) = _run_deferred_inpaint_and_clean()
                        pil_cleaned_image = cv2_to_pil(cleaned_image_cv)
                        if pil_cleaned_image.mode != target_mode:
                            pil_cleaned_image = pil_cleaned_image.convert(target_mode)
                        final_image_to_save = pil_cleaned_image
                else:
                    if getattr(config, "test_mode", False):
                        translated_texts = generate_test_placeholders(
                            sorted_bubble_data=sorted_bubble_data,
                            processed_bubbles_info=processed_bubbles_info,
                            config=config,
                            main_min_font=main_min_font,
                            main_max_font=main_max_font,
                            osb_min_font=osb_min_font,
                            osb_max_font=osb_max_font,
                            padding_pixels=padding_pixels,
                            osb_outline_width=osb_outline_width,
                            verbose=verbose,
                        )
                    elif defer_osb_inpaint:
                        # Translation now runs BEFORE OSB inpaint (sequential, not
                        # concurrent): the model's per-item is_sfx flags must be
                        # known and attached before finish_outside_text_work() runs,
                        # so SFX-flagged OSB regions can be dropped from inpaint and
                        # rendering. This trades the previous overlap speedup
                        # (inpaint and translation used to run in parallel) for
                        # correctness of the SFX-skip feature; only pages with OSB
                        # text detected are affected.
                        log_message(
                            "Running LLM translation before OSB inpaint "
                            "(sequential; required for SFX-skip)",
                            always_print=True,
                        )
                        try:
                            translated_texts, current_ocr_texts, current_sfx_flags = (
                                _run_llm_translation()
                            )
                            if current_ocr_texts and ocr_texts_out is not None:
                                ocr_texts_out.extend(current_ocr_texts)
                        except TranslationError as e:
                            error_str = str(e).lower()
                            critical_tokens = (
                                "429",
                                "rate limit",
                                "rate-limit",
                                "auth",
                                "unauthorized",
                                "forbidden",
                                "payment",
                                "quota",
                                "empty response",
                                "api failed",
                            )
                            if any(token in error_str for token in critical_tokens):
                                raise

                            log_message(f"Translation failed: {e}", always_print=True)
                            translated_texts = [f"[Translation Error: {e}]"] * len(
                                bubble_images_b64
                            )
                        except Exception as e:
                            log_message(
                                f"Translation API error: {e}", always_print=True
                            )
                            translated_texts = [
                                "[Translation Error: API call raised exception]"
                                for _ in sorted_bubble_data
                            ]

                        valid_translations = [
                            t
                            for t in translated_texts
                            if t
                            and not t.startswith("[Translation Error")
                            and not t.startswith("API Error")
                            and not t.startswith(_provider_tag)
                            and t.strip()
                            not in {
                                "[OCR FAILED]",
                                "[Empty response / no content]",
                            }
                        ]

                        if bubble_images_b64 and not valid_translations:
                            raise TranslationError("All bubbles failed.")

                        # Attach is_sfx to each sorted item (OSB items get the
                        # model-derived flag; bubbles are always False regardless
                        # of what parsing returned) so drop_sfx_skip_regions() can
                        # see it via the shared outside_text_data dict objects.
                        sfx_skip_enabled = getattr(
                            config.outside_text, "sfx_skip_inpaint", True
                        )
                        # Pad/truncate instead of disabling skip for the whole
                        # page when the flag count doesn't match.
                        aligned_flags = align_sfx_flags(
                            current_sfx_flags, len(sorted_bubble_data)
                        )
                        ocr_for_skip = list(current_ocr_texts or [])
                        for idx, (bubble, is_sfx) in enumerate(
                            zip(sorted_bubble_data, aligned_flags)
                        ):
                            is_osb = bool(bubble.get("is_outside_text", False))
                            # Model-independent safety net: ads / credits /
                            # watermarks / protected titles are skipped even if
                            # the LLM forgot the [SFX]/[SKIP] tag.
                            ocr_src = (
                                ocr_for_skip[idx]
                                if idx < len(ocr_for_skip)
                                else bubble.get("ocr_text")
                            )
                            heuristic_skip = is_osb and looks_like_non_story_text(
                                ocr_src or bubble.get("ocr_text")
                            )
                            bubble["is_sfx"] = is_osb and (
                                bool(is_sfx) or heuristic_skip
                            )
                            _bb = bubble.get("bbox")
                            if _bb and len(_bb) == 4:
                                _bb = tuple(int(c) for c in _bb)
                                if bubble["is_sfx"]:
                                    skip_restore_bboxes.append(_bb)
                                else:
                                    keep_restore_bboxes.append(_bb)

                        if sfx_skip_enabled and outside_work is not None:
                            drop_sfx_skip_regions(outside_work, verbose=verbose)

                        (
                            pil_image_processed,
                            outside_text_data,
                            cleaned_image_cv,
                            processed_bubbles_info,
                        ) = _run_deferred_inpaint_and_clean()

                        pil_cleaned_image = cv2_to_pil(cleaned_image_cv)
                        if pil_cleaned_image.mode != target_mode:
                            pil_cleaned_image = pil_cleaned_image.convert(target_mode)
                        final_image_to_save = pil_cleaned_image
                    else:
                        try:
                            translated_texts, current_ocr_texts, current_sfx_flags = (
                                _run_llm_translation()
                            )
                            if current_ocr_texts and ocr_texts_out is not None:
                                ocr_texts_out.extend(current_ocr_texts)
                        except TranslationError as e:
                            error_str = str(e).lower()
                            critical_tokens = (
                                "429",
                                "rate limit",
                                "rate-limit",
                                "auth",
                                "unauthorized",
                                "forbidden",
                                "payment",
                                "quota",
                                "empty response",
                                "api failed",
                            )
                            if any(token in error_str for token in critical_tokens):
                                raise

                            log_message(f"Translation failed: {e}", always_print=True)
                            translated_texts = [f"[Translation Error: {e}]"] * len(
                                bubble_images_b64
                            )
                        except Exception as e:
                            log_message(
                                f"Translation API error: {e}", always_print=True
                            )
                            translated_texts = [
                                "[Translation Error: API call raised exception]"
                                for _ in sorted_bubble_data
                            ]

                        valid_translations = [
                            t
                            for t in translated_texts
                            if t
                            and not t.startswith("[Translation Error")
                            and not t.startswith("API Error")
                            and not t.startswith(_provider_tag)
                            and t.strip()
                            not in {
                                "[OCR FAILED]",
                                "[Empty response / no content]",
                            }
                        ]

                        if bubble_images_b64 and not valid_translations:
                            raise TranslationError("All bubbles failed.")

                if current_ocr_texts:
                    if len(current_ocr_texts) == len(sorted_bubble_data):
                        for bubble, ocr_text in zip(
                            sorted_bubble_data, current_ocr_texts
                        ):
                            bubble["ocr_text"] = ocr_text
                    else:
                        log_message(
                            "OCR/translation count mismatch; OSB unchanged-text restore disabled",
                            verbose=verbose,
                        )

                # Non-overlap path (OSB already inpainted before translation) and
                # test-mode placeholders never attach is_sfx above; default it here
                # so downstream consumers (Manual JSON checkpoint, UI) can always
                # rely on the key being present. Bubbles are always False.
                for bubble in sorted_bubble_data:
                    if "is_sfx" not in bubble:
                        bubble["is_sfx"] = False

                # Render Translations
                bubble_render_info_map = {
                    tuple(info["bbox"]): {
                        "color": info["color"],
                        "mask": info.get("mask"),
                        "base_mask": info.get("base_mask"),
                        "is_sam": info.get("is_sam", False),
                        "is_colored": info.get("is_colored", False),
                        "text_bbox": info.get("text_bbox"),
                        "text_color_bgr": info.get("text_color_bgr"),
                        "text_median_line_height": info.get(
                            "text_median_line_height"
                        ),
                        "lettering_style": info.get("lettering_style"),
                    }
                    for info in processed_bubbles_info
                    if "bbox" in info and "color" in info and "mask" in info
                }
                log_message("Rendering translations...", verbose=verbose)
                if len(translated_texts) == len(sorted_bubble_data):
                    invalid_translation_values = {
                        "[OCR FAILED]",
                        "[Empty response / no content]",
                    }
                    # Strip sentences that ended up in two bubbles (merged
                    # read of neighbouring bubbles, or bubble + OSB twin).
                    try:
                        translated_texts = dedupe_translation_texts(
                            [b.get("bbox") for b in sorted_bubble_data],
                            list(translated_texts),
                            [bool(b.get("is_outside_text", False)) for b in sorted_bubble_data],
                            verbose=verbose,
                        )
                    except Exception as _tdd_exc:
                        log_message(
                            f"Text duplicate cleanup skipped: {_tdd_exc}", verbose=verbose
                        )
                    for i, bubble in enumerate(sorted_bubble_data):
                        bubble["translation"] = translated_texts[i]
                        bbox = bubble["bbox"]
                        text = bubble.get("translation", "")
                        is_outside_text = bubble.get("is_outside_text", False)

                        if (
                            not text
                            or text.startswith("API Error")
                            or text.startswith("[Translation Error]")
                            or text.startswith("[Translation Error:")
                            or text.startswith(_provider_tag)
                            or text.strip() in invalid_translation_values
                        ):
                            entry_type = "outside text" if is_outside_text else "bubble"
                            log_message(
                                f"Skipping {entry_type} {bbox} - invalid translation",
                                verbose=verbose,
                            )
                            continue

                        if is_outside_text:
                            if bubble.get("is_sfx", False) and "original_crop_pil" in bubble:
                                # SFX-flagged OSB item: skip rendering entirely and
                                # leave the original (never-inpainted, thanks to
                                # drop_sfx_skip_regions) pixels untouched. This is
                                # the render-side half of the SFX-skip feature -
                                # drop_sfx_skip_regions() only prevents the inpaint;
                                # this prevents drawing translated text on top of
                                # those same original pixels.
                                log_message(
                                    "Restoring original OSB patch - SFX-flagged, "
                                    f"skipping render for {bbox}",
                                    verbose=verbose,
                                    always_print=True,
                                )
                                rendered_image = pil_cleaned_image.copy()
                                original_patch = bubble["original_crop_pil"]
                                rendered_image.paste(original_patch, (bbox[0], bbox[1]))
                                pil_cleaned_image = rendered_image
                                final_image_to_save = pil_cleaned_image
                                continue

                            ocr_text = (bubble.get("ocr_text") or "").strip()
                            if (
                                ocr_text
                                and ocr_text not in invalid_translation_values
                                and ocr_text == text.strip()
                                and "original_crop_pil" in bubble
                            ):
                                log_message(
                                    "Restoring original OSB patch because OCR matches translation "
                                    f"for {bbox}",
                                    verbose=verbose,
                                    always_print=True,
                                )
                                rendered_image = pil_cleaned_image.copy()
                                original_patch = bubble["original_crop_pil"]
                                rendered_image.paste(original_patch, (bbox[0], bbox[1]))
                                pil_cleaned_image = rendered_image
                                final_image_to_save = pil_cleaned_image
                                continue

                            text = text.upper()
                            bubble["translation"] = text

                        # Use OSB-specific settings for outside text, regular settings for speech bubbles
                        target_font_size = None
                        glow_color = None
                        glow_radius = 0.0
                        outline_color = None
                        outline_width_override = None
                        if is_outside_text:
                            log_message(
                                f"Rendering outside text {bbox}: '{text[:30]}...'",
                                verbose=verbose,
                            )
                            font_dir = (
                                config.outside_text.osb_font_dir
                                if config.outside_text.osb_font_dir
                                else config.rendering.font_dir
                            )
                            min_font = osb_min_font
                            max_font = osb_max_font
                            line_spacing = config.outside_text.osb_line_spacing
                            use_ligs = config.outside_text.osb_use_ligatures
                            # Outside text was inpainted, no mask needed
                            cleaned_mask = None
                            is_dark_text = bubble.get("is_dark_text", True)
                            text_color_rgb = bubble.get("text_color_rgb", None)
                            bubble_color_bgr = (
                                (50, 50, 50) if is_dark_text else (255, 255, 255)
                            )
                            # OSB renders default to horizontal; vertical stacking is fallback-only
                            rotation_deg = 0.0
                            vertical_stack = False
                            if config.rendering.match_original_style:
                                target_font_size = (
                                    estimate_target_font_size_from_line_height(
                                        bubble.get("text_median_line_height")
                                    )
                                )
                                if target_font_size is not None:
                                    target_font_size = scale_font_size(
                                        target_font_size,
                                        processing_scale,
                                        minimum=osb_min_font,
                                        maximum=osb_max_font,
                                    )
                            if config.rendering.detect_glow:
                                glow_color = bubble.get("glow_color_rgb")
                                glow_radius = bubble.get("glow_radius") or 0.0

                            text_bg_rgb = None
                            # Same rule as the first render pass above: only
                            # box OSB/SFX text when nothing was inpainted.
                            if (
                                bubble.get("needs_text_background")
                                and config.outside_text.inpainting_method == "none"
                            ):
                                if text_color_rgb:
                                    lum = (
                                        0.299 * text_color_rgb[0]
                                        + 0.587 * text_color_rgb[1]
                                        + 0.114 * text_color_rgb[2]
                                    )
                                    text_bg_rgb = (
                                        (255, 255, 255) if lum < 128 else (0, 0, 0)
                                    )
                                else:
                                    text_bg_rgb = (
                                        (0, 0, 0) if is_dark_text else (255, 255, 255)
                                    )
                        else:
                            log_message(
                                f"Rendering bubble {bbox}: '{text[:30]}...'",
                                verbose=verbose,
                            )
                            font_dir = config.rendering.font_dir
                            min_font = main_min_font
                            max_font = main_max_font
                            line_spacing = config.rendering.line_spacing_mult
                            use_ligs = config.rendering.use_ligatures
                            render_info = bubble_render_info_map.get(tuple(bbox))
                            bubble_color_bgr = (255, 255, 255)
                            cleaned_mask = None
                            base_mask = None
                            is_sam_mask = False
                            text_color_rgb = None
                            if render_info:
                                bubble_color_bgr = render_info["color"]
                                cleaned_mask = render_info.get("mask")
                                base_mask = render_info.get("base_mask")
                                is_sam_mask = render_info.get("is_sam", False)
                                text_color_bgr_val = render_info.get("text_color_bgr")
                                if text_color_bgr_val:
                                    text_color_rgb = (
                                        text_color_bgr_val[2],
                                        text_color_bgr_val[1],
                                        text_color_bgr_val[0],
                                    )
                                if config.rendering.match_original_style:
                                    target_font_size = (
                                        estimate_target_font_size_from_line_height(
                                            render_info.get(
                                                "text_median_line_height"
                                            )
                                        )
                                    )
                                    if target_font_size is not None:
                                        target_font_size = scale_font_size(
                                            target_font_size,
                                            processing_scale,
                                            minimum=main_min_font,
                                            maximum=main_max_font,
                                        )
                                if config.rendering.detect_glow:
                                    glow_color = render_info.get("glow_color_rgb")
                                    glow_radius = (
                                        render_info.get("glow_radius") or 0.0
                                    )
                                if config.rendering.match_original_style:
                                    style_overrides = resolve_style_overrides(
                                        render_info.get("lettering_style"),
                                        base_min_font=main_min_font,
                                        base_max_font=main_max_font,
                                        tolerance=config.rendering.match_original_style_tolerance,
                                    )
                                    if style_overrides:
                                        log_message(
                                            f"  - Lettering style {bbox}: "
                                            f"{describe_style(render_info.get('lettering_style'))} "
                                            f"-> {style_overrides.summary()}",
                                            verbose=verbose,
                                        )
                                        if style_overrides.text_color_rgb:
                                            text_color_rgb = (
                                                style_overrides.text_color_rgb
                                            )
                                        if (
                                            style_overrides.outline_color_rgb
                                            and style_overrides.outline_width
                                        ):
                                            outline_color = (
                                                style_overrides.outline_color_rgb
                                            )
                                            outline_width_override = (
                                                style_overrides.outline_width
                                            )
                                        if (
                                            config.rendering.detect_glow
                                            and style_overrides.glow_color_rgb
                                            and style_overrides.glow_radius
                                            and not glow_color
                                        ):
                                            glow_color = (
                                                style_overrides.glow_color_rgb
                                            )
                                            glow_radius = (
                                                style_overrides.glow_radius
                                            )
                                        if style_overrides.max_font_size:
                                            target_font_size = (
                                                style_overrides.max_font_size
                                            )
                            # No rotation/stacking for regular bubbles
                            vertical_stack = False
                            rotation_deg = 0.0

                        # Latin languages use hyphenation; Korean/Thai use
                        # no-hyphen emergency breaks under the same user setting.
                        should_hyphenate = config.rendering.hyphenate_before_scaling
                        if not supports_long_word_breaking(
                            config.translation.output_language
                        ):
                            should_hyphenate = False

                        render_config = RenderingConfig(
                            min_font_size=min_font,
                            max_font_size=max_font,
                            line_spacing_mult=line_spacing,
                            use_subpixel_rendering=(
                                config.outside_text.osb_use_subpixel_rendering
                                if is_outside_text
                                else config.rendering.use_subpixel_rendering
                            ),
                            font_hinting=(
                                config.outside_text.osb_font_hinting
                                if is_outside_text
                                else config.rendering.font_hinting
                            ),
                            use_ligatures=use_ligs,
                            hyphenate_before_scaling=should_hyphenate,
                            hyphen_penalty=config.rendering.hyphen_penalty,
                            hyphenation_min_word_length=config.rendering.hyphenation_min_word_length,
                            badness_exponent=config.rendering.badness_exponent,
                            padding_pixels=padding_pixels,
                            outline_width=(
                                osb_outline_width
                                if is_outside_text
                                else (outline_width_override or 0.0)
                            ),
                            supersampling_factor=config.rendering.supersampling_factor,
                            detach_trailing_punctuation=(
                                config.rendering.detach_trailing_punctuation
                            ),
                            auto_vertical_text=(
                                False
                                if is_outside_text
                                else config.rendering.auto_vertical_text
                            ),
                            target_font_size=target_font_size,
                            target_font_size_tolerance=(
                                config.rendering.match_original_style_tolerance
                            ),
                            glow_color=glow_color,
                            glow_radius=glow_radius,
                            outline_color=(
                                outline_color if not is_outside_text else None
                            ),
                        )
                        success = False
                        if is_outside_text:
                            try:
                                rendered_image = render_text_skia(
                                    pil_image=pil_cleaned_image,
                                    text=text,
                                    bbox=bbox,
                                    font_dir=font_dir,
                                    cleaned_mask=cleaned_mask,
                                    bubble_color_bgr=bubble_color_bgr,
                                    config=render_config,
                                    verbose=verbose,
                                    bubble_id=str(i + 1),
                                    rotation_deg=rotation_deg,
                                    vertical_stack=vertical_stack,
                                    text_color_rgb=text_color_rgb,
                                    raise_on_safe_error=False,
                                    text_background_color=text_bg_rgb,
                                    anchor_bbox=bubble.get("original_bbox") if is_outside_text else _bubble_text_anchor(render_info),
                                )
                                success = True
                            except Exception as e:
                                log_message(
                                    f"Text rendering failed: {e}", verbose=verbose
                                )
                                rendered_image = pil_cleaned_image
                                success = False

                                # Absolute last-chance fallback: force vertical stacking before giving up
                                if not vertical_stack:
                                    # Fallback uses neutral rotation since we no longer track orientation
                                    forced_stack_rotation = 0.0
                                    try:
                                        log_message(
                                            "OSB render failed, retrying with vertical-stack fallback",
                                            verbose=verbose,
                                        )
                                        rendered_image = render_text_skia(
                                            pil_image=pil_cleaned_image,
                                            text=text,
                                            bbox=bbox,
                                            font_dir=font_dir,
                                            cleaned_mask=cleaned_mask,
                                            bubble_color_bgr=bubble_color_bgr,
                                            config=render_config,
                                            verbose=verbose,
                                            bubble_id=str(i + 1),
                                            rotation_deg=forced_stack_rotation,
                                            vertical_stack=True,
                                            text_color_rgb=text_color_rgb,
                                            raise_on_safe_error=False,
                                            text_background_color=text_bg_rgb,
                                            anchor_bbox=bubble.get("original_bbox") if is_outside_text else _bubble_text_anchor(render_info),
                                        )
                                        log_message(
                                            "Vertical-stack fallback succeeded",
                                            verbose=verbose,
                                        )
                                        success = True
                                    except Exception as e2:
                                        log_message(
                                            f"Vertical-stack fallback failed: {e2}",
                                            verbose=verbose,
                                        )
                                        # Restore original OSB patch if available
                                        if "original_crop_pil" in bubble:
                                            log_message(
                                                f"Restoring original OSB patch for {bbox}",
                                                verbose=verbose,
                                                always_print=True,
                                            )
                                            rendered_image = pil_cleaned_image.copy()
                                            original_patch = bubble["original_crop_pil"]
                                            rendered_image.paste(
                                                original_patch, (bbox[0], bbox[1])
                                            )
                                            success = True
                                        else:
                                            rendered_image = pil_cleaned_image
                                            success = False
                                else:
                                    if "original_crop_pil" in bubble:
                                        log_message(
                                            f"Restoring original OSB patch for {bbox}",
                                            verbose=verbose,
                                            always_print=True,
                                        )
                                        rendered_image = pil_cleaned_image.copy()
                                        original_patch = bubble["original_crop_pil"]
                                        rendered_image.paste(
                                            original_patch, (bbox[0], bbox[1])
                                        )
                                        success = True
                                    else:
                                        rendered_image = pil_cleaned_image
                                        success = False
                        else:
                            try:
                                rendered_image = render_text_skia(
                                    pil_image=pil_cleaned_image,
                                    text=text,
                                    bbox=bbox,
                                    font_dir=font_dir,
                                    cleaned_mask=cleaned_mask,
                                    bubble_color_bgr=bubble_color_bgr,
                                    config=render_config,
                                    verbose=verbose,
                                    bubble_id=str(i + 1),
                                    rotation_deg=rotation_deg,
                                    vertical_stack=vertical_stack,
                                    text_color_rgb=text_color_rgb,
                                    raise_on_safe_error=True,
                                    anchor_bbox=_bubble_text_anchor(render_info),
                                )
                                success = True
                            except ImageProcessingError as e:
                                safe_area_failed = (
                                    "Safe area calculation failed" in str(e)
                                )
                                retry_result = None
                                if safe_area_failed and base_mask is not None:
                                    log_message(
                                        f"Safe area failed for bubble {bbox}, retrying mask with Otsu",
                                        verbose=verbose,
                                        always_print=True,
                                    )
                                    retry_result = retry_cleaning_with_otsu(
                                        original_cv_image,
                                        {
                                            "base_mask": base_mask,
                                            "bbox": bbox,
                                            "is_sam": is_sam_mask,
                                            "is_colored": (
                                                render_info.get("is_colored", False)
                                                if render_info
                                                else False
                                            ),
                                            "text_bbox": (
                                                render_info.get("text_bbox")
                                                if render_info
                                                else None
                                            ),
                                            "text_color_bgr": (
                                                render_info.get("text_color_bgr")
                                                if render_info
                                                else None
                                            ),
                                        },
                                        config.cleaning.thresholding_value,
                                        config.cleaning.roi_shrink_px,
                                        processing_scale,
                                        verbose=verbose,
                                        classify_colored=(
                                            config.cleaning.inpaint_colored_bubbles
                                        ),
                                    )

                                if (
                                    retry_result
                                    and retry_result.get("mask") is not None
                                ):
                                    cleaned_mask = retry_result["mask"]
                                    bubble_color_bgr = retry_result.get(
                                        "color", bubble_color_bgr
                                    )
                                    base_mask = retry_result.get("base_mask", base_mask)
                                    if render_info is not None:
                                        render_info.update(
                                            {
                                                "mask": cleaned_mask,
                                                "color": bubble_color_bgr,
                                                "base_mask": base_mask,
                                                "is_colored": retry_result.get(
                                                    "is_colored",
                                                    render_info.get(
                                                        "is_colored", False
                                                    ),
                                                ),
                                                "text_bbox": retry_result.get(
                                                    "text_bbox",
                                                    render_info.get("text_bbox"),
                                                ),
                                            }
                                        )

                                    try:
                                        rendered_image = render_text_skia(
                                            pil_image=pil_cleaned_image,
                                            text=text,
                                            bbox=bbox,
                                            font_dir=font_dir,
                                            cleaned_mask=cleaned_mask,
                                            bubble_color_bgr=bubble_color_bgr,
                                            config=render_config,
                                            verbose=verbose,
                                            bubble_id=str(i + 1),
                                            rotation_deg=rotation_deg,
                                            vertical_stack=vertical_stack,
                                            raise_on_safe_error=False,
                                        )
                                        success = True
                                    except (
                                        RenderingError,
                                        FontError,
                                        ImageProcessingError,
                                    ) as e2:
                                        log_message(
                                            f"Text rendering failed after Otsu retry: {e2}",
                                            verbose=verbose,
                                        )
                                        rendered_image = pil_cleaned_image
                                        success = False
                                if not success:
                                    # Final fallback to padded bbox path
                                    fallback_msg = (
                                        f"Safe area calculation failed for {bbox}, using padded bbox fallback"
                                        if safe_area_failed
                                        else f"Rendering retry fallback for {bbox}, using padded bbox method"
                                    )
                                    log_message(
                                        fallback_msg,
                                        verbose=verbose,
                                    )
                                    try:
                                        rendered_image = render_text_skia(
                                            pil_image=pil_cleaned_image,
                                            text=text,
                                            bbox=bbox,
                                            font_dir=font_dir,
                                            cleaned_mask=cleaned_mask,
                                            bubble_color_bgr=bubble_color_bgr,
                                            config=render_config,
                                            verbose=verbose,
                                            bubble_id=str(i + 1),
                                            rotation_deg=rotation_deg,
                                            vertical_stack=vertical_stack,
                                            raise_on_safe_error=False,
                                        )
                                        success = True
                                    except (RenderingError, FontError) as e2:
                                        log_message(
                                            f"Text rendering failed: {e2}",
                                            verbose=verbose,
                                        )
                                        rendered_image = pil_cleaned_image
                                        success = False
                            except (RenderingError, FontError) as e:
                                log_message(
                                    f"Text rendering failed: {e}", verbose=verbose
                                )
                                rendered_image = pil_cleaned_image
                                success = False

                        if success:
                            pil_cleaned_image = rendered_image
                            final_image_to_save = pil_cleaned_image
                        else:
                            log_message(
                                f"Failed to render bubble {bbox}", verbose=verbose
                            )
                else:
                    log_message(
                        f"Warning: Bubble/translation count mismatch "
                        f"({len(sorted_bubble_data)}/{len(translated_texts)})",
                        always_print=True,
                    )

    # Halo-free restore: put ORIGINAL pixels back over every skipped region
    # (SFX / ads / logos) + a padded, feathered margin, so inpaint context
    # blur around the bbox ("dhabba") can never survive.
    if skip_restore_bboxes:
        try:
            final_image_to_save = restore_skipped_regions(
                final_image_to_save,
                pil_page_original,
                skip_restore_bboxes,
                keep_restore_bboxes,
            )
            log_message(
                f"Restored {len(skip_restore_bboxes)} skipped region(s) from original",
                verbose=verbose,
            )
        except Exception as e:  # never fail the page because of the safety net
            log_message(f"Skip-region restore failed: {e}", always_print=True)

    # Final Image Upscaling (optional)
    if config.output.upscale_final_image:
        log_message("Upscaling final image...", verbose=verbose, always_print=True)
        final_image_to_save = upscale_image(
            final_image_to_save,
            config.output.image_upscale_factor,
            model_type=config.output.image_upscale_model,
            verbose=verbose,
        )

    # Save Output
    if output_path:
        if final_image_to_save.mode != target_mode:
            log_message(f"Converting final image to {target_mode}", verbose=verbose)
            final_image_to_save = final_image_to_save.convert(target_mode)

        try:
            save_image_with_compression(
                final_image_to_save,
                output_path,
                jpeg_quality=config.output.jpeg_quality,
                png_compression=config.output.png_compression,
                verbose=verbose,
            )
        except ImageProcessingError as e:
            log_message(f"Failed to save image: {e}", always_print=True)
            raise

    end_time = time.time()
    processing_time = end_time - start_time
    log_message(f"Processing completed in {processing_time:.2f}s", always_print=True)

    return final_image_to_save


def _resolve_output_path(
    img_path: Path,
    input_dir: Path,
    output_dir: Path,
    config: MangaTranslatorConfig,
    preserve_structure: bool,
) -> Tuple[Path, str, str]:
    """Compute output path, display name, and error key for a single image."""
    if preserve_structure:
        relative_path = img_path.relative_to(input_dir)
        output_subdir = output_dir / relative_path.parent
        os.makedirs(output_subdir, exist_ok=True)
        output_filename = f"{relative_path.stem}_translated"
        display_path = str(relative_path)
        error_key = str(relative_path)
    else:
        output_subdir = output_dir
        output_filename = f"{img_path.stem}_translated"
        display_path = img_path.name
        error_key = img_path.name

    original_ext = img_path.suffix.lower()
    desired_format = config.output.output_format
    if desired_format == "jpeg":
        output_ext = ".jpg"
    elif desired_format == "png":
        output_ext = ".png"
    elif desired_format == "auto":
        output_ext = original_ext
    else:
        output_ext = original_ext
        log_message(
            f"Warning: Invalid output_format '{desired_format}' in config. "
            f"Using original extension '{original_ext}'.",
            always_print=True,
        )

    return output_subdir / f"{output_filename}{output_ext}", display_path, error_key


def _should_run_failed_retry(
    config: MangaTranslatorConfig,
    failed_jobs: List[Dict[str, Any]],
    cancellation_manager: Optional["CancellationManager"] = None,
) -> bool:
    if not getattr(config, "retry_failed_once", False):
        return False
    if not failed_jobs:
        return False
    if cancellation_manager is not None and cancellation_manager.is_cancelled():
        return False
    return True


def _retry_failed_batch_images(
    failed_jobs: List[Dict[str, Any]],
    results: Dict[str, Any],
    config: MangaTranslatorConfig,
    input_dir: Path,
    output_dir: Path,
    preserve_structure: bool = False,
    progress_callback: Optional[Callable[[float, str], None]] = None,
    cancellation_manager: Optional["CancellationManager"] = None,
    source_path_map: Optional[Dict[str, str]] = None,
) -> None:
    """Retry failed batch images once. Mutates *results* in place.

    Each entry in *failed_jobs* must include:
      - error_key: key used in results["errors"]
      - img_path: processing Path passed to translate_and_render
      - source_path: path stored in results["failed_image_paths"]
    """
    if not failed_jobs:
        results.setdefault("retry_attempted_count", 0)
        results.setdefault("retry_success_count", 0)
        results.setdefault("retry_failed_count", 0)
        return

    if cancellation_manager is not None and cancellation_manager.is_cancelled():
        results.setdefault("retry_attempted_count", 0)
        results.setdefault("retry_success_count", 0)
        results.setdefault("retry_failed_count", 0)
        return

    total = len(failed_jobs)
    attempted = 0
    retry_success = 0
    retry_failed = 0

    log_message(
        f"Retrying {total} failed image(s) once...",
        always_print=True,
    )

    for i, job in enumerate(failed_jobs):
        if cancellation_manager is not None and cancellation_manager.is_cancelled():
            log_message(
                "Batch retry cancelled by user; remaining retries skipped.",
                always_print=True,
            )
            break

        error_key = job["error_key"]
        img_path = Path(job["img_path"])
        source_path = job.get("source_path")
        if source_path is None:
            source_path = resolve_source_path(img_path, source_path_map)

        output_path, display_path, _ = _resolve_output_path(
            img_path, input_dir, output_dir, config, preserve_structure
        )

        attempted += 1
        try:
            if progress_callback:
                # Keep retries in the high progress band so UI still looks near-complete.
                frac = 0.95 + 0.05 * (i / max(total, 1))
                progress_callback(
                    frac,
                    f"Retrying failed image {i + 1}/{total}: {display_path}",
                )

            log_message(
                f"Retrying {i + 1}/{total}: {display_path}",
                always_print=True,
            )

            if cancellation_manager is not None and cancellation_manager.is_cancelled():
                attempted -= 1
                break
            translate_and_render(
                img_path,
                config,
                output_path,
                cancellation_manager=cancellation_manager,
            )
            results["success_count"] = int(results.get("success_count", 0)) + 1
            results["error_count"] = max(0, int(results.get("error_count", 0)) - 1)
            errors = results.setdefault("errors", {})
            errors.pop(error_key, None)
            failed_paths = list(results.get("failed_image_paths") or [])
            before_len = len(failed_paths)
            failed_paths = [p for p in failed_paths if p != source_path]
            if len(failed_paths) == before_len:
                log_message(
                    f"Retry success path cleanup: source_path not in "
                    f"failed_image_paths ({source_path!r})",
                    always_print=True,
                )
            results["failed_image_paths"] = failed_paths
            retry_success += 1
            log_message(
                f"Retry succeeded: {display_path}",
                always_print=True,
            )
        except CancellationError:
            attempted -= 1
            log_message(
                f"Batch retry cancelled during {display_path}; "
                "remaining retries skipped.",
                always_print=True,
            )
            break
        except Exception as e:
            results.setdefault("errors", {})[error_key] = str(e)
            retry_failed += 1
            log_message(
                f"Retry failed for {display_path}: {e}",
                always_print=True,
            )

    results["retry_attempted_count"] = attempted
    results["retry_success_count"] = retry_success
    results["retry_failed_count"] = retry_failed

    if progress_callback and attempted > 0:
        try:
            progress_callback(
                0.99,
                f"Retry complete: {retry_success} recovered, {retry_failed} still failed",
            )
        except CancellationError:
            log_message(
                "Batch retry progress callback cancelled after stats flush.",
                always_print=True,
            )


async def _batch_translate_parallel(
    image_files: List[Path],
    input_dir: Path,
    config: MangaTranslatorConfig,
    output_dir: Path,
    preserve_structure: bool,
    progress_callback: Optional[Callable[[float, str], None]],
    cancellation_manager: Optional["CancellationManager"],
    source_path_map: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Process images in parallel using a semaphore to maintain target concurrency.

    The first image is processed sequentially to warm up all ML models (triggering
    lazy loading and YOLO layer fusing on the main thread). Remaining images are
    then processed in parallel with models already initialized.
    """
    total_images = len(image_files)
    n_workers = config.parallel_requests
    results = {
        "success_count": 0,
        "error_count": 0,
        "errors": {},
        "failed_image_paths": [],
        "_failed_jobs": [],
    }
    previous_context_cache = OrderedDict()
    previous_context_cache_lock = threading.Lock()
    ocr_text_history: Dict[Path, List[str]] = {}
    ocr_text_history_lock = threading.Lock()
    ocr_text_ready_events = [threading.Event() for _ in image_files]
    requested_text_context_count = int(
        getattr(config.translation, "previous_context_text_count", 0) or 0
    )

    log_message(
        f"Starting parallel batch processing: {total_images} images, "
        f"{n_workers} parallel workers",
        always_print=True,
    )

    if getattr(config, "batch_parallel_within_pages", False):
        request_coordinator = BatchRequestCoordinator(
            n_workers, cancellation_manager=cancellation_manager
        )
        config.request_coordinator = request_coordinator
        config.translation.request_coordinator = request_coordinator
        log_message(
            "Intra-page parallel requests enabled",
            always_print=True,
        )
    else:
        config.request_coordinator = None
        config.translation.request_coordinator = None

    # -- Phase 1: process the first image sequentially to warm up models --
    first_img = image_files[0]
    first_output, first_display, first_key = _resolve_output_path(
        first_img, input_dir, output_dir, config, preserve_structure
    )
    log_message(
        f"Processing 1/{total_images}: {first_display} (warming up models)",
        always_print=True,
    )
    try:
        if cancellation_manager and cancellation_manager.is_cancelled():
            raise CancellationError("Batch process cancelled by user.")
        first_previous_context_images = _build_previous_context_images(
            image_files,
            0,
            config,
            previous_context_cache,
            previous_context_cache_lock,
        )
        first_previous_context_texts = _build_previous_context_texts(
            image_files,
            0,
            config,
            ocr_text_history,
            ocr_text_history_lock,
        )
        first_ocr_texts: List[str] = []
        translate_and_render(
            first_img,
            config,
            first_output,
            cancellation_manager=cancellation_manager,
            previous_context_images=first_previous_context_images,
            previous_context_texts=first_previous_context_texts,
            ocr_texts_out=first_ocr_texts,
        )
        if first_ocr_texts:
            with ocr_text_history_lock:
                ocr_text_history[first_img] = first_ocr_texts
        results["success_count"] += 1
    except CancellationError:
        raise
    except Exception as e:
        log_message(f"Error processing {first_display}: {str(e)}", always_print=True)
        source_path = resolve_source_path(first_img, source_path_map)
        results["error_count"] += 1
        results["errors"][first_key] = str(e)
        results["failed_image_paths"].append(source_path)
        results["_failed_jobs"].append(
            {
                "error_key": first_key,
                "img_path": first_img,
                "source_path": source_path,
            }
        )
    finally:
        ocr_text_ready_events[0].set()

    completed_count = 1
    if progress_callback:
        has_errors = results["error_count"] > 0
        suffix = " (with errors)" if has_errors else ""
        progress_callback(
            1 / total_images, f"Completed 1/{total_images} images{suffix}"
        )

    # -- Phase 2: process remaining images in parallel --
    remaining = image_files[1:]
    if not remaining:
        return results

    if cancellation_manager and cancellation_manager.is_cancelled():
        raise CancellationError("Batch process cancelled by user.")

    sem = asyncio.Semaphore(n_workers)
    results_lock = threading.Lock()
    cancelled = False

    def _wait_for_required_previous_ocr(index: int) -> None:
        if requested_text_context_count <= 0:
            return
        start_index = max(0, index - requested_text_context_count)
        for previous_index in range(start_index, index):
            if cancellation_manager and cancellation_manager.is_cancelled():
                raise CancellationError("Batch process cancelled by user.")
            while not ocr_text_ready_events[previous_index].wait(timeout=0.2):
                if cancellation_manager and cancellation_manager.is_cancelled():
                    raise CancellationError("Batch process cancelled by user.")
            if cancellation_manager and cancellation_manager.is_cancelled():
                raise CancellationError("Batch process cancelled by user.")

    def _process_single(img_path: Path, index: int) -> Tuple[str, str]:
        """Run translate_and_render for a single image. Returns (display_path, error_key)."""
        output_path, display_path, error_key = _resolve_output_path(
            img_path, input_dir, output_dir, config, preserve_structure
        )
        log_message(
            f"Processing {index + 1}/{total_images}: {display_path}",
            always_print=True,
        )
        previous_context_images = _build_previous_context_images(
            image_files,
            index,
            config,
            previous_context_cache,
            previous_context_cache_lock,
        )

        def previous_context_texts_provider() -> List[List[str]]:
            _wait_for_required_previous_ocr(index)
            return _build_previous_context_texts(
                image_files,
                index,
                config,
                ocr_text_history,
                ocr_text_history_lock,
            )

        captured_ocr_texts: List[str] = []
        translate_and_render(
            img_path,
            config,
            output_path,
            cancellation_manager=cancellation_manager,
            previous_context_images=previous_context_images,
            previous_context_texts_provider=previous_context_texts_provider,
            ocr_texts_out=captured_ocr_texts,
        )
        if captured_ocr_texts:
            with ocr_text_history_lock:
                ocr_text_history[img_path] = captured_ocr_texts
        return display_path, error_key

    async def _worker(img_path: Path, index: int, executor: ThreadPoolExecutor):
        nonlocal completed_count, cancelled
        try:
            if cancelled or (
                cancellation_manager and cancellation_manager.is_cancelled()
            ):
                cancelled = True
                return

            async with sem:
                if cancelled or (
                    cancellation_manager and cancellation_manager.is_cancelled()
                ):
                    cancelled = True
                    return

                loop = asyncio.get_event_loop()
                try:
                    await loop.run_in_executor(
                        executor, _process_single, img_path, index
                    )
                    with results_lock:
                        results["success_count"] += 1
                        completed_count += 1
                        count = completed_count
                except CancellationError:
                    cancelled = True
                    raise
                except Exception as e:
                    _, display_path, error_key = _resolve_output_path(
                        img_path, input_dir, output_dir, config, preserve_structure
                    )
                    log_message(
                        f"Error processing {display_path}: {str(e)}",
                        always_print=True,
                    )
                    source_path = resolve_source_path(img_path, source_path_map)
                    with results_lock:
                        results["error_count"] += 1
                        results["errors"][error_key] = str(e)
                        results["failed_image_paths"].append(source_path)
                        results["_failed_jobs"].append(
                            {
                                "error_key": error_key,
                                "img_path": img_path,
                                "source_path": source_path,
                            }
                        )
                        completed_count += 1
                        count = completed_count

                if progress_callback:
                    progress = count / total_images
                    has_errors = results["error_count"] > 0
                    suffix = " (with errors)" if has_errors else ""
                    progress_callback(
                        progress, f"Completed {count}/{total_images} images{suffix}"
                    )
        except CancellationError:
            cancelled = True
            raise
        finally:
            ocr_text_ready_events[index].set()

            if cancelled:
                for event in ocr_text_ready_events:
                    event.set()

    with ThreadPoolExecutor(max_workers=n_workers) as executor:
        tasks = [_worker(img, i, executor) for i, img in enumerate(remaining, start=1)]
        gathered = await asyncio.gather(*tasks, return_exceptions=True)

    for exc in gathered:
        if isinstance(exc, CancellationError):
            raise exc

    return results


def batch_translate_images(
    input_dir: Union[str, Path],
    config: MangaTranslatorConfig,
    output_dir: Optional[Union[str, Path]] = None,
    progress_callback: Optional[Callable[[float, str], None]] = None,
    preserve_structure: bool = False,
    cancellation_manager: Optional["CancellationManager"] = None,
    source_path_map: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """
    Process all images in a directory using a configuration object.

    Args:
        input_dir (str or Path): Directory containing images to process
        config (MangaTranslatorConfig): Configuration object containing all settings.
        output_dir (str or Path, optional): Directory to save translated images.
                                            If None, uses input_dir / "output_translated".
        progress_callback (callable, optional): Function to call with progress updates (0.0-1.0, message).
        preserve_structure (bool): If True, recursively process subdirectories and preserve folder structure
                                   in the output. If False, only processes files in the root directory.
        source_path_map: Optional mapping from processing paths to original source paths
            (used when UI/CLI copies inputs into a temp directory).

    Returns:
        dict: Processing results with keys:
            - "success_count": Number of successfully processed images
            - "error_count": Number of images that failed to process
            - "errors": Dictionary mapping filenames to error messages
            - "failed_image_paths": Absolute source paths of failed images
            - "failed_paths_file": Path to failed_paths.txt when written
    """
    empty_results = {
        "success_count": 0,
        "error_count": 0,
        "errors": {},
        "failed_image_paths": [],
    }

    input_dir = Path(input_dir)
    if not input_dir.is_dir():
        log_message(f"Input path '{input_dir}' is not a directory", always_print=True)
        return empty_results

    if output_dir:
        output_dir = Path(output_dir)
    else:
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output_dir = Path("./output") / timestamp

    os.makedirs(output_dir, exist_ok=True)

    image_extensions = [".jpg", ".jpeg", ".png", ".webp"]

    if preserve_structure:
        image_files = []
        for root, dirs, files in os.walk(input_dir):
            for file in files:
                file_path = Path(root) / file
                if file_path.suffix.lower() in image_extensions:
                    image_files.append(file_path)
    else:
        image_files = [
            f
            for f in input_dir.iterdir()
            if f.is_file() and f.suffix.lower() in image_extensions
        ]

    def _batch_sort_key(path: Path):
        try:
            sort_path = (
                path.relative_to(input_dir) if preserve_structure else Path(path.name)
            )
        except ValueError:
            sort_path = path
        return _natural_path_sort_key(sort_path)

    image_files.sort(key=_batch_sort_key)

    if not image_files:
        log_message(f"No image files found in '{input_dir}'", always_print=True)
        return empty_results

    total_images = len(image_files)
    start_batch_time = time.time()

    if progress_callback:
        progress_callback(0.0, f"Starting batch processing of {total_images} images...")

    if config.parallel_requests > 1:
        results = asyncio.run(
            _batch_translate_parallel(
                image_files=image_files,
                input_dir=input_dir,
                config=config,
                output_dir=output_dir,
                preserve_structure=preserve_structure,
                progress_callback=progress_callback,
                cancellation_manager=cancellation_manager,
                source_path_map=source_path_map,
            )
        )
        failed_jobs = results.pop("_failed_jobs", [])
    else:
        results = {
            "success_count": 0,
            "error_count": 0,
            "errors": {},
            "failed_image_paths": [],
        }
        failed_jobs: List[Dict[str, Any]] = []
        previous_context_cache = OrderedDict()
        previous_context_cache_lock = threading.Lock()
        ocr_text_history: Dict[Path, List[str]] = {}
        ocr_text_history_lock = threading.Lock()
        log_message(
            f"Starting batch processing: {total_images} images", always_print=True
        )

        for i, img_path in enumerate(image_files):
            try:
                output_path, display_path, error_key = _resolve_output_path(
                    img_path, input_dir, output_dir, config, preserve_structure
                )

                if cancellation_manager and cancellation_manager.is_cancelled():
                    raise CancellationError("Batch process cancelled by user.")

                if progress_callback:
                    current_progress = i / total_images
                    progress_callback(
                        current_progress,
                        f"Processing image {i + 1}/{total_images}: {display_path}",
                    )

                log_message(
                    f"Processing {i + 1}/{total_images}: {display_path}",
                    always_print=True,
                )

                previous_context_images = _build_previous_context_images(
                    image_files,
                    i,
                    config,
                    previous_context_cache,
                    previous_context_cache_lock,
                )
                previous_context_texts = _build_previous_context_texts(
                    image_files,
                    i,
                    config,
                    ocr_text_history,
                    ocr_text_history_lock,
                )
                captured_ocr_texts: List[str] = []
                translate_and_render(
                    img_path,
                    config,
                    output_path,
                    cancellation_manager=cancellation_manager,
                    previous_context_images=previous_context_images,
                    previous_context_texts=previous_context_texts,
                    ocr_texts_out=captured_ocr_texts,
                )
                if captured_ocr_texts:
                    with ocr_text_history_lock:
                        ocr_text_history[img_path] = captured_ocr_texts

                results["success_count"] += 1

                if progress_callback:
                    completed_progress = (i + 1) / total_images
                    progress_callback(
                        completed_progress,
                        f"Completed {i + 1}/{total_images} images",
                    )

            except CancellationError:
                log_message(
                    f"Batch cancelled during processing of {display_path}",
                    verbose=config.verbose,
                )
                raise
            except Exception as e:
                log_message(
                    f"Error processing {display_path}: {str(e)}", always_print=True
                )
                source_path = resolve_source_path(img_path, source_path_map)
                results["error_count"] += 1
                results["errors"][error_key] = str(e)
                results["failed_image_paths"].append(source_path)
                failed_jobs.append(
                    {
                        "error_key": error_key,
                        "img_path": img_path,
                        "source_path": source_path,
                    }
                )

                if progress_callback:
                    completed_progress = (i + 1) / total_images
                    progress_callback(
                        completed_progress,
                        f"Completed {i + 1}/{total_images} images (with errors)",
                    )

    if _should_run_failed_retry(config, failed_jobs, cancellation_manager):
        _retry_failed_batch_images(
            failed_jobs=failed_jobs,
            results=results,
            config=config,
            input_dir=input_dir,
            output_dir=output_dir,
            preserve_structure=preserve_structure,
            progress_callback=progress_callback,
            cancellation_manager=cancellation_manager,
            source_path_map=source_path_map,
        )

    if progress_callback:
        progress_callback(1.0, "Processing complete")

    end_batch_time = time.time()
    total_batch_time = end_batch_time - start_batch_time
    seconds_per_image = total_batch_time / total_images if total_images > 0 else 0

    log_message(
        f"Batch complete: {results['success_count']}/{total_images} images in "
        f"{total_batch_time:.2f}s ({seconds_per_image:.2f}s/image)",
        always_print=True,
    )
    if results.get("retry_attempted_count"):
        log_message(
            f"Retry pass: {results.get('retry_success_count', 0)} recovered, "
            f"{results.get('retry_failed_count', 0)} still failed "
            f"(of {results['retry_attempted_count']} attempted)",
            always_print=True,
        )
    if results["error_count"] > 0:
        log_message(f"Failed: {results['error_count']} images", always_print=True)
        for filename, error_msg in results["errors"].items():
            log_message(f"  - {filename}: {error_msg}", always_print=True)

    failed_paths = results.get("failed_image_paths") or []
    if failed_paths:
        failed_file = write_failed_paths(output_dir, failed_paths)
        if failed_file:
            results["failed_paths_file"] = str(failed_file)
            log_message(
                f"Failed image paths saved to: {failed_file}",
                always_print=True,
            )

    return results
