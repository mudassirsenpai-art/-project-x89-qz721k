import gc
from typing import Optional

import torch


def get_best_device() -> torch.device:
    """Return the optimal device based on platform and available hardware.

    Priority order: CUDA > XPU > MPS > CPU

    Returns:
        torch.device: The best available device for the current system.

    Examples:
        >>> device = get_best_device()
        >>> model.to(device)
    """
    # CUDA: NVIDIA and AMD (via ROCm)
    if torch.cuda.is_available():
        return torch.device("cuda")

    # XPU: Intel ARC GPUs
    if hasattr(torch, "xpu") and torch.xpu.is_available():
        return torch.device("xpu")

    # MPS: Apple Silicon and Intel Macs with AMD GPUs
    if torch.backends.mps.is_available():
        return torch.device("mps")

    return torch.device("cpu")


def _cuda_supports_bf16_natively(device: torch.device) -> bool:
    """Whether a CUDA device has real bfloat16 hardware, not just the ability to
    hold a bf16 tensor.

    `torch.cuda.is_bf16_supported()` cannot be used here: it defaults to
    `including_emulation=True` and falls back to simply allocating a bf16 tensor,
    which succeeds on any CUDA device. On pre-Ampere cards (T4/Turing, sm_75) that
    reports True while the hardware has no bf16 tensor cores at all, so picking
    bf16 there silently drops off the tensor-core path and runs the model slower
    than fp16 - which those cards *do* accelerate.

    bf16 tensor cores arrive with compute capability 8.0 (Ampere). ROCm builds
    support bf16 across the GPU archs this runs on, so they are taken as native.
    """
    if getattr(torch.version, "hip", None):
        return True
    try:
        # Queried instead of torch.cuda.is_bf16_supported(including_emulation=False)
        # because that keyword only exists on newer PyTorch releases.
        return torch.cuda.get_device_capability(device)[0] >= 8
    except Exception:
        return False


def get_best_dtype(device: Optional[torch.device] = None) -> torch.dtype:
    """Return the optimal dtype for the given device.

    Args:
        device: The target device. If None, uses get_best_device().

    Returns:
        torch.dtype: The optimal dtype for the device.
            - CUDA: bfloat16 when the hardware accelerates it (Ampere+), else
              float16, which pre-Ampere cards do accelerate
            - XPU: bfloat16 if supported, else float16
            - MPS: float16
            - CPU: float32

    Examples:
        >>> device = get_best_device()
        >>> dtype = get_best_dtype(device)
        >>> model.to(device, dtype=dtype)
    """
    if device is None:
        device = get_best_device()

    device_type = device.type

    if device_type == "cuda":
        if _cuda_supports_bf16_natively(device):
            return torch.bfloat16
        return torch.float16

    if device_type == "xpu":
        # Intel XPU supports bfloat16 on most ARC GPUs
        try:
            if (
                hasattr(torch.xpu, "is_bf16_supported")
                and torch.xpu.is_bf16_supported()
            ):
                return torch.bfloat16
        except Exception:
            pass
        return torch.float16

    if device_type == "mps":
        return torch.float16

    # CPU fallback
    return torch.float32


def empty_cache(device: Optional[torch.device] = None) -> None:
    """Clear GPU memory cache in a platform-aware manner.

    Args:
        device: The device to clear cache for. If None, clears all available backends.

    Examples:
        >>> empty_cache()  # Clears cache for all available backends
        >>> empty_cache(torch.device("cuda"))  # Clears CUDA cache only
    """
    gc.collect()

    if device is not None:
        device_type = device.type
        if device_type == "cuda" and torch.cuda.is_available():
            torch.cuda.empty_cache()
        elif (
            device_type == "xpu" and hasattr(torch, "xpu") and torch.xpu.is_available()
        ):
            torch.xpu.empty_cache()
        elif device_type == "mps" and torch.backends.mps.is_available():
            torch.mps.empty_cache()
        return

    # Clear all available backends
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    if hasattr(torch, "xpu") and torch.xpu.is_available():
        torch.xpu.empty_cache()

    if torch.backends.mps.is_available():
        torch.mps.empty_cache()


def get_device_info(device: Optional[torch.device] = None) -> dict:
    """Get memory and device information for any backend.

    Args:
        device: The device to get info for. If None, uses get_best_device().

    Returns:
        dict: Device information including:
            - device: Device name or type
            - allocated_gb: Allocated memory in GB (if available)
            - reserved_gb: Reserved memory in GB (if available)
            - memory: "N/A" if memory info unavailable

    Examples:
        >>> info = get_device_info()
        >>> print(f"Device: {info['device']}")
    """
    if device is None:
        device = get_best_device()

    device_type = device.type

    if device_type == "cuda" and torch.cuda.is_available():
        allocated = torch.cuda.memory_allocated() / 1024**3
        reserved = torch.cuda.memory_reserved() / 1024**3
        return {
            "device": torch.cuda.get_device_name(0),
            "allocated_gb": f"{allocated:.2f}",
            "reserved_gb": f"{reserved:.2f}",
        }

    if device_type == "xpu" and hasattr(torch, "xpu") and torch.xpu.is_available():
        try:
            allocated = torch.xpu.memory_allocated() / 1024**3
            reserved = torch.xpu.memory_reserved() / 1024**3
            device_name = torch.xpu.get_device_name(0)
            return {
                "device": device_name,
                "allocated_gb": f"{allocated:.2f}",
                "reserved_gb": f"{reserved:.2f}",
            }
        except Exception:
            return {"device": "Intel XPU", "memory": "N/A"}

    if device_type == "mps" and torch.backends.mps.is_available():
        try:
            # MPS has limited memory reporting
            allocated = torch.mps.current_allocated_memory() / 1024**3
            return {
                "device": "Apple MPS",
                "allocated_gb": f"{allocated:.2f}",
                "reserved_gb": "N/A",
            }
        except Exception:
            return {"device": "Apple MPS", "memory": "N/A"}

    return {"device": "cpu", "memory": "N/A"}


def is_gpu_available() -> bool:
    """Check if any GPU backend is available.

    Returns:
        bool: True if CUDA, XPU, or MPS is available.

    Examples:
        >>> if is_gpu_available():
        ...     print("GPU acceleration available")
    """
    if torch.cuda.is_available():
        return True

    if hasattr(torch, "xpu") and torch.xpu.is_available():
        return True

    if torch.backends.mps.is_available():
        return True

    return False


def synchronize(device: Optional[torch.device] = None) -> None:
    """Synchronize the given device or all available GPU backends.

    Useful for accurate timing measurements and ensuring operations complete.

    Args:
        device: The device to synchronize. If None, synchronizes all available backends.
    """
    if device is not None:
        device_type = device.type
        if device_type == "cuda" and torch.cuda.is_available():
            torch.cuda.synchronize()
        elif (
            device_type == "xpu" and hasattr(torch, "xpu") and torch.xpu.is_available()
        ):
            torch.xpu.synchronize()
        elif device_type == "mps" and torch.backends.mps.is_available():
            torch.mps.synchronize()
        return

    # Synchronize all available backends
    if torch.cuda.is_available():
        torch.cuda.synchronize()

    if hasattr(torch, "xpu") and torch.xpu.is_available():
        torch.xpu.synchronize()

    if torch.backends.mps.is_available():
        torch.mps.synchronize()


def get_flux_gpu_index() -> Optional[int]:
    """Index of the GPU Flux (SDNQ) should run on, or None for the default GPU.

    Opt-in via env var FLUX_GPU_ID (e.g. FLUX_GPU_ID=1 on Kaggle T4 x2) so Flux
    gets a whole GPU to itself while detection/OCR/SAM stay on GPU 0.
    """
    import os

    raw = os.environ.get("FLUX_GPU_ID", "").strip()
    if not raw or not torch.cuda.is_available():
        return None
    try:
        idx = int(raw)
    except ValueError:
        return None
    if idx < 0 or idx >= torch.cuda.device_count():
        return None
    return idx


def get_flux_device(default: torch.device) -> torch.device:
    """Device for Flux inference: FLUX_GPU_ID GPU if set, else `default`."""
    idx = get_flux_gpu_index()
    if idx is None or default.type != "cuda":
        return default
    return torch.device(f"cuda:{idx}")
