"""Tests for core.image.bubble_outline (numpy + cv2 only, no torch needed).

Run:  python -m pytest tests/test_yolo3_outline_rescue.py -q
"""
import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import importlib.util

_spec = importlib.util.spec_from_file_location(
    "bubble_outline",
    os.path.join(os.path.dirname(__file__), "..", "core", "image", "bubble_outline.py"),
)
bo = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bo)


def _canvas(bg=(250, 240, 245), size=(700, 900)):
    return np.full((size[0], size[1], 3), bg, np.uint8)


def _text(img, lines, origin, scale=1.0):
    x, y = origin
    for i, t in enumerate(lines):
        cv2.putText(img, t, (x, y + i * int(42 * scale)), cv2.FONT_HERSHEY_SIMPLEX,
                    scale, (10, 10, 10), 2, cv2.LINE_AA)


def test_ellipse_bubble_on_pale_background_is_rescued():
    img = _canvas()
    cv2.ellipse(img, (450, 300), (240, 150), 0, 0, 360, (255, 255, 255), -1)
    cv2.ellipse(img, (450, 300), (240, 150), 0, 0, 360, (0, 0, 0), 6, cv2.LINE_AA)
    _text(img, ["I'M YOUR", "GIRLFRIEND...!", "REALLY NOW"], (350, 270))
    ok, info = bo.is_enclosed_speech_bubble(img, (210, 150, 690, 450))
    assert ok, info


def test_floating_text_on_plain_page_is_not_rescued():
    img = _canvas(bg=(255, 255, 255))
    _text(img, ["THE NEXT MORNING,", "AT THE UNIVERSITY...", "HE WOKE UP LATE"], (250, 260))
    ok, info = bo.is_enclosed_speech_bubble(img, (230, 220, 700, 400))
    assert not ok, info


def test_floating_text_on_art_is_not_rescued():
    img = _canvas()
    rng = np.random.default_rng(0)
    noise = rng.integers(60, 200, img.shape, dtype=np.uint8)
    img = cv2.GaussianBlur(noise, (0, 0), 9)
    _text(img, ["WHOOSH", "BANG BANG"], (250, 300), scale=1.4)
    ok, info = bo.is_enclosed_speech_bubble(img, (230, 240, 700, 400))
    assert not ok, info


def test_outline_without_text_is_not_rescued():
    img = _canvas()
    cv2.ellipse(img, (450, 300), (240, 150), 0, 0, 360, (255, 255, 255), -1)
    cv2.ellipse(img, (450, 300), (240, 150), 0, 0, 360, (0, 0, 0), 6, cv2.LINE_AA)
    ok, info = bo.is_enclosed_speech_bubble(img, (210, 150, 690, 450))
    assert not ok, info


def test_tiny_box_is_safe():
    img = _canvas()
    ok, _ = bo.is_enclosed_speech_bubble(img, (5, 5, 20, 20))
    assert not ok
