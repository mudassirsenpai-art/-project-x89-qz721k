from __future__ import annotations

from typing import Any, Dict, List, Optional, Union

import cv2
import numpy as np
import torch
from PIL import Image


class _RTDetrBoxes:
    """Minimal stand-in for ultralytics Results.boxes."""

    def __init__(
        self,
        xyxy: torch.Tensor,
        conf: torch.Tensor,
        cls: torch.Tensor,
    ):
        self.xyxy = xyxy
        self.conf = conf
        self.cls = cls

    def __len__(self) -> int:
        return int(self.xyxy.shape[0])


class _RTDetrResults:
    """Minimal stand-in for ultralytics Results."""

    def __init__(self, boxes: _RTDetrBoxes, names: Dict[int, str]):
        self.boxes = boxes
        self.names = names


class RTDetrYOLOAdapter:
    """Callable wrapper that mimics YOLO's predict API for RT-DETR-v2.

    Usage matches ultralytics YOLO:
        results = adapter(image_cv, conf=0.35, device=device, imgsz=640)[0]
        results.boxes.xyxy / .conf / .cls
        adapter.names  # {id: class_name}
    """

    def __init__(
        self,
        model: Any,
        processor: Any,
        device: torch.device,
        names: Optional[Dict[int, str]] = None,
    ):
        self.model = model
        self.processor = processor
        self.device = device
        if names is not None:
            self.names = {int(k): str(v) for k, v in names.items()}
        else:
            id2label = getattr(model.config, "id2label", None) or {}
            self.names = {int(k): str(v) for k, v in id2label.items()}

    def __call__(
        self,
        source: Union[np.ndarray, Image.Image, str],
        conf: float = 0.35,
        device: Optional[Union[torch.device, str]] = None,
        verbose: bool = False,
        imgsz: Optional[int] = None,
        **_kwargs,
    ) -> List[_RTDetrResults]:
        del verbose  # accepted for YOLO API compatibility
        run_device = torch.device(device) if device is not None else self.device
        image_pil, orig_h, orig_w = self._to_pil(source)

        processor_kwargs = {"images": image_pil, "return_tensors": "pt"}
        if imgsz is not None:
            size = int(imgsz)
            processor_kwargs["size"] = {"height": size, "width": size}

        inputs = self.processor(**processor_kwargs)
        inputs = {k: v.to(run_device) for k, v in inputs.items()}

        was_training = self.model.training
        self.model.eval()
        try:
            with torch.inference_mode():
                outputs = self.model(**inputs)
                results = self.processor.post_process_object_detection(
                    outputs,
                    threshold=float(conf),
                    target_sizes=[(orig_h, orig_w)],
                    use_focal_loss=bool(
                        getattr(self.model.config, "use_focal_loss", True)
                    ),
                )[0]
        finally:
            if was_training:
                self.model.train()

        boxes = results["boxes"].detach()
        scores = results["scores"].detach()
        labels = results["labels"].detach()

        # Keep tensors on the inference device so they can be concatenated with YOLO boxes.
        if boxes.numel() == 0:
            xyxy = torch.empty((0, 4), dtype=torch.float32, device=run_device)
            conf_t = torch.empty((0,), dtype=torch.float32, device=run_device)
            cls_t = torch.empty((0,), dtype=torch.float32, device=run_device)
        else:
            xyxy = boxes.to(device=run_device, dtype=torch.float32)
            conf_t = scores.to(device=run_device, dtype=torch.float32)
            cls_t = labels.to(device=run_device, dtype=torch.float32)

        return [_RTDetrResults(_RTDetrBoxes(xyxy, conf_t, cls_t), self.names)]

    @staticmethod
    def _to_pil(
        source: Union[np.ndarray, Image.Image, str],
    ) -> tuple[Image.Image, int, int]:
        if isinstance(source, Image.Image):
            image = source.convert("RGB") if source.mode != "RGB" else source
            w, h = image.size
            return image, h, w

        if isinstance(source, str):
            image = Image.open(source).convert("RGB")
            w, h = image.size
            return image, h, w

        # Remaining accepted type: OpenCV BGR ndarray
        arr = source
        if arr.ndim == 2:
            arr = cv2.cvtColor(arr, cv2.COLOR_GRAY2RGB)
        elif arr.shape[2] == 4:
            arr = cv2.cvtColor(arr, cv2.COLOR_BGRA2RGB)
        else:
            arr = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
        image = Image.fromarray(arr)
        h, w = arr.shape[:2]
        return image, h, w


def _iou_contain(a, b):
    """Return (iou, containment-of-smaller) for two xyxy boxes."""
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    area_a = max(0.0, a[2] - a[0]) * max(0.0, a[3] - a[1])
    area_b = max(0.0, b[2] - b[0]) * max(0.0, b[3] - b[1])
    union = area_a + area_b - inter
    small = min(area_a, area_b)
    return (inter / union if union else 0.0), (inter / small if small else 0.0)


def detect_bubbles_rtdetr(
    adapter: "RTDetrYOLOAdapter",
    image_cv: np.ndarray,
    conf: float = 0.35,
    device: Optional[Union[torch.device, str]] = None,
    imgsz: int = 640,
    tall_ratio: float = 2.0,
    chunk_ratio: float = 1.5,
    overlap_px: int = 150,
):
    """Use the ogkalu RT-DETR-v2 detector as the PRIMARY bubble detector.

    Classes: ``bubble`` (kept as speech bubbles), ``text_free`` (returned
    separately as outside-speech-bubble boxes), ``text_bubble`` (ignored).

    Tall manhwa/manhua strips are processed in overlapping chunks, because
    squashing a very tall image into 640x640 destroys detection quality.

    Returns:
        (results, text_free_boxes) where ``results`` mimics ultralytics Results
        (``.boxes.xyxy/.conf/.cls``, ``.names``, ``.masks=None``,
        ``.orig_shape``) holding bubble detections only.
    """
    h, w = image_cv.shape[:2]
    run_device = torch.device(device) if device is not None else adapter.device

    if h > tall_ratio * w:
        chunk_h = max(int(w * chunk_ratio), 800)
        step = max(chunk_h - overlap_px, 1)
        ys = list(range(0, max(h - overlap_px, 1), step))
    else:
        chunk_h, ys = h, [0]

    raw = []  # (name, conf, [x1,y1,x2,y2])
    for y in ys:
        crop = image_cv[y : min(y + chunk_h, h)]
        res = adapter(crop, conf=conf, device=run_device, verbose=False, imgsz=imgsz)[0]
        if res.boxes is None or len(res.boxes) == 0:
            continue
        xyxy = res.boxes.xyxy.detach().cpu().tolist()
        scores = res.boxes.conf.detach().cpu().tolist()
        clss = res.boxes.cls.detach().cpu().tolist()
        for b, s, c in zip(xyxy, scores, clss):
            name = adapter.names.get(int(c), str(int(c)))
            raw.append((name, float(s), [b[0], b[1] + y, b[2], b[3] + y]))

    # De-duplicate (chunk overlaps): high score wins
    keep = []
    for name, s, box in sorted(raw, key=lambda r: -r[1]):
        dup = False
        for k_name, _k_s, k_box in keep:
            if (name == "bubble") != (k_name == "bubble"):
                continue
            iou, contain = _iou_contain(k_box, box)
            if iou > 0.5 or (name != "bubble" and contain > 0.8):
                dup = True
                break
        if not dup:
            keep.append((name, s, box))

    bubble_id = next((i for i, n in adapter.names.items() if n == "bubble"), 0)
    bubbles = [k for k in keep if k[0] == "bubble"]
    text_free = [k[2] for k in keep if k[0] == "text_free"]

    if bubbles:
        xyxy_t = torch.tensor([k[2] for k in bubbles], dtype=torch.float32, device=run_device)
        conf_t = torch.tensor([k[1] for k in bubbles], dtype=torch.float32, device=run_device)
        cls_t = torch.full((len(bubbles),), float(bubble_id), dtype=torch.float32, device=run_device)
    else:
        xyxy_t = torch.empty((0, 4), dtype=torch.float32, device=run_device)
        conf_t = torch.empty((0,), dtype=torch.float32, device=run_device)
        cls_t = torch.empty((0,), dtype=torch.float32, device=run_device)

    results = _RTDetrResults(_RTDetrBoxes(xyxy_t, conf_t, cls_t), adapter.names)
    results.masks = None
    results.orig_shape = (h, w)
    results.text_free_boxes = text_free
    return results, text_free
