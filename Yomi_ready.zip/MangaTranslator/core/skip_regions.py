"""Skip-regions: text that must be left 100% untouched (SFX, ads, title logos,
credits, watermarks) and a halo-free restore step.

Two problems this solves:

1. DETECTION used to depend only on the LLM's ``[SFX]`` tag, and the prompt told
   the model that only *audible* SFX qualify. Promo banners, series-title logos,
   credits and watermarks were therefore never skipped. We now (a) let the LLM
   tag them (``[SKIP]``) and (b) add a model-independent keyword heuristic.

2. The old skip only re-pasted the item's own bbox crop. Inpaint backends
   (Flux / LaMa / OpenCV) rewrite a larger context window and the OSB mask is
   padded/feathered, so pixels *just outside* the bbox came back blurred
   ("dhabba"). ``restore_skipped_regions`` copies the ORIGINAL pixels back over
   a padded + feathered area around every skipped bbox, except where a kept
   (translated) item legitimately needs changed pixels.
"""

from __future__ import annotations

import re
from typing import Iterable, List, Optional, Sequence, Tuple

import numpy as np
from PIL import Image, ImageFilter

BBox = Tuple[int, int, int, int]

# --------------------------------------------------------------------------
# Detection heuristic (model independent)
# --------------------------------------------------------------------------

# Promo / ad / credit / watermark vocabulary. Kept conservative on purpose:
# every entry is something that essentially never appears in real dialogue.
_PROMO_CJK = [
    # Japanese
    r"単行本", r"発売中", r"好評発売", r"最新(?:刊|巻|単行本)", r"描き下ろし",
    r"書き下ろし", r"連載中", r"次号", r"掲載誌", r"電子書籍",
    r"公式(?:サイト|ツイッター|SNS|アカウント)", r"コミックス", r"全\d+巻",
    r"第\s*\d+\s*巻.{0,6}(?:発売|好評)", r"QRコード", r"[©Ⓒ]", r"無断転載",
    # Korean
    r"단행본", r"발매", r"연재중", r"공식\s*(?:사이트|계정)", r"무단\s*전재",
    # Chinese
    r"单行本", r"发售", r"连载中", r"官方(?:网站|微博|账号)", r"未经许可",
]
# English / scanlation watermark vocabulary (case-insensitive). Deliberately
# NOT matching bare words like "scan" or "app" that occur in real dialogue.
_PROMO_LATIN = [
    r"\bavailable now\b", r"\bnow on sale\b", r"\bfollow us\b",
    r"\bscanlations?\b", r"\bread (?:more|online) at\b",
    r"https?://", r"\bwww\.", r"\b[\w-]+\.(?:com|net|org|jp|co)\b",
    r"\ball rights reserved\b",
]
_PROMO_CJK_RE = re.compile("|".join(_PROMO_CJK))
_PROMO_LATIN_RE = re.compile("|".join(_PROMO_LATIN), re.IGNORECASE)


_EXTRA_PHRASES_CACHE: Optional[List[str]] = None


def load_extra_skip_phrases() -> List[str]:
    """Series title / logo / credit lines to always leave untouched.

    Put one phrase per line in ``skip_phrases.txt`` (project root, or the path
    in env ``MANGA_SKIP_PHRASES``). Lines starting with # are ignored. This is
    the bullet-proof way to protect a series-title logo that appears on every
    chapter's first/last page.
    """
    global _EXTRA_PHRASES_CACHE
    if _EXTRA_PHRASES_CACHE is not None:
        return _EXTRA_PHRASES_CACHE
    import os
    from pathlib import Path

    candidates = [os.environ.get("MANGA_SKIP_PHRASES", "")]
    candidates.append(str(Path(__file__).resolve().parent.parent / "skip_phrases.txt"))
    phrases: List[str] = []
    for c in candidates:
        if c and os.path.isfile(c):
            try:
                with open(c, encoding="utf-8") as fh:
                    for line in fh:
                        line = re.sub(r"\s+", "", line.strip())
                        if line and not line.startswith("#"):
                            phrases.append(line)
            except OSError:
                pass
    _EXTRA_PHRASES_CACHE = phrases
    return phrases


def looks_like_non_story_text(ocr_text: Optional[str]) -> bool:
    """True for ad / promo / credit / watermark / protected-title text."""
    if not ocr_text:
        return False
    if _PROMO_CJK_RE.search(ocr_text) or _PROMO_LATIN_RE.search(ocr_text):
        return True
    squashed = re.sub(r"\s+", "", ocr_text)
    return any(p in squashed for p in load_extra_skip_phrases())


# --------------------------------------------------------------------------
# Halo-free restore
# --------------------------------------------------------------------------


def _clip(b: Sequence[float], w: int, h: int, pad: int = 0) -> BBox:
    x1, y1, x2, y2 = (int(round(c)) for c in b)
    return (
        max(0, x1 - pad),
        max(0, y1 - pad),
        min(w, x2 + pad),
        min(h, y2 + pad),
    )


def adaptive_pad(bbox: Sequence[float], img_w: int, img_h: int) -> int:
    """Padding that scales with the region (big logos blur further out)."""
    x1, y1, x2, y2 = bbox
    short = max(1, min(x2 - x1, y2 - y1))
    page = max(img_w, img_h)
    return int(max(12, min(0.35 * short, 0.03 * page)))


def build_protect_mask(
    img_w: int,
    img_h: int,
    skip_bboxes: Iterable[Sequence[float]],
    keep_bboxes: Iterable[Sequence[float]] = (),
    keep_margin: int = 4,
) -> np.ndarray:
    """Boolean mask of pixels that must equal the original image.

    protect = union(padded skipped bboxes) minus union(kept bboxes + margin)
    so a translated neighbour is never "un-cleaned" by a nearby skipped item.
    """
    protect = np.zeros((img_h, img_w), dtype=bool)
    any_skip = False
    for b in skip_bboxes:
        x1, y1, x2, y2 = _clip(b, img_w, img_h, adaptive_pad(b, img_w, img_h))
        if x2 > x1 and y2 > y1:
            protect[y1:y2, x1:x2] = True
            any_skip = True
    if not any_skip:
        return protect
    for b in keep_bboxes:
        x1, y1, x2, y2 = _clip(b, img_w, img_h, keep_margin)
        if x2 > x1 and y2 > y1:
            protect[y1:y2, x1:x2] = False
    # The skipped bboxes themselves always win (their own pixels are sacred
    # even if a kept bbox overlaps them).
    for b in skip_bboxes:
        x1, y1, x2, y2 = _clip(b, img_w, img_h, 0)
        if x2 > x1 and y2 > y1:
            protect[y1:y2, x1:x2] = True
    return protect


def restore_skipped_regions(
    result: Image.Image,
    original: Image.Image,
    skip_bboxes: Sequence[Sequence[float]],
    keep_bboxes: Sequence[Sequence[float]] = (),
    feather: int = 3,
) -> Image.Image:
    """Copy ORIGINAL pixels back over every skipped region (+ padded halo).

    A small feather on the outer edge hides the seam against inpainted art.
    Returns ``result`` unchanged when there is nothing to restore or the sizes
    do not match (e.g. caller already upscaled).
    """
    if not skip_bboxes:
        return result
    if result.size != original.size:
        return result

    w, h = result.size
    protect = build_protect_mask(w, h, skip_bboxes, keep_bboxes)
    if not protect.any():
        return result

    alpha = Image.fromarray((protect.astype(np.uint8)) * 255, mode="L")
    if feather > 0:
        alpha = alpha.filter(ImageFilter.GaussianBlur(feather))
        # Blur only softens the outside edge: force the core to stay 100%.
        core = np.array(alpha)
        core[protect & (_erode(protect, feather * 2))] = 255
        alpha = Image.fromarray(core, mode="L")

    mode = result.mode
    base = result.convert("RGBA")
    src = original.convert("RGBA")
    out = Image.composite(src, base, alpha)
    return out.convert(mode) if mode != "RGBA" else out


def _erode(mask: np.ndarray, r: int) -> np.ndarray:
    """Cheap box erosion (no cv2 dependency in this helper)."""
    if r <= 0:
        return mask
    m = mask.astype(np.uint8)
    k = 2 * r + 1
    # separable min filter via PIL
    img = Image.fromarray(m * 255, mode="L").filter(ImageFilter.MinFilter(k))
    return np.array(img) > 0


def align_sfx_flags(flags: Optional[List[bool]], n: int) -> List[bool]:
    """Never drop ALL skip flags just because list length != item count.

    Old code reset every flag to False on a length mismatch, silently turning
    skip off for the whole page. Pad/truncate instead.
    """
    flags = list(flags or [])
    if len(flags) < n:
        flags.extend([False] * (n - len(flags)))
    return [bool(f) for f in flags[:n]]
