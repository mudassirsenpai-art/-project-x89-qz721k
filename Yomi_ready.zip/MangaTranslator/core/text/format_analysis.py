"""Measure the *format* of the original text block: line alignment, italic, bold.

Works on a binary ink mask (uint8, 255 = ink) of one bubble / OSB region and the
already-estimated tilt (see rotation_estimation). Everything here is a
conservative heuristic: whenever a measurement is unclear the neutral value is
returned (centered, not italic, not bold), so a page never gets a wrong
"format" just because the probe was unsure.
"""

from typing import Any, Dict, Optional

import cv2
import numpy as np

MIN_INK_PIXELS = 60
WORK_MAX_SIDE = 320
MIN_LINE_GAP_FRAC = 0.18  # gap between text lines, as a fraction of line height
ALIGN_TOL_FRAC = 0.35  # edge jitter tolerated, as a fraction of line height
ITALIC_WINDOW_DEG = 22.0  # only strokes within this of vertical are considered
ITALIC_MIN_LEAN_DEG = 2.0  # mean right-lean (deg) needed to call it italic (upright ~0, 11deg oblique ~4-5)
BOLD_MIN_STROKE_RATIO = 0.18  # stroke thickness / line height (regular comic fonts ~0.11-0.14, bold ~0.21+)
BOLD_MIN_LINE_PX = 16  # below this line height the stroke ratio is quantised/noisy, so never call it bold
NEUTRAL = {"align": "center", "italic": False, "bold": False, "lines": 0}


def clean_ink_mask(ink_mask: np.ndarray) -> np.ndarray:
    """Drop big, hollow components (leftover bubble-outline slivers) so only
    glyph-like ink is analysed. Cheap; safe to call on any ink mask."""
    try:
        binary = (ink_mask > 0).astype(np.uint8)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
        if n <= 2:
            return ink_mask
        ys, xs = np.where(binary > 0)
        total_w = xs.max() - xs.min() + 1
        total_h = ys.max() - ys.min() + 1
        fills = np.array(
            [stats[i][4] / float(max(1, stats[i][2] * stats[i][3])) for i in range(1, n)]
        )
        order = sorted(range(1, n), key=lambda i: -stats[i][4])
        big = [i for i in order[: max(3, int(0.4 * len(order)))] if fills[i - 1] >= 0.12]
        h_med = float(np.median([stats[i][3] for i in big])) if big else 0.0
        a_med = float(np.median([stats[i][4] for i in big])) if big else 0.0
        keep = np.zeros(n, dtype=bool)
        for i in range(1, n):
            x, y, w, h, area = stats[i]
            fill = fills[i - 1]
            ring_like = w > 0.5 * total_w and h > 0.5 * total_h and fill < 0.2
            # hollow arcs much longer than a letter = bubble-outline fragments
            arc_like = fill < 0.12 and h_med > 0 and max(w, h) > 2.0 * h_med
            # long, hair-thin strokes (near-vertical/horizontal outline pieces
            # have a high bbox fill, so test thickness instead)
            if h_med > 0 and max(w, h) > 2.5 * h_med:
                if area / float(max(w, h)) < 0.25 * h_med:
                    arc_like = True
            keep[i] = not (ring_like or arc_like)
        # also drop isolated crumbs that sit far from any solid, letter-like
        # component (more bubble-outline leftovers)
        solid_ids = [
            i for i in range(1, n)
            if keep[i] and fills[i - 1] >= 0.12 and stats[i][3] >= 0.5 * h_med
            and stats[i][4] >= 0.3 * a_med
        ]
        if solid_ids and h_med > 0:
            zone = np.zeros(binary.shape, dtype=np.uint8)
            zone[np.isin(labels, solid_ids)] = 1
            r = max(3, int(round(1.6 * h_med)))
            zone = cv2.dilate(zone, cv2.getStructuringElement(cv2.MORPH_RECT, (2 * r + 1, 2 * r + 1)))
            for i in range(1, n):
                if keep[i] and i not in solid_ids:
                    cx, cy = stats[i][0] + stats[i][2] // 2, stats[i][1] + stats[i][3] // 2
                    if zone[min(cy, zone.shape[0] - 1), min(cx, zone.shape[1] - 1)] == 0:
                        keep[i] = False
        # if the "ring" is the whole mask, everything is removed: keep original
        if not keep.any():
            return ink_mask
        out = np.where(keep[labels], 255, 0).astype(np.uint8)
        return out
    except Exception:
        return ink_mask


def _prepare(ink_mask: np.ndarray, rotation_deg: float) -> Optional[np.ndarray]:
    ys, xs = np.where(ink_mask > 0)
    if ys.size < MIN_INK_PIXELS:
        return None
    crop = ink_mask[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1]
    ch, cw = crop.shape
    scale = min(1.0, WORK_MAX_SIDE / float(max(ch, cw)))
    if scale < 1.0:
        crop = cv2.resize(
            crop,
            (max(1, int(round(cw * scale))), max(1, int(round(ch * scale)))),
            interpolation=cv2.INTER_AREA,
        )
    crop = (crop > 64).astype(np.uint8) * 255
    ch, cw = crop.shape
    diag = int(np.ceil(np.hypot(ch, cw))) + 6
    canvas = np.zeros((diag, diag), dtype=np.uint8)
    oy, ox = (diag - ch) // 2, (diag - cw) // 2
    canvas[oy : oy + ch, ox : ox + cw] = crop
    if abs(rotation_deg) > 0.01:
        # rotation_deg > 0 means the text is tilted clockwise; rotating the
        # image CCW by the same amount (cv2 positive angle) levels it again.
        mat = cv2.getRotationMatrix2D((diag / 2.0, diag / 2.0), rotation_deg, 1.0)
        canvas = cv2.warpAffine(canvas, mat, (diag, diag), flags=cv2.INTER_LINEAR)
        canvas = (canvas > 64).astype(np.uint8) * 255
    ys, xs = np.where(canvas > 0)
    if ys.size < MIN_INK_PIXELS:
        return None
    return canvas[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1]


def _line_bands(level: np.ndarray):
    """Split a levelled ink image into text-line row bands [(y0, y1), ...].

    Lines are found as runs of rows whose (smoothed) ink count is clearly above
    the valleys between lines, so lines whose descenders/ascenders touch are
    still separated.
    """
    prof = level.sum(axis=1, dtype=np.float64) / 255.0
    if prof.max() <= 0:
        return []
    k = max(1, int(round(level.shape[0] * 0.01)))
    prof = np.convolve(prof, np.ones(2 * k + 1) / (2 * k + 1), mode="same")
    on = prof > 0.22 * prof.max()
    bands, start = [], None
    for y, v in enumerate(on):
        if v and start is None:
            start = y
        elif not v and start is not None:
            bands.append([start, y])
            start = None
    if start is not None:
        bands.append([start, len(on)])
    if not bands:
        return []
    heights = [b[1] - b[0] for b in bands]
    med_h = float(np.median(heights))
    merged = [bands[0]]
    for b in bands[1:]:
        # a very short valley inside one line (e.g. between x-height and
        # ascender rows) must not split it
        if b[0] - merged[-1][1] < MIN_LINE_GAP_FRAC * med_h * 0.5:
            merged[-1][1] = b[1]
        else:
            merged.append(b)
    return [tuple(b) for b in merged if (b[1] - b[0]) >= 0.35 * med_h]


def _alignment(level: np.ndarray, bands) -> str:
    if len(bands) < 2:
        return "center"
    lefts, rights = [], []
    for y0, y1 in bands:
        xs = np.where(level[y0:y1].sum(axis=0) > 0)[0]
        if xs.size == 0:
            continue
        lefts.append(float(xs.min()))
        rights.append(float(xs.max()))
    if len(lefts) < 2:
        return "center"
    lefts, rights = np.array(lefts), np.array(rights)
    centers = (lefts + rights) / 2.0
    line_h = float(np.median([b[1] - b[0] for b in bands]))
    tol = max(2.0, ALIGN_TOL_FRAC * line_h)
    spread = lambda a: float(a.max() - a.min())
    l_ok, r_ok, c_ok = spread(lefts) <= tol, spread(rights) <= tol, spread(centers) <= tol
    if l_ok and r_ok:
        return "center"  # all lines equally wide: alignment is moot
    if c_ok and not (l_ok or r_ok):
        return "center"
    if l_ok and not r_ok:
        return "left"
    if r_ok and not l_ok:
        return "right"
    # nothing lines up well: pick the clearly best edge, else stay centered
    spreads = {"left": spread(lefts), "right": spread(rights), "center": spread(centers)}
    best = min(spreads, key=spreads.get)
    others = sorted(v for k, v in spreads.items() if k != best)
    if best != "center" and spreads[best] < 0.6 * others[0]:
        return best
    return "center"


def _italic(level: np.ndarray) -> bool:
    """Italic = near-vertical strokes lean right. Measure the mean lean of
    near-vertical edges (diagonals like A/V/W are excluded by the window)."""
    h, w = level.shape
    if h < 12 or w < 12:
        return False
    blur = cv2.GaussianBlur(level, (3, 3), 0).astype(np.float32) / 255.0
    gx = cv2.Sobel(blur, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(blur, cv2.CV_32F, 0, 1, ksize=3)
    mag = np.hypot(gx, gy)
    sel = mag > 0.5 * mag.max()
    if int(sel.sum()) < 40:
        return False
    # stroke direction is perpendicular to the gradient. lean = angle of the
    # stroke away from vertical, positive = top leaning right.
    lean = np.degrees(np.arctan2(gy[sel], gx[sel]))  # gradient angle
    lean = (lean + 90.0) % 180.0 - 90.0  # fold to (-90, 90]
    # gradient angle 0 == perfectly vertical stroke
    lean = np.where(lean > 90, lean - 180, lean)
    near = np.abs(lean) <= ITALIC_WINDOW_DEG
    if int(near.sum()) < 30:
        return False
    # image rows grow downward; measured so that +lean == top of stroke leans right
    mean_lean = float(np.mean(lean[near]))
    return mean_lean >= ITALIC_MIN_LEAN_DEG


def _bold(level: np.ndarray, bands) -> bool:
    """Stroke thickness relative to line height: t ~= 2*area/perimeter."""
    if not bands:
        return False
    line_h = float(np.median([b[1] - b[0] for b in bands]))
    if line_h < BOLD_MIN_LINE_PX:
        return False
    contours, _ = cv2.findContours(level, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
    perim = sum(cv2.arcLength(c, True) for c in contours)
    area = float(np.count_nonzero(level))
    if perim <= 0:
        return False
    thickness = 2.0 * area / perim
    return (thickness / line_h) >= BOLD_MIN_STROKE_RATIO


def analyze_text_format(
    ink_mask: Optional[np.ndarray], rotation_deg: float = 0.0
) -> Dict[str, Any]:
    """Return {"align": "left|center|right", "italic": bool, "bold": bool, "lines": int}."""
    try:
        if ink_mask is None or ink_mask.ndim != 2:
            return dict(NEUTRAL)
        level = _prepare(clean_ink_mask(ink_mask), rotation_deg)
        if level is None or level.shape[0] < 6 or level.shape[1] < 6:
            return dict(NEUTRAL)
        bands = _line_bands(level)
        if not bands:
            return dict(NEUTRAL)
        # vertical (tall, narrow, many columns) text: alignment/bold are not
        # meaningful for the horizontal re-layout
        horizontal = level.shape[1] >= level.shape[0] * 0.6 or len(bands) >= 2
        return {
            "align": _alignment(level, bands) if horizontal else "center",
            "italic": _italic(level) if horizontal else False,
            "bold": _bold(level, bands) if horizontal else False,
            "lines": len(bands),
        }
    except Exception:
        return dict(NEUTRAL)
