"""Post-SAM refinement of speech-bubble masks.

SAM (2.1 / 3) occasionally returns a mask that is

  * too SMALL  - stops at the text / inner glow and misses the bubble edge, or
                 has holes where letters were, so cleaning leaves text behind
                 and the renderer gets a cramped box;
  * too BIG    - leaks through the tail or a gap in the outline into the
                 artwork, so cleaning paints outside the bubble;
  * NOISY      - detached islands, thin tentacles, pin-holes.

This module repairs those cases using two independent signals:

  A. Shape hygiene (always): fill holes, drop islands, cut thin leaks.
  B. Outline verification (only when the bubble is clearly enclosed by a dark
     outline on the ORIGINAL page): the closed interior found from pixels is
     used to grow a too-small mask and to trim a leaking one.

Every step is guarded: if anything looks off the ORIGINAL mask is returned, so
refinement can only help, never break the pipeline. Set the environment
variable ``MT_REFINE_BUBBLE_MASKS=0`` to disable it completely.
"""

import os
from typing import Optional

import cv2
import numpy as np

from utils.logging import log_message

ENABLED = os.environ.get("MT_REFINE_BUBBLE_MASKS", "1") != "0"

MIN_BUBBLE_SIDE = 30  # smaller boxes are left alone
MIN_AGREEMENT = 0.50  # share of SAM mask that must sit inside the verified interior
GROW_TRIGGER = 1.04  # interior must exceed mask area by this factor to grow
LEAK_TRIGGER = 0.03  # share of mask outside allowed zone before trimming
MAX_AREA_CHANGE_UP = 1.60  # refined/original area sanity bounds (no outline proof)
MAX_AREA_CHANGE_UP_OUTLINE = 3.00  # looser when the outline confirmed the shape
MAX_AREA_CHANGE_DOWN = 0.50
BOX_PAD = 4  # refined mask may exceed the YOLO box by at most this many px
COLOR_TOL_BRIGHT = 10  # per-channel tolerance vs bubble fill (white/very light fills)
COLOR_TOL_OTHER = 18  # tolerance for mid-tone / coloured fills
COLOR_CLOSE_PX = 9  # closes speed lines / text strokes inside the interior
COLOR_EDGE_PX = 3  # keep this much beyond the interior (anti-aliased edge)
COLOR_MIN_INTERIOR = 0.20  # interior must cover this share of the box
COLOR_MAX_TRIM = 0.45  # never trim away more than this share of the mask

_interior_override = None  # test hook


def _get_interior_fn():
    if _interior_override is not None:
        return _interior_override
    from core.image.cleaning import _bubble_interior_from_original

    return _bubble_interior_from_original


def _largest_component(mask_u8: np.ndarray, prefer_xy=None) -> np.ndarray:
    """Keep one connected component: the one containing ``prefer_xy`` if given
    (and set), otherwise the largest."""
    num, lab, stats, _ = cv2.connectedComponentsWithStats(mask_u8, connectivity=8)
    if num <= 2:
        return mask_u8
    keep = None
    if prefer_xy is not None:
        px, py = prefer_xy
        if 0 <= py < lab.shape[0] and 0 <= px < lab.shape[1] and lab[py, px] > 0:
            keep = int(lab[py, px])
    if keep is None:
        keep = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return (lab == keep).astype(np.uint8)


def _fill_holes(mask_u8: np.ndarray) -> np.ndarray:
    """Fill every hole not connected to the crop border (letters, pin-holes)."""
    padded = np.pad(mask_u8, 1)
    inv = (padded == 0).astype(np.uint8)
    _, lab = cv2.connectedComponents(inv, connectivity=4)
    outside_id = lab[0, 0]
    filled = np.where((padded == 0) & (lab != outside_id), 1, padded)
    return filled[1:-1, 1:-1].astype(np.uint8)


def _shape_hygiene(mask_u8: np.ndarray, bw: int, bh: int, center_xy) -> np.ndarray:
    """Step A: holes -> island removal -> thin-leak removal (edge preserving)."""
    m = _fill_holes(mask_u8)
    m = _largest_component(m, center_xy)
    k = max(3, int(0.03 * min(bw, bh))) | 1
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    opened = cv2.morphologyEx(np.pad(m, k), cv2.MORPH_OPEN, ker)[k:-k, k:-k]
    if opened.sum() >= 0.6 * m.sum():  # opening must not eat the bubble
        opened = _largest_component(opened, center_xy)
        # reconstruct edges the opening shaved off, but never regrow leaks
        regrow = cv2.dilate(opened, ker) & m
        m = np.maximum(opened, regrow)
    return m.astype(np.uint8)



def _color_interior(image_bgr, crop_box, mask_crop, bw, bh):
    """Interior of a bubble that has NO dark outline (flash / burst / pale
    bubbles): the connected region of pixels whose colour matches the bubble
    fill, with text and speed lines closed up. Returns a uint8 0/1 array the
    size of the crop, or None when the fill cannot be established reliably."""
    cx1, cy1, cx2, cy2 = crop_box
    crop = image_bgr[cy1:cy2, cx1:cx2, :3].astype(np.int16)
    h, w = crop.shape[:2]
    # fill colour = median of the SAM-mask pixels in the middle of the box
    mh0, mh1 = int(h * 0.3), int(h * 0.7)
    mw0, mw1 = int(w * 0.3), int(w * 0.7)
    core = (mask_crop > 0)[mh0:mh1, mw0:mw1]
    px = crop[mh0:mh1, mw0:mw1][core]
    if px.shape[0] < 50:
        return None
    # brightest half of the core: text pixels are dark and sparse
    lum = px.mean(axis=1)
    px = px[lum >= np.percentile(lum, 50)]
    fill = np.median(px, axis=0)
    tol = COLOR_TOL_BRIGHT if fill.min() >= 235 else COLOR_TOL_OTHER
    sim = (np.abs(crop - fill).max(axis=2) <= tol).astype(np.uint8)
    k = COLOR_CLOSE_PX
    ker = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    sim = cv2.morphologyEx(np.pad(sim, k), cv2.MORPH_CLOSE, ker)[k:-k, k:-k]
    sim = cv2.morphologyEx(sim, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    num, lab, stats, _ = cv2.connectedComponentsWithStats(sim, connectivity=4)
    if num <= 1:
        return None
    inside = lab[(mask_crop > 0)]
    ids, cnt = np.unique(inside[inside > 0], return_counts=True)
    if len(ids) == 0:
        return None
    region = (lab == ids[int(np.argmax(cnt))]).astype(np.uint8)
    region = _fill_holes(region)  # letters / speech lines inside the bubble
    if region.sum() < COLOR_MIN_INTERIOR * bw * bh:
        return None
    return region


def refine_single_bubble_mask(
    image_bgr: np.ndarray,
    mask: np.ndarray,
    bbox,
    skip_outline: bool = False,
    verbose: bool = False,
) -> Optional[np.ndarray]:
    """Return a refined uint8 0/255 mask (same HxW as ``mask``), or None if the
    original should be kept unchanged."""
    H, W = mask.shape[:2]
    x1, y1, x2, y2 = [int(round(float(v))) for v in bbox[:4]]
    x1, y1, x2, y2 = max(0, x1), max(0, y1), min(W, x2), min(H, y2)
    bw, bh = x2 - x1, y2 - y1
    if bw < MIN_BUBBLE_SIDE or bh < MIN_BUBBLE_SIDE:
        return None

    pad = max(BOX_PAD, int(0.04 * max(bw, bh)))
    cx1, cy1 = max(0, x1 - pad), max(0, y1 - pad)
    cx2, cy2 = min(W, x2 + pad), min(H, y2 + pad)

    orig = (mask[cy1:cy2, cx1:cx2] > 0).astype(np.uint8)
    orig_area = int(orig.sum())
    if orig_area < 0.05 * bw * bh:
        return None  # SAM basically failed; do not guess from this

    center = ((x1 + x2) // 2 - cx1, (y1 + y2) // 2 - cy1)
    refined = _shape_hygiene(orig, bw, bh, center)

    # ---- Step B: outline-verified correction ------------------------------
    used_outline = False
    if not skip_outline:
        try:
            res = _get_interior_fn()(image_bgr, (x1, y1, x2, y2), pad=12)
        except Exception as e:  # pragma: no cover - defensive
            log_message(f"mask refine: interior probe failed ({e})", verbose=verbose)
            res = None
        if res is not None:
            ix, iy, interior = res
            ih, iw = interior.shape[:2]
            full_int = np.zeros((cy2 - cy1, cx2 - cx1), np.uint8)
            # place interior (page coords ix,iy) into crop coords
            sx1, sy1 = max(cx1, ix), max(cy1, iy)
            sx2, sy2 = min(cx2, ix + iw), min(cy2, iy + ih)
            if sx2 > sx1 and sy2 > sy1:
                full_int[sy1 - cy1 : sy2 - cy1, sx1 - cx1 : sx2 - cx1] = interior[
                    sy1 - iy : sy2 - iy, sx1 - ix : sx2 - ix
                ]
            int_area = int(full_int.sum())
            agree = float((refined & full_int).sum()) / float(max(1, refined.sum()))
            if int_area > 0 and agree >= MIN_AGREEMENT:
                used_outline = True
                # too small -> grow into the verified interior
                if int_area > GROW_TRIGGER * refined.sum():
                    refined = np.maximum(refined, full_int)
                # leaking -> trim to interior + outline stroke thickness
                t = max(4, int(0.012 * max(bw, bh)))
                allowed = cv2.dilate(
                    full_int,
                    cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * t + 1, 2 * t + 1)),
                )
                outside = int((refined & (1 - allowed)).sum())
                if outside > LEAK_TRIGGER * max(1, int(refined.sum())):
                    refined = refined & allowed
                    refined = _largest_component(_fill_holes(refined), center)

    # ---- Step C: colour-based leak trim (bubbles without a dark outline) ---
    if not used_outline:
        try:
            interior = _color_interior(
                image_bgr, (cx1, cy1, cx2, cy2), refined, bw, bh
            )
        except Exception as e:  # pragma: no cover - defensive
            log_message(f"mask refine: colour probe failed ({e})", verbose=verbose)
            interior = None
        if interior is not None:
            agree = float((refined & interior).sum()) / float(max(1, refined.sum()))
            if agree >= MIN_AGREEMENT:
                e = COLOR_EDGE_PX
                allowed = cv2.dilate(
                    interior,
                    cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * e + 1, 2 * e + 1)),
                )
                trimmed = refined & allowed
                lost = 1.0 - float(trimmed.sum()) / float(max(1, refined.sum()))
                if 0.02 < lost <= COLOR_MAX_TRIM:
                    refined = _largest_component(_fill_holes(trimmed), center)
                    used_outline = True  # evidence-backed change

    # keep inside the (padded) detector box so neighbours are never touched
    box_lim = np.zeros_like(refined)
    box_lim[y1 - cy1 - 0 : y2 - cy1 + 0, x1 - cx1 : x2 - cx1] = 1
    box_lim = cv2.dilate(box_lim, np.ones((2 * BOX_PAD + 1, 2 * BOX_PAD + 1), np.uint8))
    refined = refined & box_lim

    new_area = int(refined.sum())
    ratio = new_area / float(max(1, orig_area))
    max_up = MAX_AREA_CHANGE_UP_OUTLINE if used_outline else MAX_AREA_CHANGE_UP
    if new_area == 0 or ratio > max_up or ratio < MAX_AREA_CHANGE_DOWN:
        log_message(
            f"mask refine: area change x{ratio:.2f} out of bounds, keeping original",
            verbose=verbose,
        )
        return None
    if np.array_equal(refined, orig):
        return None

    out = np.zeros((H, W), np.uint8)
    # outside the crop the original mask is kept untouched
    out[:] = (mask > 0).astype(np.uint8) * 255
    out[cy1:cy2, cx1:cx2] = refined * 255
    log_message(
        f"mask refine: bubble {bw}x{bh} area x{ratio:.2f}"
        + (" (outline-verified)" if used_outline else ""),
        verbose=verbose,
    )
    return out


def refine_bubble_detections(image_bgr: np.ndarray, detections, verbose: bool = False):
    """Refine ``sam_mask`` of every bubble detection. Returns a NEW list of
    shallow-copied dicts (cached detections are never mutated)."""
    if not ENABLED or not detections or image_bgr is None:
        return detections
    H, W = image_bgr.shape[:2]
    out_list = []
    changed = 0
    for det in detections:
        try:
            if det.get("is_outside_text", False):
                out_list.append(det)
                continue
            m = det.get("sam_mask")
            bbox = det.get("bbox")
            if m is None or bbox is None or len(bbox) != 4 or m.shape[:2] != (H, W):
                out_list.append(det)
                continue
            skip_outline = bool(det.get("conjoined_neighbor_bboxes"))
            new_mask = refine_single_bubble_mask(
                image_bgr, m, bbox, skip_outline=skip_outline, verbose=verbose
            )
            if new_mask is None:
                out_list.append(det)
            else:
                d = dict(det)
                d["sam_mask"] = new_mask
                out_list.append(d)
                changed += 1
        except Exception as e:  # never break detection over refinement
            log_message(f"mask refine skipped for one bubble: {e}", verbose=verbose)
            out_list.append(det)
    if changed:
        log_message(
            f"Refined {changed}/{len(detections)} bubble mask(s)", always_print=True
        )
    return out_list
